# The Everything Calculator — Flutter

Production-oriented Flutter source for iPhone and Android, version 1.0.5. The app has a live scientific/basic expression engine, textbook-style TeX formulas, a compact top-drop catalog with 92 tools, nested favorite folders, local calculation history, haptic feedback, live reference-rate currency conversion, visual graphs/shapes, and persisted light/dark/system settings.

## Version 1.0.5 highlights

- Half-width toolbox with protected text/icon layout and a tighter main calculator viewport
- Nameable, searchable favorite folders with nested folders, rename, move, and delete controls
- Rearranged signed-number keypad with `000`, and mortgage lifetime loan cost
- Typed reference dimensions plus shared true-scale geometry and element-shape visuals
- Corrected isometric prisms, labeled triangle sides/angles, and lighter reference labels
- Crisp, freely pannable/pinch-zoomable quadratic graph with 0.2 subdivisions and a marked apex
- Rocket branding that is independent of external sprite loading and corrected rectangle badge

## Requirements

- Flutter 3.35 or newer
- Dart 3.9 or newer
- Android Studio/Android SDK for Android builds
- macOS with Xcode for iOS builds

## One-time platform setup

This source bundle keeps generated platform runners out of the repository so they can be created by the exact Flutter SDK you use. From this directory, run:

```bash
flutter create --platforms=android,ios --org com.everythingcalculator --project-name everything_calculator .
flutter pub get
flutter test
flutter run
```

The included `tool/bootstrap_platforms.sh` runs the same setup and test sequence on macOS/Linux.
It also ensures the Android release manifest includes Internet permission for the live currency-rate request.

## Release builds

```bash
flutter build appbundle   # Android Play Store bundle
flutter build apk         # Android APK
flutter build ipa         # iOS archive; requires macOS/Xcode/signing
```

Before publishing, replace the generated bundle identifiers, signing configuration, app-store metadata, and launcher icons using `assets/logo.svg` as the source artwork.

## Architecture

- `lib/core/` — expression parser/evaluator, history/settings persistence, formatting
- `lib/data/` — unit, calculator, and 118-element density catalogs
- `lib/models/` — extensible tool definitions and result models
- `lib/screens/` — calculator home and generic converter/calculator screens
- `lib/widgets/` — logo, settings/history sheets, searchable tool drawer
- `CHANGELOG.md` — versioned release notes mirrored by the in-app Change log button
- `test/` — expression, exact conversion, catalog coverage, and default-result tests

## Adding another tool

1. Add a `UnitTool` to `lib/data/unit_catalog.dart`, or a `CalculatorTool` to `lib/data/calculator_catalog.dart`.
2. Add it to a section in `lib/data/tool_catalog.dart`.
3. Add a default-case assertion if the tool needs special coverage.

The generic mobile tool screens, search index, live input handling, result layout, copy action, and formula panel are data-driven and require no new screen for ordinary additions.

## Accuracy notes

- Linear conversions use a documented base factor; temperature also uses exact offsets.
- Fuel economy is reciprocal and has dedicated logic.
- Calendar-day differences use UTC dates to avoid daylight-saving-time errors.
- Currency conversion requests the latest available Frankfurter reference rate directly from `api.frankfurter.dev`, falls back between v2 and v1, and labels the rate date; provider spreads and fees are not included.
- Finance and health outputs are labeled estimates; they are not professional financial or medical advice.
- Element names and reference densities were checked against the [PubChem periodic table](https://pubchem.ncbi.nlm.nih.gov/periodic-table/) and [NIST periodic table](https://www.nist.gov/pml/periodic-table-elements). Density changes with physical conditions and allotrope; gas and theoretical values are labeled in-app.
