import 'package:everything_calculator/core/expression_engine.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('expression engine', () {
    test('respects precedence and parentheses', () {
      expect(calculateExpression('2*(8+4)').value, 24);
      expect(calculateExpression('-2^2').value, -4);
    });

    test('supports textbook operations', () {
      expect(calculateExpression('sqrt(81)+3^2').value, 18);
      expect(calculateExpression('5!').value, 120);
      expect(calculateExpression('50%').value, .5);
      expect(calculateExpression('sinh(0)').value, 0);
      expect(calculateExpression('cosh(0)').value, 1);
    });

    test('supports constants and implicit multiplication', () {
      expect(
        calculateExpression('2pi').value,
        closeTo(6.283185307179586, 1e-12),
      );
    });

    test('uses selected angle mode', () {
      expect(calculateExpression('sin(30)').value, closeTo(.5, 1e-12));
      expect(
        calculateExpression(
          'sin(pi/2)',
          context: const ExpressionContext(angle: AngleUnit.radians),
        ).value,
        closeTo(1, 1e-12),
      );
    });

    test('renders structural latex', () {
      expect(calculateExpression('1/2').latex, contains(r'\frac'));
      expect(calculateExpression('sqrt(9)').latex, contains(r'\sqrt'));
      expect(calculateExpression('3^2').latex, contains('^{2}'));
    });
  });
}
