import 'package:everything_calculator/data/tool_catalog.dart';
import 'package:everything_calculator/data/tool_badges.dart';
import 'package:everything_calculator/models/tool_models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  Map<String, String> defaultsFor(CalculatorTool tool) {
    final values = <String, String>{};
    for (final field in tool.fields) {
      values[field.id] = field.type == ToolFieldType.time12
          ? field.id.toLowerCase().contains('start')
                ? '08:30'
                : '05:15'
          : field.defaultValue;
      if (field.solveToggle) {
        values['solve_${field.id}'] = '${field.solveByDefault}';
      }
      if (field.type == ToolFieldType.time12) {
        values['${field.id}Period'] = field.periodDefault;
      }
    }
    return values;
  }

  test('catalog has broad coverage and unique ids', () {
    expect(allTools.length, 92);
    expect(toolById.length, allTools.length);
    expect(allTools.map(toolBadge).toSet().length, allTools.length);
  });

  test('all tools calculate with their defaults', () {
    for (final tool in allTools) {
      if (tool is UnitTool) {
        expect(
          tool.convert(1, tool.defaultFrom, tool.defaultTo).value.isFinite,
          isTrue,
          reason: tool.id,
        );
      } else if (tool is CalculatorTool) {
        if (tool.asyncType.isEmpty) {
          expect(
            () => tool.calculate(defaultsFor(tool)),
            returnsNormally,
            reason: tool.id,
          );
        }
      }
    }
  });

  test('temperature offsets are exact', () {
    final tool = toolById['unit-temperature']! as UnitTool;
    expect(tool.convert(0, 0, 1).value, closeTo(32, 1e-12));
    expect(tool.convert(100, 0, 1).value, closeTo(212, 1e-12));
  });

  test('mortgage includes escrow and housing costs', () {
    final tool = toolById['calc-mortgage-payment']! as CalculatorTool;
    final result = tool.calculate(defaultsFor(tool));
    expect(result.primary as num, inInclusiveRange(2000, 3000));
    expect(
      result.details.map((detail) => detail.label),
      contains('Monthly escrow'),
    );
    final lifetime = result.details.firstWhere(
      (detail) => detail.label == 'Lifetime cost of loan',
    );
    expect(lifetime.value as num, greaterThan(400000));
  });

  test('aluminum cube uses the reference density', () {
    final tool = toolById['calc-element-shape']! as CalculatorTool;
    final result = tool.calculate(defaultsFor(tool));
    expect(result.primary as num, closeTo(1000, 1e-10));
    expect(
      result.details
              .firstWhere(
                (detail) => detail.label == 'Mass' && detail.suffix == ' g',
              )
              .value
          as num,
      closeTo(2700, 1e-10),
    );
  });

  test('automatic triangle solver completes and classifies a 3-4-5 case', () {
    final tool = toolById['calc-triangle']! as CalculatorTool;
    final result = tool.calculate({
      'sideA': '3',
      'sideB': '4',
      'sideC': '5',
      'angleA': '',
      'angleB': '',
      'angleC': '',
    });
    expect(result.primary as num, closeTo(6, 1e-8));
    expect(result.details.map((detail) => detail.label), contains('Angle C'));
    expect(
      result.details
          .firstWhere((detail) => detail.label == 'Triangle type')
          .value,
      'Right scalene triangle',
    );
    expect(
      () => tool.calculate({
        'sideA': '3',
        'sideB': '',
        'sideC': '',
        'angleA': '',
        'angleB': '',
        'angleC': '',
      }),
      throwsA(
        isA<FormatException>().having(
          (error) => error.message,
          'message',
          'More data needed for triangle calculation.',
        ),
      ),
    );
  });

  test('currency converter is marked as live async data', () {
    final tool = toolById['calc-currency']! as CalculatorTool;
    expect(tool.asyncType, 'currency');
  });
}
