import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/tool_models.dart';
import 'element_catalog.dart';

ToolField _n(
  String id,
  String label,
  num value, {
  String unit = '',
  String help = '',
  String? showWhenField,
  List<String> showWhenValues = const [],
  bool solveToggle = false,
  bool solveByDefault = false,
}) => ToolField.number(
  id,
  label,
  value,
  unit: unit,
  help: help,
  showWhenField: showWhenField,
  showWhenValues: showWhenValues,
  solveToggle: solveToggle,
  solveByDefault: solveByDefault,
);
ToolField _t(
  String id,
  String label,
  String value, {
  String help = '',
  String? showWhenField,
  List<String> showWhenValues = const [],
  bool numericList = false,
  bool time12 = false,
  String periodDefault = 'am',
}) => ToolField.text(
  id,
  label,
  value,
  help: help,
  showWhenField: showWhenField,
  showWhenValues: showWhenValues,
  numericList: numericList,
  time12: time12,
  periodDefault: periodDefault,
);
ToolField _d(String id, String label, String value) =>
    ToolField.date(id, label, value);
ToolField _s(
  String id,
  String label,
  String value,
  List<ToolOption> options, {
  bool segmented = false,
  String? showWhenField,
  List<String> showWhenValues = const [],
}) => ToolField.select(
  id,
  label,
  value,
  options,
  segmented: segmented,
  showWhenField: showWhenField,
  showWhenValues: showWhenValues,
);
ToolOption _o(String value, String label) => ToolOption(value, label);

CalculatorTool _calc(
  String id,
  String title,
  String description,
  IconData icon,
  List<ToolField> fields,
  ToolCalculator calculate, {
  String note = '',
  bool currency = false,
  String asyncType = '',
}) => CalculatorTool(
  id: 'calc-$id',
  title: title,
  shortTitle: title.replaceAll(' calculator', ''),
  description: description,
  icon: icon,
  fields: fields,
  calculate: calculate,
  note: note,
  currency: currency,
  asyncType: asyncType,
);

double _number(Map<String, String> values, String id, String label) {
  final parsed = double.tryParse((values[id] ?? '').replaceAll(',', ''));
  if (parsed == null || !parsed.isFinite)
    throw FormatException('$label must be a valid number.');
  return parsed;
}

double _positive(
  Map<String, String> values,
  String id,
  String label, {
  bool zero = false,
}) {
  final value = _number(values, id, label);
  if (zero ? value < 0 : value <= 0) {
    throw FormatException(
      '$label must be ${zero ? 'zero or greater' : 'greater than zero'}.',
    );
  }
  return value;
}

double _clock12Hours(String? input, String? period, String label) {
  final match = RegExp(r'^(\d{1,2}):(\d{2})$').firstMatch(input?.trim() ?? '');
  if (match == null) {
    throw FormatException('$label must use a 12-hour time such as 08:30.');
  }
  final hour = int.parse(match.group(1)!);
  final minute = int.parse(match.group(2)!);
  if (hour < 1 || hour > 12 || minute > 59) {
    throw FormatException('$label must use a valid 12-hour time.');
  }
  return (hour % 12) + (period == 'pm' ? 12 : 0) + minute / 60;
}

String _compact(num value) {
  final number = value.toDouble();
  if (number == number.roundToDouble()) return number.toInt().toString();
  return number.toStringAsPrecision(10).replaceFirst(RegExp(r'\.?0+$'), '');
}

List<double> _numberList(String input) {
  final values = input
      .split(RegExp(r'[\s,;]+'))
      .where((part) => part.isNotEmpty)
      .map(double.tryParse)
      .toList();
  if (values.isEmpty ||
      values.any((value) => value == null || !value.isFinite)) {
    throw const FormatException('Enter valid numbers separated by commas.');
  }
  return values.cast<double>();
}

int _gcd(int a, int b) {
  a = a.abs();
  b = b.abs();
  while (b != 0) {
    final old = a;
    a = b;
    b = old % b;
  }
  return a;
}

double _combination(int n, int r) {
  if (n < 0 || r < 0 || r > n)
    throw const FormatException('Require whole numbers with 0 ≤ r ≤ n.');
  r = math.min(r, n - r);
  var result = 1.0;
  for (var index = 1; index <= r; index += 1) {
    result = result * (n - r + index) / index;
  }
  return result;
}

({int numerator, int denominator}) _decimalFraction(
  double value,
  int maxDenominator,
) {
  final sign = value < 0 ? -1 : 1;
  final target = value.abs();
  if (target == target.roundToDouble()) {
    return (numerator: sign * target.round(), denominator: 1);
  }
  var h1 = 1;
  var h2 = 0;
  var k1 = 0;
  var k2 = 1;
  var remaining = target;
  for (var iteration = 0; iteration < 64; iteration += 1) {
    final whole = remaining.floor();
    final h = whole * h1 + h2;
    final k = whole * k1 + k2;
    if (k > maxDenominator) break;
    if ((target - h / k).abs() <= 1e-12) {
      return (numerator: sign * h, denominator: k);
    }
    h2 = h1;
    h1 = h;
    k2 = k1;
    k1 = k;
    final fraction = remaining - whole;
    if (fraction == 0) break;
    remaining = 1 / fraction;
  }
  return (numerator: sign * h1, denominator: k1);
}

const _currencies = <ToolOption>[
  ToolOption('USD', 'USD — US dollar'),
  ToolOption('EUR', 'EUR — Euro'),
  ToolOption('GBP', 'GBP — British pound'),
  ToolOption('JPY', 'JPY — Japanese yen'),
  ToolOption('CAD', 'CAD — Canadian dollar'),
  ToolOption('AUD', 'AUD — Australian dollar'),
  ToolOption('CHF', 'CHF — Swiss franc'),
  ToolOption('CNY', 'CNY — Chinese yuan'),
  ToolOption('HKD', 'HKD — Hong Kong dollar'),
  ToolOption('NZD', 'NZD — New Zealand dollar'),
  ToolOption('SEK', 'SEK — Swedish krona'),
  ToolOption('NOK', 'NOK — Norwegian krone'),
  ToolOption('DKK', 'DKK — Danish krone'),
  ToolOption('PLN', 'PLN — Polish zloty'),
  ToolOption('CZK', 'CZK — Czech koruna'),
  ToolOption('HUF', 'HUF — Hungarian forint'),
  ToolOption('RON', 'RON — Romanian leu'),
  ToolOption('BGN', 'BGN — Bulgarian lev'),
  ToolOption('TRY', 'TRY — Turkish lira'),
  ToolOption('BRL', 'BRL — Brazilian real'),
  ToolOption('MXN', 'MXN — Mexican peso'),
  ToolOption('INR', 'INR — Indian rupee'),
  ToolOption('IDR', 'IDR — Indonesian rupiah'),
  ToolOption('KRW', 'KRW — South Korean won'),
  ToolOption('MYR', 'MYR — Malaysian ringgit'),
  ToolOption('PHP', 'PHP — Philippine peso'),
  ToolOption('SGD', 'SGD — Singapore dollar'),
  ToolOption('THB', 'THB — Thai baht'),
  ToolOption('ZAR', 'ZAR — South African rand'),
  ToolOption('ILS', 'ILS — Israeli new shekel'),
  ToolOption('ISK', 'ISK — Icelandic krona'),
];

final List<CalculatorTool> financeTools = [
  _calc(
    'loan-payment',
    'Loan payment calculator',
    'Periodic payment, total paid, and interest for a fixed-rate loan.',
    Icons.account_balance_wallet_rounded,
    [
      _n('principal', 'Loan amount', 250000, unit: r'$'),
      _n('downPayment', 'Down payment', 25000, unit: r'$'),
      _n('rate', 'Annual interest rate', 6.5, unit: '%'),
      _n('years', 'Loan term', 30, unit: 'years'),
      _s('payments', 'Payments per year', '12', [
        _o('12', 'Monthly (12)'),
        _o('26', 'Biweekly (26)'),
        _o('52', 'Weekly (52)'),
      ]),
    ],
    (values) {
      final price = _positive(values, 'principal', 'Loan amount');
      final downPayment = _positive(
        values,
        'downPayment',
        'Down payment',
        zero: true,
      );
      if (downPayment >= price) {
        throw const FormatException(
          'Down payment must be less than the loan amount.',
        );
      }
      final principal = price - downPayment;
      final annualRate =
          _positive(values, 'rate', 'Interest rate', zero: true) / 100;
      final years = _positive(values, 'years', 'Loan term');
      final payments = _positive(values, 'payments', 'Payments per year');
      final count = (years * payments).round();
      final rate = annualRate / payments;
      final growth = math.pow(1 + rate, count).toDouble();
      final payment = rate == 0
          ? principal / count
          : principal * rate * growth / (growth - 1);
      final total = payment * count;
      return ToolResult(
        primary: payment,
        unit: r'$ per payment',
        latex: rate == 0
            ? '\\frac{${_compact(principal)}}{$count}'
            : '\\frac{${_compact(principal)}\\times${_compact(rate)}(1+${_compact(rate)})^{$count}}{(1+${_compact(rate)})^{$count}-1}',
        details: [
          ResultDetail('Amount financed', principal, prefix: r'$'),
          ResultDetail('Down payment', downPayment, prefix: r'$'),
          ResultDetail('Total paid', total, prefix: r'$'),
          ResultDetail('Total interest', total - principal, prefix: r'$'),
          ResultDetail('Payments', count),
        ],
        note:
            'Estimate only. Fees, taxes, insurance, and lender-specific rules are not included.',
      );
    },
    currency: true,
  ),
  _calc(
    'mortgage-payment',
    'Mortgage payment calculator',
    'Principal, interest, escrow, PMI, HOA, and total monthly housing cost.',
    Icons.house_rounded,
    [
      _n('price', 'Home price', 400000, unit: r'$'),
      _n('downPayment', 'Down payment', 80000, unit: r'$'),
      _n('rate', 'Annual interest rate', 6.5, unit: '%'),
      _n('years', 'Loan term', 30, unit: 'years'),
      _n('propertyTax', 'Annual property tax', 4800, unit: r'$/year'),
      _n('insurance', 'Annual home insurance', 1800, unit: r'$/year'),
      _n('pmiRate', 'Annual PMI rate', 0.5, unit: '%'),
      _n('hoa', 'Monthly HOA dues', 0, unit: r'$/month'),
    ],
    (values) {
      final price = _positive(values, 'price', 'Home price');
      final down = _positive(values, 'downPayment', 'Down payment', zero: true);
      if (down >= price) {
        throw const FormatException(
          'Down payment must be less than the home price.',
        );
      }
      final principal = price - down;
      final annualRate =
          _positive(values, 'rate', 'Interest rate', zero: true) / 100;
      final years = _positive(values, 'years', 'Loan term');
      final count = (years * 12).round();
      final monthlyRate = annualRate / 12;
      final growth = math.pow(1 + monthlyRate, count).toDouble();
      final principalAndInterest = monthlyRate == 0
          ? principal / count
          : principal * monthlyRate * growth / (growth - 1);
      final propertyTax =
          _positive(values, 'propertyTax', 'Property tax', zero: true) / 12;
      final insurance =
          _positive(values, 'insurance', 'Home insurance', zero: true) / 12;
      final pmi =
          principal *
          (_positive(values, 'pmiRate', 'PMI rate', zero: true) / 100) /
          12;
      final hoa = _positive(values, 'hoa', 'HOA dues', zero: true);
      final escrow = propertyTax + insurance;
      final total = principalAndInterest + escrow + pmi + hoa;
      final lifetimeInterest = principalAndInterest * count - principal;
      final lifetimeLoanCost = principal + lifetimeInterest + pmi * count;
      return ToolResult(
        primary: total,
        unit: r'$ per month',
        latex:
            '\\mathrm{P\\&I}+\\frac{\\mathrm{tax}+\\mathrm{insurance}}{12}+\\mathrm{PMI}+\\mathrm{HOA}',
        details: [
          ResultDetail(
            'Principal & interest',
            principalAndInterest,
            prefix: r'$',
          ),
          ResultDetail('Monthly escrow', escrow, prefix: r'$'),
          ResultDetail('Property tax', propertyTax, prefix: r'$'),
          ResultDetail('Home insurance', insurance, prefix: r'$'),
          ResultDetail('PMI', pmi, prefix: r'$'),
          ResultDetail('HOA', hoa, prefix: r'$'),
          ResultDetail('Amount financed', principal, prefix: r'$'),
          ResultDetail('Total interest', lifetimeInterest, prefix: r'$'),
          ResultDetail('Lifetime cost of loan', lifetimeLoanCost, prefix: r'$'),
        ],
        note:
            'Estimate only. Closing costs, lender fees, tax changes, insurance changes, and escrow adjustments are not included. Set PMI or HOA to zero when not applicable.',
      );
    },
    currency: true,
  ),
  _calc(
    'currency',
    'Currency converter',
    'Convert money using the latest available reference exchange rate.',
    Icons.currency_exchange_rounded,
    [
      _n('amount', 'Amount', 100, unit: 'money'),
      _s('from', 'From currency', 'USD', _currencies),
      _s('to', 'To currency', 'EUR', _currencies),
    ],
    (_) => throw const FormatException('A live exchange rate is required.'),
    currency: true,
    asyncType: 'currency',
    note:
        'Latest available reference rates are loaded from Frankfurter. Market providers, banks, and card issuers may add spreads or fees.',
  ),
  _calc(
    'compound-interest',
    'Compound interest calculator',
    'Project growth with compounding and monthly contributions.',
    Icons.trending_up_rounded,
    [
      _n('principal', 'Starting balance', 10000, unit: r'$'),
      _n('rate', 'Annual return', 7, unit: '%'),
      _n('years', 'Time horizon', 10, unit: 'years'),
      _s('frequency', 'Compounding', '12', [
        _o('1', 'Annually'),
        _o('4', 'Quarterly'),
        _o('12', 'Monthly'),
        _o('365', 'Daily'),
      ]),
      _n('contribution', 'Monthly contribution', 250, unit: r'$'),
    ],
    (values) {
      final principal = _positive(
        values,
        'principal',
        'Starting balance',
        zero: true,
      );
      final annual =
          _positive(values, 'rate', 'Annual return', zero: true) / 100;
      final years = _positive(values, 'years', 'Time horizon');
      final n = _positive(values, 'frequency', 'Compounding frequency');
      final contribution = _positive(
        values,
        'contribution',
        'Monthly contribution',
        zero: true,
      );
      final months = (years * 12).round();
      final initialGrowth = principal * math.pow(1 + annual / n, n * years);
      final monthlyRate = annual == 0
          ? 0
          : math.pow(1 + annual / n, n / 12).toDouble() - 1;
      final contributionGrowth = monthlyRate == 0
          ? contribution * months
          : contribution *
                (math.pow(1 + monthlyRate, months) - 1) /
                monthlyRate;
      final future = initialGrowth + contributionGrowth;
      final deposited = principal + contribution * months;
      return ToolResult(
        primary: future,
        unit: r'$ future value',
        latex:
            '${_compact(principal)}(1+\\frac{${_compact(annual)}}{${_compact(n)}})^{${_compact(n * years)}}+\\mathrm{contributions}',
        details: [
          ResultDetail('Total contributed', deposited, prefix: r'$'),
          ResultDetail('Estimated growth', future - deposited, prefix: r'$'),
          ResultDetail('Months', months),
        ],
        note:
            'Mathematical projection only; actual returns and contribution timing vary.',
      );
    },
  ),
  _calc(
    'simple-interest',
    'Simple interest calculator',
    'Interest that does not compound.',
    Icons.percent_rounded,
    [
      _n('principal', 'Principal', 5000, unit: r'$'),
      _n('rate', 'Annual rate', 5, unit: '%'),
      _n('years', 'Time', 3, unit: 'years'),
    ],
    (values) {
      final p = _positive(values, 'principal', 'Principal', zero: true);
      final r = _positive(values, 'rate', 'Rate', zero: true) / 100;
      final t = _positive(values, 'years', 'Time', zero: true);
      final interest = p * r * t;
      return ToolResult(
        primary: p + interest,
        unit: r'$ total',
        latex:
            '${_compact(p)}+${_compact(p)}\\times${_compact(r)}\\times${_compact(t)}',
        details: [
          ResultDetail('Interest', interest, prefix: r'$'),
          ResultDetail('Principal', p, prefix: r'$'),
        ],
      );
    },
  ),
  _calc(
    'savings-goal',
    'Savings goal calculator',
    'Monthly deposit needed to reach a future balance.',
    Icons.savings_rounded,
    [
      _n('goal', 'Target balance', 50000, unit: r'$'),
      _n('current', 'Current savings', 5000, unit: r'$'),
      _n('rate', 'Annual return', 4, unit: '%'),
      _n('years', 'Time available', 5, unit: 'years'),
    ],
    (values) {
      final goal = _positive(values, 'goal', 'Target balance');
      final current = _positive(
        values,
        'current',
        'Current savings',
        zero: true,
      );
      final rate =
          _positive(values, 'rate', 'Annual return', zero: true) / 1200;
      final months = math.max(
        1,
        (_positive(values, 'years', 'Time available') * 12).round(),
      );
      final currentFuture = current * math.pow(1 + rate, months);
      final gap = math.max(0, goal - currentFuture);
      final payment = rate == 0
          ? gap / months
          : gap * rate / (math.pow(1 + rate, months) - 1);
      return ToolResult(
        primary: payment,
        unit: r'$ per month',
        latex: rate == 0
            ? '\\frac{${_compact(gap)}}{$months}'
            : '\\frac{${_compact(gap)}\\times${_compact(rate)}}{(1+${_compact(rate)})^{$months}-1}',
        details: [
          ResultDetail(
            'Current savings at goal date',
            currentFuture,
            prefix: r'$',
          ),
          ResultDetail('New deposits', payment * months, prefix: r'$'),
          ResultDetail('Months', months),
        ],
        note: 'Assumes a constant return and end-of-month deposits.',
      );
    },
  ),
  _calc(
    'discount',
    'Discount calculator',
    'Sale price and savings from sequential discounts.',
    Icons.local_offer_rounded,
    [
      _n('price', 'Original price', 120, unit: r'$'),
      _n('first', 'First discount', 25, unit: '%'),
      _n('second', 'Second discount', 0, unit: '%'),
    ],
    (values) {
      final price = _positive(values, 'price', 'Original price', zero: true);
      final first =
          (_positive(values, 'first', 'First discount', zero: true) / 100)
              .clamp(0, 1);
      final second =
          (_positive(values, 'second', 'Second discount', zero: true) / 100)
              .clamp(0, 1);
      final sale = price * (1 - first) * (1 - second);
      return ToolResult(
        primary: sale,
        unit: r'$ sale price',
        latex:
            '${_compact(price)}(1-${_compact(first)})(1-${_compact(second)})',
        details: [
          ResultDetail('You save', price - sale, prefix: r'$'),
          ResultDetail(
            'Effective discount',
            price == 0 ? 0 : (1 - sale / price) * 100,
            suffix: '%',
          ),
        ],
      );
    },
  ),
  _calc(
    'sales-tax',
    'Sales tax calculator',
    'Add tax or work backward from a tax-inclusive total.',
    Icons.receipt_long_rounded,
    [
      _n('amount', 'Amount', 100, unit: r'$'),
      _n('rate', 'Tax rate', 8.25, unit: '%'),
      _s('direction', 'Amount entered is', 'pre', [
        _o('pre', 'Before tax'),
        _o('total', 'Tax included'),
      ]),
    ],
    (values) {
      final amount = _positive(values, 'amount', 'Amount', zero: true);
      final rate = _positive(values, 'rate', 'Tax rate', zero: true) / 100;
      final included = values['direction'] == 'total';
      final before = included ? amount / (1 + rate) : amount;
      final total = included ? amount : amount * (1 + rate);
      return ToolResult(
        primary: total,
        unit: r'$ total',
        latex: included
            ? _compact(amount)
            : '${_compact(amount)}(1+${_compact(rate)})',
        details: [
          ResultDetail('Before tax', before, prefix: r'$'),
          ResultDetail('Tax', total - before, prefix: r'$'),
        ],
      );
    },
  ),
  _calc(
    'tip-split',
    'Tip & split calculator',
    'Calculate a tip and divide the final bill.',
    Icons.restaurant_rounded,
    [
      _n('bill', 'Bill amount', 86.4, unit: r'$'),
      _n('tip', 'Tip', 20, unit: '%'),
      _n('people', 'People', 3),
    ],
    (values) {
      final bill = _positive(values, 'bill', 'Bill', zero: true);
      final tipRate = _positive(values, 'tip', 'Tip', zero: true) / 100;
      final people = math.max(1, _positive(values, 'people', 'People').round());
      final tip = bill * tipRate;
      final total = bill + tip;
      return ToolResult(
        primary: total / people,
        unit: r'$ per person',
        latex: '\\frac{${_compact(bill)}+${_compact(tip)}}{$people}',
        details: [
          ResultDetail('Tip', tip, prefix: r'$'),
          ResultDetail('Bill total', total, prefix: r'$'),
          ResultDetail('People', people),
        ],
      );
    },
  ),
  _calc(
    'profit-margin',
    'Profit margin calculator',
    'Profit, margin, and markup from cost and selling price.',
    Icons.storefront_rounded,
    [
      _n('cost', 'Cost', 45, unit: r'$'),
      _n('revenue', 'Selling price', 80, unit: r'$'),
    ],
    (values) {
      final cost = _positive(values, 'cost', 'Cost', zero: true);
      final revenue = _positive(values, 'revenue', 'Selling price', zero: true);
      final profit = revenue - cost;
      final margin = revenue == 0 ? 0 : profit / revenue * 100;
      final markup = cost == 0 ? 0 : profit / cost * 100;
      return ToolResult(
        primary: margin,
        unit: '% margin',
        latex:
            '\\frac{${_compact(revenue)}-${_compact(cost)}}{${_compact(revenue == 0 ? 1 : revenue)}}\\times100',
        details: [
          ResultDetail('Profit', profit, prefix: r'$'),
          ResultDetail('Markup', markup, suffix: '%'),
          ResultDetail('Selling price', revenue, prefix: r'$'),
        ],
      );
    },
  ),
  _calc(
    'break-even',
    'Break-even calculator',
    'Units needed to cover fixed and variable costs.',
    Icons.balance_rounded,
    [
      _n('fixed', 'Fixed costs', 10000, unit: r'$'),
      _n('price', 'Price per unit', 75, unit: r'$'),
      _n('variable', 'Variable cost per unit', 40, unit: r'$'),
    ],
    (values) {
      final fixed = _positive(values, 'fixed', 'Fixed costs', zero: true);
      final price = _positive(values, 'price', 'Price per unit');
      final variable = _positive(
        values,
        'variable',
        'Variable cost',
        zero: true,
      );
      if (price <= variable)
        throw const FormatException(
          'Price must be greater than variable cost.',
        );
      final exact = fixed / (price - variable);
      return ToolResult(
        primary: exact.ceil(),
        unit: 'whole units',
        latex:
            '\\frac{${_compact(fixed)}}{${_compact(price)}-${_compact(variable)}}',
        details: [
          ResultDetail('Exact break-even', exact, suffix: ' units'),
          ResultDetail('Contribution margin', price - variable, prefix: r'$'),
          ResultDetail(
            'Revenue at break-even',
            exact.ceil() * price,
            prefix: r'$',
          ),
        ],
      );
    },
  ),
];

final List<CalculatorTool> healthTools = [
  _calc(
    'bmi',
    'BMI calculator',
    'Body mass index from metric or imperial height and weight.',
    Icons.favorite_rounded,
    [
      _s('system', 'Units', 'metric', [
        _o('metric', 'Metric'),
        _o('imperial', 'US / Imperial'),
      ], segmented: true),
      _n(
        'weightKg',
        'Weight',
        72,
        unit: 'kg',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'heightCm',
        'Height',
        175,
        unit: 'cm',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'weightLb',
        'Weight',
        159,
        unit: 'lb',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n(
        'heightFt',
        'Height — feet',
        5,
        unit: 'ft',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n(
        'heightInches',
        'Height — inches',
        9,
        unit: 'in',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
    ],
    (values) {
      final metric = values['system'] != 'imperial';
      final weight = metric
          ? _positive(values, 'weightKg', 'Weight')
          : _positive(values, 'weightLb', 'Weight') * 0.45359237;
      final heightInches = metric
          ? 0.0
          : _positive(values, 'heightFt', 'Height in feet', zero: true) * 12 +
                _positive(
                  values,
                  'heightInches',
                  'Height in inches',
                  zero: true,
                );
      if (!metric && heightInches <= 0) {
        throw const FormatException('Height must be greater than zero.');
      }
      final height = metric
          ? _positive(values, 'heightCm', 'Height') / 100
          : heightInches * 0.0254;
      final bmi = weight / (height * height);
      final category = bmi < 18.5
          ? 'Below standard range'
          : bmi < 25
          ? 'Standard range'
          : bmi < 30
          ? 'Above standard range'
          : 'High range';
      return ToolResult(
        primary: bmi,
        unit: 'kg/m²',
        latex: '\\frac{${_compact(weight)}}{${_compact(height)}^2}',
        details: [
          ResultDetail('Screening category', category),
          metric
              ? ResultDetail('Height', height, suffix: ' m')
              : ResultDetail(
                  'Height',
                  '${(heightInches / 12).floor()} ft ${(heightInches % 12).toStringAsFixed(heightInches % 12 == 0 ? 0 : 1)} in',
                ),
        ],
        note: 'BMI is a population screening measure, not a diagnosis.',
      );
    },
    note:
        'For general informational use only; discuss health decisions with a qualified clinician.',
  ),
  _calc(
    'bmr',
    'BMR calculator',
    'Resting energy estimate with the Mifflin–St Jeor equation.',
    Icons.local_fire_department_rounded,
    [
      _s('sex', 'Equation', 'male', [
        _o('male', 'Male constant (+5)'),
        _o('female', 'Female constant (−161)'),
      ]),
      _s('system', 'Units', 'metric', [
        _o('metric', 'Metric'),
        _o('imperial', 'US / Imperial'),
      ], segmented: true),
      _n('age', 'Age', 30, unit: 'years'),
      _n(
        'weightKg',
        'Weight',
        72,
        unit: 'kg',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'heightCm',
        'Height',
        175,
        unit: 'cm',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'weightLb',
        'Weight',
        159,
        unit: 'lb',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n(
        'heightIn',
        'Height',
        69,
        unit: 'in',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
    ],
    (values) {
      final metric = values['system'] != 'imperial';
      final weight = metric
          ? _positive(values, 'weightKg', 'Weight')
          : _positive(values, 'weightLb', 'Weight') * 0.45359237;
      final height = metric
          ? _positive(values, 'heightCm', 'Height')
          : _positive(values, 'heightIn', 'Height') * 2.54;
      final age = _positive(values, 'age', 'Age');
      final constant = values['sex'] == 'male' ? 5 : -161;
      final bmr = 10 * weight + 6.25 * height - 5 * age + constant;
      return ToolResult(
        primary: bmr,
        unit: 'kcal/day',
        latex:
            '10(${_compact(weight)})+6.25(${_compact(height)})-5(${_compact(age)})+$constant',
        details: const [ResultDetail('Equation', 'Mifflin–St Jeor')],
        note: 'This estimate is not a personalized nutrition prescription.',
      );
    },
  ),
  _calc(
    'tdee',
    'Daily energy estimate',
    'Apply an activity factor to resting energy use.',
    Icons.directions_run_rounded,
    [
      _n('bmr', 'Resting energy', 1650, unit: 'kcal/day'),
      _s('activity', 'Activity factor', '1.55', [
        _o('1.2', 'Sedentary (1.20)'),
        _o('1.375', 'Light (1.375)'),
        _o('1.55', 'Moderate (1.55)'),
        _o('1.725', 'Very active (1.725)'),
        _o('1.9', 'Extra active (1.90)'),
      ]),
    ],
    (values) {
      final bmr = _positive(values, 'bmr', 'Resting energy');
      final factor = _positive(values, 'activity', 'Activity factor');
      return ToolResult(
        primary: bmr * factor,
        unit: 'kcal/day',
        latex: '${_compact(bmr)}\\times${_compact(factor)}',
        details: [
          ResultDetail('Resting estimate', bmr, suffix: ' kcal/day'),
          ResultDetail('Activity factor', factor),
        ],
        note: 'Activity multipliers are broad estimates.',
      );
    },
  ),
  _calc(
    'body-surface-area',
    'Body surface area calculator',
    'Mosteller body surface area estimate.',
    Icons.accessibility_new_rounded,
    [
      _s('system', 'Units', 'metric', [
        _o('metric', 'Metric'),
        _o('imperial', 'US / Imperial'),
      ], segmented: true),
      _n(
        'weightKg',
        'Weight',
        72,
        unit: 'kg',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'heightCm',
        'Height',
        175,
        unit: 'cm',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'weightLb',
        'Weight',
        159,
        unit: 'lb',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n(
        'heightIn',
        'Height',
        69,
        unit: 'in',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
    ],
    (values) {
      final metric = values['system'] != 'imperial';
      final weight = metric
          ? _positive(values, 'weightKg', 'Weight')
          : _positive(values, 'weightLb', 'Weight') * 0.45359237;
      final height = metric
          ? _positive(values, 'heightCm', 'Height')
          : _positive(values, 'heightIn', 'Height') * 2.54;
      final result = math.sqrt(height * weight / 3600);
      return ToolResult(
        primary: result,
        unit: 'm²',
        latex:
            '\\sqrt{\\frac{${_compact(height)}\\times${_compact(weight)}}{3600}}',
        details: const [ResultDetail('Formula', 'Mosteller')],
        note: 'Clinical calculations require professional verification.',
      );
    },
  ),
  _calc(
    'pace',
    'Running pace calculator',
    'Pace and average speed from distance and finish time.',
    Icons.timer_rounded,
    [
      _s('system', 'Units', 'metric', [
        _o('metric', 'Kilometers'),
        _o('imperial', 'Miles'),
      ], segmented: true),
      _n(
        'distanceKm',
        'Distance',
        5,
        unit: 'km',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'distanceMi',
        'Distance',
        3.1,
        unit: 'mi',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n('minutes', 'Finish time', 28, unit: 'minutes'),
    ],
    (values) {
      final metric = values['system'] != 'imperial';
      final distance = _positive(
        values,
        metric ? 'distanceKm' : 'distanceMi',
        'Distance',
      );
      final minutes = _positive(values, 'minutes', 'Finish time');
      final pace = minutes / distance;
      var whole = pace.floor();
      var seconds = ((pace - whole) * 60).round();
      if (seconds == 60) {
        whole += 1;
        seconds = 0;
      }
      return ToolResult(
        primary: '$whole:${seconds.toString().padLeft(2, '0')}',
        unit: metric ? 'min/km' : 'min/mi',
        latex: '\\frac{${_compact(minutes)}}{${_compact(distance)}}',
        details: [
          ResultDetail(
            'Average speed',
            distance / (minutes / 60),
            suffix: metric ? ' km/h' : ' mph',
          ),
          ResultDetail(
            'Raw pace',
            pace,
            suffix: metric ? ' min/km' : ' min/mi',
          ),
        ],
      );
    },
  ),
  _calc(
    'target-heart-rate',
    'Target heart rate calculator',
    'Training zone estimate with the heart-rate reserve method.',
    Icons.monitor_heart_rounded,
    [
      _n('age', 'Age', 35, unit: 'years'),
      _n('resting', 'Resting heart rate', 65, unit: 'bpm'),
      _n('low', 'Low intensity', 60, unit: '%'),
      _n('high', 'High intensity', 80, unit: '%'),
    ],
    (values) {
      final age = _positive(values, 'age', 'Age');
      final resting = _positive(values, 'resting', 'Resting heart rate');
      final low = (_positive(values, 'low', 'Low intensity') / 100).clamp(0, 1);
      final high = (_positive(values, 'high', 'High intensity') / 100).clamp(
        low,
        1,
      );
      final maximum = 220 - age;
      final reserve = maximum - resting;
      final lowRate = reserve * low + resting;
      final highRate = reserve * high + resting;
      return ToolResult(
        primary: '${lowRate.round()}–${highRate.round()}',
        unit: 'bpm zone',
        latex:
            '(${_compact(maximum)}-${_compact(resting)})${_compact(low)}+${_compact(resting)}',
        details: [
          ResultDetail('Estimated maximum', maximum, suffix: ' bpm'),
          ResultDetail('Heart-rate reserve', reserve, suffix: ' bpm'),
        ],
        note: 'Age-based estimate only, not medical advice.',
      );
    },
  ),
];

({
  List<double> sides,
  List<double> angles,
  double area,
  double perimeter,
  String triangleType,
})
_solveTriangle(Map<String, String> values) {
  double? read(String id, String label) {
    final raw = (values[id] ?? '').trim();
    return raw.isEmpty ? null : _positive(values, id, label);
  }

  final sides = <double?>[
    read('sideA', 'Side a'),
    read('sideB', 'Side b'),
    read('sideC', 'Side c'),
  ];
  final angles = <double?>[
    read('angleA', 'Angle A'),
    read('angleB', 'Angle B'),
    read('angleC', 'Angle C'),
  ];
  const tolerance = 1e-8;
  double radians(double degrees) => degrees * math.pi / 180;
  double degrees(double radiansValue) => radiansValue * 180 / math.pi;
  double cosineAngle(double opposite, double first, double second) => degrees(
    math.acos(
      ((first * first + second * second - opposite * opposite) /
              (2 * first * second))
          .clamp(-1.0, 1.0),
    ),
  );

  if (angles.any((value) => value != null && (value <= 0 || value >= 180))) {
    throw const FormatException('Known angles must be between 0° and 180°.');
  }
  for (var iteration = 0; iteration < 12; iteration += 1) {
    var changed = false;
    final knownAngles = <int>[
      for (var index = 0; index < 3; index += 1)
        if (angles[index] != null) index,
    ];
    if (knownAngles.length == 2) {
      final missing = <int>[
        0,
        1,
        2,
      ].firstWhere((index) => angles[index] == null);
      angles[missing] = 180 - angles[knownAngles[0]]! - angles[knownAngles[1]]!;
      changed = true;
    }
    if (sides.every((value) => value != null)) {
      angles[0] ??= cosineAngle(sides[0]!, sides[1]!, sides[2]!);
      angles[1] ??= cosineAngle(sides[1]!, sides[0]!, sides[2]!);
      angles[2] ??= 180 - angles[0]! - angles[1]!;
      changed = true;
    }
    const sas = <(int, int, int)>[(0, 1, 2), (0, 2, 1), (1, 2, 0)];
    for (final pair in sas) {
      final first = pair.$1;
      final second = pair.$2;
      final missing = pair.$3;
      if (sides[first] != null &&
          sides[second] != null &&
          sides[missing] == null &&
          angles[missing] != null) {
        sides[missing] = math.sqrt(
          math.max(
            0,
            sides[first]! * sides[first]! +
                sides[second]! * sides[second]! -
                2 *
                    sides[first]! *
                    sides[second]! *
                    math.cos(radians(angles[missing]!)),
          ),
        );
        changed = true;
      }
    }
    int? knownPair;
    for (var index = 0; index < 3; index += 1) {
      if (sides[index] != null && angles[index] != null) {
        knownPair = index;
        break;
      }
    }
    if (knownPair != null) {
      for (var index = 0; index < 3; index += 1) {
        if (index == knownPair) continue;
        if (angles[index] != null && sides[index] == null) {
          sides[index] =
              sides[knownPair]! *
              math.sin(radians(angles[index]!)) /
              math.sin(radians(angles[knownPair]!));
          changed = true;
        } else if (sides[index] != null && angles[index] == null) {
          final ratio =
              sides[index]! *
              math.sin(radians(angles[knownPair]!)) /
              sides[knownPair]!;
          if (ratio <= 1 + tolerance) {
            final candidate = degrees(math.asin(ratio.clamp(-1.0, 1.0)));
            if (candidate > 0 && candidate + angles[knownPair]! < 180) {
              angles[index] = candidate;
              changed = true;
            }
          }
        }
      }
    }
    if (!changed) break;
  }

  if (sides.any((value) => value == null) ||
      angles.any((value) => value == null)) {
    throw const FormatException('More data needed for triangle calculation.');
  }
  final solvedSides = sides.cast<double>();
  final solvedAngles = angles.cast<double>();
  if ((solvedAngles.reduce((a, b) => a + b) - 180).abs() > 1e-5) {
    throw const FormatException('The angles must total 180°.');
  }
  if (solvedSides[0] + solvedSides[1] <= solvedSides[2] ||
      solvedSides[0] + solvedSides[2] <= solvedSides[1] ||
      solvedSides[1] + solvedSides[2] <= solvedSides[0]) {
    throw const FormatException('Those side lengths cannot form a triangle.');
  }
  final perimeter = solvedSides.reduce((a, b) => a + b);
  final semi = perimeter / 2;
  final area = math.sqrt(
    math.max(
      0,
      semi *
          (semi - solvedSides[0]) *
          (semi - solvedSides[1]) *
          (semi - solvedSides[2]),
    ),
  );
  final largestSide = solvedSides.reduce(math.max);
  final sideTolerance = largestSide * 1e-7;
  final equalAB = (solvedSides[0] - solvedSides[1]).abs() <= sideTolerance;
  final equalAC = (solvedSides[0] - solvedSides[2]).abs() <= sideTolerance;
  final equalBC = (solvedSides[1] - solvedSides[2]).abs() <= sideTolerance;
  final sideType = equalAB && equalAC
      ? 'equilateral'
      : equalAB || equalAC || equalBC
      ? 'isosceles'
      : 'scalene';
  final largestAngle = solvedAngles.reduce(math.max);
  final angleType = (largestAngle - 90).abs() <= 1e-6
      ? 'right'
      : largestAngle > 90
      ? 'obtuse'
      : 'acute';
  final triangleType = sideType == 'equilateral'
      ? 'Equilateral triangle'
      : '${angleType[0].toUpperCase()}${angleType.substring(1)} $sideType triangle';
  return (
    sides: solvedSides,
    angles: solvedAngles,
    area: area,
    perimeter: perimeter,
    triangleType: triangleType,
  );
}

String _polygonName(int sides) => switch (sides) {
  3 => 'Triangle',
  4 => 'Square',
  5 => 'Pentagon',
  6 => 'Hexagon',
  7 => 'Heptagon',
  8 => 'Octagon',
  9 => 'Nonagon',
  10 => 'Decagon',
  11 => 'Hendecagon',
  12 => 'Dodecagon',
  13 => 'Tridecagon',
  14 => 'Tetradecagon',
  15 => 'Pentadecagon',
  16 => 'Hexadecagon',
  17 => 'Heptadecagon',
  18 => 'Octadecagon',
  19 => 'Enneadecagon',
  20 => 'Icosagon',
  _ => '$sides-gon',
};

final List<CalculatorTool> geometryTools = [
  _calc(
    'circle',
    'Circle calculator',
    'Area, circumference, and diameter from radius.',
    Icons.circle_outlined,
    [_n('radius', 'Radius', 5, unit: 'units')],
    (values) {
      final r = _positive(values, 'radius', 'Radius', zero: true);
      return ToolResult(
        primary: math.pi * r * r,
        unit: 'square units',
        latex: '\\pi(${_compact(r)})^2',
        details: [
          ResultDetail('Circumference', 2 * math.pi * r, suffix: ' units'),
          ResultDetail('Diameter', 2 * r, suffix: ' units'),
        ],
      );
    },
  ),
  _calc(
    'rectangle',
    'Rectangle calculator',
    'Area, perimeter, and diagonal.',
    Icons.crop_square_rounded,
    [
      _n('length', 'Length', 12, unit: 'units'),
      _n('width', 'Width', 8, unit: 'units'),
    ],
    (values) {
      final l = _positive(values, 'length', 'Length', zero: true);
      final w = _positive(values, 'width', 'Width', zero: true);
      return ToolResult(
        primary: l * w,
        unit: 'square units',
        latex: '${_compact(l)}\\times${_compact(w)}',
        details: [
          ResultDetail('Perimeter', 2 * (l + w), suffix: ' units'),
          ResultDetail('Diagonal', math.sqrt(l * l + w * w), suffix: ' units'),
        ],
      );
    },
  ),
  _calc(
    'triangle',
    'Standard triangle calculator',
    'Enter any sufficient combination of sides and angles; blank measurements are solved automatically.',
    Icons.change_history_rounded,
    [
      _n('sideA', 'Side a (opposite angle A)', 3, unit: 'units'),
      _n('sideB', 'Side b (opposite angle B)', 4, unit: 'units'),
      _n('sideC', 'Side c (opposite angle C)', 5, unit: 'units'),
      _n('angleA', 'Angle A', 36.86989765, unit: '°'),
      _n('angleB', 'Angle B', 53.13010235, unit: '°'),
      _n('angleC', 'Angle C', 90, unit: '°'),
    ],
    (values) {
      final solved = _solveTriangle(values);
      final a = solved.sides[0];
      final b = solved.sides[1];
      final c = solved.sides[2];
      return ToolResult(
        primary: solved.area,
        unit: 'square units',
        latex:
            '\\sqrt{${_compact(solved.perimeter / 2)}(${_compact(solved.perimeter / 2)}-${_compact(a)})(${_compact(solved.perimeter / 2)}-${_compact(b)})(${_compact(solved.perimeter / 2)}-${_compact(c)})}',
        details: [
          ResultDetail('Triangle type', solved.triangleType),
          ResultDetail('Side a', a, suffix: ' units'),
          ResultDetail('Side b', b, suffix: ' units'),
          ResultDetail('Side c', c, suffix: ' units'),
          ResultDetail('Angle A', solved.angles[0], suffix: '°'),
          ResultDetail('Angle B', solved.angles[1], suffix: '°'),
          ResultDetail('Angle C', solved.angles[2], suffix: '°'),
          ResultDetail('Perimeter', solved.perimeter, suffix: ' units'),
          ResultDetail('Area', solved.area, suffix: ' square units'),
        ],
        meta: {
          'sides': solved.sides,
          'angles': solved.angles,
          'area': solved.area,
          'triangleType': solved.triangleType,
        },
      );
    },
  ),
  _calc(
    'trapezoid',
    'Trapezoid calculator',
    'Area from two parallel bases and height.',
    Icons.architecture_rounded,
    [
      _n('a', 'First base', 8, unit: 'units'),
      _n('b', 'Second base', 12, unit: 'units'),
      _n('height', 'Height', 6, unit: 'units'),
    ],
    (values) {
      final a = _positive(values, 'a', 'First base', zero: true);
      final b = _positive(values, 'b', 'Second base', zero: true);
      final h = _positive(values, 'height', 'Height', zero: true);
      return ToolResult(
        primary: (a + b) * h / 2,
        unit: 'square units',
        latex: '\\frac{(${_compact(a)}+${_compact(b)})${_compact(h)}}{2}',
        details: [ResultDetail('Average base', (a + b) / 2, suffix: ' units')],
      );
    },
  ),
  _calc(
    'sphere',
    'Sphere calculator',
    'Volume and surface area from radius.',
    Icons.language_rounded,
    [_n('radius', 'Radius', 4, unit: 'units')],
    (values) {
      final r = _positive(values, 'radius', 'Radius', zero: true);
      return ToolResult(
        primary: 4 / 3 * math.pi * math.pow(r, 3),
        unit: 'cubic units',
        latex: '\\frac{4}{3}\\pi(${_compact(r)})^3',
        details: [
          ResultDetail(
            'Surface area',
            4 * math.pi * r * r,
            suffix: ' square units',
          ),
          ResultDetail('Diameter', 2 * r, suffix: ' units'),
        ],
      );
    },
  ),
  _calc(
    'cylinder',
    'Cylinder calculator',
    'Volume and surface area from radius and height.',
    Icons.battery_full_rounded,
    [
      _n('radius', 'Radius', 4, unit: 'units'),
      _n('height', 'Height', 10, unit: 'units'),
    ],
    (values) {
      final r = _positive(values, 'radius', 'Radius', zero: true);
      final h = _positive(values, 'height', 'Height', zero: true);
      return ToolResult(
        primary: math.pi * r * r * h,
        unit: 'cubic units',
        latex: '\\pi(${_compact(r)})^2(${_compact(h)})',
        details: [
          ResultDetail(
            'Surface area',
            2 * math.pi * r * (r + h),
            suffix: ' square units',
          ),
          ResultDetail('Base area', math.pi * r * r, suffix: ' square units'),
        ],
      );
    },
  ),
  _calc(
    'cone',
    'Cone calculator',
    'Volume, slant height, and total surface area.',
    Icons.change_history_rounded,
    [
      _n('radius', 'Radius', 4, unit: 'units'),
      _n('height', 'Height', 9, unit: 'units'),
    ],
    (values) {
      final r = _positive(values, 'radius', 'Radius', zero: true);
      final h = _positive(values, 'height', 'Height', zero: true);
      final slant = math.sqrt(r * r + h * h);
      return ToolResult(
        primary: math.pi * r * r * h / 3,
        unit: 'cubic units',
        latex: '\\frac{\\pi(${_compact(r)})^2(${_compact(h)})}{3}',
        details: [
          ResultDetail('Slant height', slant, suffix: ' units'),
          ResultDetail(
            'Surface area',
            math.pi * r * (r + slant),
            suffix: ' square units',
          ),
        ],
      );
    },
  ),
  _calc(
    'rectangular-prism',
    'Rectangular prism calculator',
    'Volume, surface area, and space diagonal.',
    Icons.view_in_ar_rounded,
    [
      _n('length', 'Length', 10, unit: 'units'),
      _n('width', 'Width', 6, unit: 'units'),
      _n('height', 'Height', 4, unit: 'units'),
    ],
    (values) {
      final l = _positive(values, 'length', 'Length', zero: true);
      final w = _positive(values, 'width', 'Width', zero: true);
      final h = _positive(values, 'height', 'Height', zero: true);
      return ToolResult(
        primary: l * w * h,
        unit: 'cubic units',
        latex: '${_compact(l)}\\times${_compact(w)}\\times${_compact(h)}',
        details: [
          ResultDetail(
            'Surface area',
            2 * (l * w + l * h + w * h),
            suffix: ' square units',
          ),
          ResultDetail(
            'Diagonal',
            math.sqrt(l * l + w * w + h * h),
            suffix: ' units',
          ),
        ],
      );
    },
  ),
  _calc(
    'regular-polygon',
    'Regular polygon calculator',
    'Area and perimeter from side count and length.',
    Icons.hexagon_outlined,
    [
      _n('sides', 'Number of sides', 6),
      _n('length', 'Side length', 5, unit: 'units'),
    ],
    (values) {
      final sides = math.max(
        3,
        _positive(values, 'sides', 'Number of sides').round(),
      );
      final length = _positive(values, 'length', 'Side length', zero: true);
      final area = sides * length * length / (4 * math.tan(math.pi / sides));
      return ToolResult(
        primary: area,
        unit: 'square units',
        latex: '\\frac{$sides(${_compact(length)})^2}{4\\tan(\\pi/$sides)}',
        details: [
          ResultDetail('Shape name', _polygonName(sides)),
          ResultDetail('Perimeter', sides * length, suffix: ' units'),
          ResultDetail(
            'Interior angle',
            (sides - 2) * 180 / sides,
            suffix: '°',
          ),
        ],
      );
    },
  ),
];

final List<CalculatorTool> mathTools = [
  _calc(
    'percentage-of',
    'Percentage calculator',
    'Find a percentage of a value.',
    Icons.percent_rounded,
    [_n('percent', 'Percentage', 18, unit: '%'), _n('value', 'Of value', 240)],
    (values) {
      final percent = _number(values, 'percent', 'Percentage');
      final value = _number(values, 'value', 'Value');
      final answer = percent / 100 * value;
      return ToolResult(
        primary: answer,
        unit: 'result',
        latex: '\\frac{${_compact(percent)}}{100}\\times${_compact(value)}',
        details: [
          ResultDetail(
            'Fraction of original',
            value == 0 ? 'Undefined' : answer / value,
          ),
        ],
      );
    },
  ),
  _calc(
    'percentage-change',
    'Percentage change calculator',
    'Increase or decrease relative to a starting value.',
    Icons.show_chart_rounded,
    [_n('from', 'Starting value', 80), _n('to', 'New value', 104)],
    (values) {
      final from = _number(values, 'from', 'Starting value');
      final to = _number(values, 'to', 'New value');
      if (from == 0)
        throw const FormatException('Starting value cannot be zero.');
      final change = (to - from) / from.abs() * 100;
      return ToolResult(
        primary: change,
        unit: change >= 0 ? '% increase' : '% decrease',
        latex:
            '\\frac{${_compact(to)}-${_compact(from)}}{|${_compact(from)}|}\\times100',
        details: [
          ResultDetail('Absolute change', to - from),
          ResultDetail('Multiplier', to / from),
        ],
      );
    },
  ),
  _calc(
    'quadratic',
    'Quadratic equation solver',
    'Solve ax² + bx + c = 0.',
    Icons.functions_rounded,
    [
      _n('a', 'Coefficient a', 1),
      _n('b', 'Coefficient b', -3),
      _n('c', 'Coefficient c', 2),
    ],
    (values) {
      final a = _number(values, 'a', 'Coefficient a');
      final b = _number(values, 'b', 'Coefficient b');
      final c = _number(values, 'c', 'Coefficient c');
      if (a == 0) throw const FormatException('Coefficient a cannot be zero.');
      final discriminant = b * b - 4 * a * c;
      if (discriminant >= 0) {
        final first = (-b + math.sqrt(discriminant)) / (2 * a);
        final second = (-b - math.sqrt(discriminant)) / (2 * a);
        return ToolResult(
          primary: '${_compact(first)}, ${_compact(second)}',
          unit: 'real roots',
          latex:
              '\\frac{-(${_compact(b)})\\pm\\sqrt{${_compact(discriminant)}}}{2(${_compact(a)})}',
          details: [
            ResultDetail('x₁', first),
            ResultDetail('x₂', second),
            ResultDetail('Discriminant', discriminant),
          ],
          meta: {'a': a, 'b': b, 'c': c},
        );
      }
      final real = -b / (2 * a);
      final imaginary = math.sqrt(-discriminant) / (2 * a).abs();
      return ToolResult(
        primary: '${_compact(real)} ± ${_compact(imaginary)}i',
        unit: 'complex roots',
        latex: '${_compact(real)}\\pm${_compact(imaginary)}i',
        details: [
          ResultDetail('Real part', real),
          ResultDetail('Imaginary magnitude', imaginary),
          ResultDetail('Discriminant', discriminant),
        ],
        meta: {'a': a, 'b': b, 'c': c},
      );
    },
  ),
  _calc(
    'statistics',
    'Mean, median & mode',
    'Summarize a list of observations.',
    Icons.analytics_rounded,
    [
      _t(
        'values',
        'Values',
        '4, 7, 7, 9, 13, 15',
        numericList: true,
        help: 'Use commas or spaces between signed decimal values.',
      ),
    ],
    (values) {
      final list = _numberList(values['values'] ?? '');
      final sorted = [...list]..sort();
      final mean = list.reduce((a, b) => a + b) / list.length;
      final middle = sorted.length ~/ 2;
      final median = sorted.length.isOdd
          ? sorted[middle]
          : (sorted[middle - 1] + sorted[middle]) / 2;
      final counts = <double, int>{};
      for (final item in list) {
        counts[item] = (counts[item] ?? 0) + 1;
      }
      final maximum = counts.values.reduce(math.max);
      final modes = maximum == 1
          ? <double>[]
          : counts.entries
                .where((entry) => entry.value == maximum)
                .map((entry) => entry.key)
                .toList();
      return ToolResult(
        primary: mean,
        unit: 'mean',
        latex: '\\frac{${list.map(_compact).join('+')}}{${list.length}}',
        details: [
          ResultDetail('Median', median),
          ResultDetail(
            'Mode',
            modes.isEmpty ? 'No mode' : modes.map(_compact).join(', '),
          ),
          ResultDetail('Count', list.length),
          ResultDetail('Range', sorted.last - sorted.first),
        ],
      );
    },
  ),
  _calc(
    'standard-deviation',
    'Standard deviation calculator',
    'Population or sample spread for a list.',
    Icons.scatter_plot_rounded,
    [
      _t(
        'values',
        'Values',
        '10, 12, 13, 16, 19',
        numericList: true,
        help: 'Use commas or spaces between signed decimal values.',
      ),
      _s('type', 'Method', 'population', [
        _o('population', 'Population (N)'),
        _o('sample', 'Sample (N − 1)'),
      ]),
    ],
    (values) {
      final list = _numberList(values['values'] ?? '');
      final sample = values['type'] == 'sample';
      if (sample && list.length < 2)
        throw const FormatException('A sample needs at least two values.');
      final mean = list.reduce((a, b) => a + b) / list.length;
      final sum = list.fold<double>(
        0,
        (total, item) => total + math.pow(item - mean, 2),
      );
      final divisor = sample ? list.length - 1 : list.length;
      final variance = sum / divisor;
      return ToolResult(
        primary: math.sqrt(variance),
        unit: 'standard deviation',
        latex: '\\sqrt{\\frac{${_compact(sum)}}{$divisor}}',
        details: [
          ResultDetail('Variance', variance),
          ResultDetail('Mean', mean),
          ResultDetail('Count', list.length),
        ],
      );
    },
  ),
  _calc(
    'ratio-scale',
    'Ratio scaling calculator',
    'Scale a ratio while preserving proportion.',
    Icons.aspect_ratio_rounded,
    [_n('a', 'Ratio A', 16), _n('b', 'Ratio B', 9), _n('newA', 'New A', 1920)],
    (values) {
      final a = _number(values, 'a', 'Ratio A');
      final b = _number(values, 'b', 'Ratio B');
      final newA = _number(values, 'newA', 'New A');
      if (a == 0) throw const FormatException('Ratio A cannot be zero.');
      final newB = newA * b / a;
      return ToolResult(
        primary: newB,
        unit: 'scaled B',
        latex: '\\frac{${_compact(newA)}\\times${_compact(b)}}{${_compact(a)}}',
        details: [
          ResultDetail('Scale factor', newA / a),
          ResultDetail('Original ratio', '${_compact(a)}:${_compact(b)}'),
          ResultDetail('Scaled ratio', '${_compact(newA)}:${_compact(newB)}'),
        ],
      );
    },
  ),
  _calc(
    'gcd-lcm',
    'GCD & LCM calculator',
    'Greatest common divisor and least common multiple.',
    Icons.calculate_rounded,
    [_n('a', 'Integer A', 84), _n('b', 'Integer B', 126)],
    (values) {
      final a = _number(values, 'a', 'Integer A').truncate();
      final b = _number(values, 'b', 'Integer B').truncate();
      final divisor = _gcd(a, b);
      final multiple = divisor == 0 ? 0 : (a * b).abs() ~/ divisor;
      return ToolResult(
        primary: divisor,
        unit: 'greatest common divisor',
        latex: '\\gcd($a,$b)',
        details: [
          ResultDetail('Least common multiple', multiple),
          ResultDetail(
            'Reduced ratio',
            divisor == 0 ? '0:0' : '${a ~/ divisor}:${b ~/ divisor}',
          ),
        ],
      );
    },
  ),
  _calc(
    'combinations',
    'Combinations calculator',
    'Selections where order does not matter.',
    Icons.apps_rounded,
    [_n('n', 'Total items (n)', 10), _n('r', 'Selected items (r)', 3)],
    (values) {
      final n = _number(values, 'n', 'n').truncate();
      final r = _number(values, 'r', 'r').truncate();
      final result = _combination(n, r);
      return ToolResult(
        primary: result,
        unit: 'combinations',
        latex: '\\binom{$n}{$r}',
        details: [
          ResultDetail('Notation', 'C($n, $r)'),
          const ResultDetail('Order matters?', 'No'),
        ],
      );
    },
  ),
  _calc(
    'permutations',
    'Permutations calculator',
    'Arrangements where order matters.',
    Icons.reorder_rounded,
    [_n('n', 'Total items (n)', 10), _n('r', 'Arranged items (r)', 3)],
    (values) {
      final n = _number(values, 'n', 'n').truncate();
      final r = _number(values, 'r', 'r').truncate();
      if (n < 0 || r < 0 || r > n)
        throw const FormatException('Require whole numbers with 0 ≤ r ≤ n.');
      var result = 1.0;
      for (var index = 0; index < r; index += 1) {
        result *= n - index;
      }
      return ToolResult(
        primary: result,
        unit: 'permutations',
        latex: '\\frac{$n!}{($n-$r)!}',
        details: [
          ResultDetail('Notation', 'P($n, $r)'),
          const ResultDetail('Order matters?', 'Yes'),
        ],
      );
    },
  ),
  _calc(
    'decimal-fraction',
    'Decimal to fraction',
    'Approximate a decimal as a reduced fraction.',
    Icons.functions_rounded,
    [
      _n('decimal', 'Decimal', .375),
      _n('denominator', 'Maximum denominator', 10000),
    ],
    (values) {
      final decimal = _number(values, 'decimal', 'Decimal');
      final maximum = math.max(
        1,
        _positive(values, 'denominator', 'Maximum denominator').truncate(),
      );
      final fraction = _decimalFraction(decimal, maximum);
      final check = fraction.numerator / fraction.denominator;
      return ToolResult(
        primary: '${fraction.numerator}/${fraction.denominator}',
        unit: 'fraction',
        latex: '\\frac{${fraction.numerator}}{${fraction.denominator}}',
        details: [
          ResultDetail('Decimal check', check),
          ResultDetail('Approximation error', (decimal - check).abs()),
        ],
      );
    },
  ),
];

final List<CalculatorTool> scienceTools = [
  _calc(
    'ohms-law',
    'Ohm’s law calculator',
    'Resistance and electric power from voltage and current.',
    Icons.electrical_services_rounded,
    [
      _n('voltage', 'Voltage', 12, unit: 'V'),
      _n('current', 'Current', 2, unit: 'A'),
    ],
    (values) {
      final voltage = _number(values, 'voltage', 'Voltage');
      final current = _number(values, 'current', 'Current');
      if (current == 0) throw const FormatException('Current cannot be zero.');
      return ToolResult(
        primary: voltage / current,
        unit: 'Ω resistance',
        latex: '\\frac{${_compact(voltage)}}{${_compact(current)}}',
        details: [
          ResultDetail('Power', voltage * current, suffix: ' W'),
          ResultDetail('Voltage', voltage, suffix: ' V'),
          ResultDetail('Current', current, suffix: ' A'),
        ],
      );
    },
  ),
  _calc(
    'electric-power',
    'Electric power calculator',
    'DC power and energy use.',
    Icons.bolt_rounded,
    [
      _n('voltage', 'Voltage', 120, unit: 'V'),
      _n('current', 'Current', 5, unit: 'A'),
      _n('hours', 'Run time', 3, unit: 'hours'),
    ],
    (values) {
      final voltage = _number(values, 'voltage', 'Voltage');
      final current = _number(values, 'current', 'Current');
      final hours = _positive(values, 'hours', 'Run time', zero: true);
      final power = voltage * current;
      return ToolResult(
        primary: power,
        unit: 'watts',
        latex: '${_compact(voltage)}\\times${_compact(current)}',
        details: [
          ResultDetail('Energy', power * hours / 1000, suffix: ' kWh'),
          ResultDetail(
            'Resistance',
            current == 0 ? 'Undefined' : voltage / current,
            suffix: current == 0 ? '' : ' Ω',
          ),
        ],
      );
    },
  ),
  _calc(
    'kinetic-energy',
    'Kinetic energy calculator',
    'Translational energy from mass and velocity.',
    Icons.speed_rounded,
    [
      _n('mass', 'Mass', 80, unit: 'kg'),
      _n('velocity', 'Velocity', 12, unit: 'm/s'),
    ],
    (values) {
      final mass = _positive(values, 'mass', 'Mass', zero: true);
      final velocity = _number(values, 'velocity', 'Velocity');
      return ToolResult(
        primary: .5 * mass * velocity * velocity,
        unit: 'joules',
        latex: '\\frac{1}{2}(${_compact(mass)})(${_compact(velocity)})^2',
        details: [ResultDetail('Momentum', mass * velocity, suffix: ' kg⋅m/s')],
      );
    },
  ),
  _calc(
    'potential-energy',
    'Gravitational potential energy',
    'Near-Earth gravitational potential energy.',
    Icons.height_rounded,
    [
      _n('mass', 'Mass', 20, unit: 'kg'),
      _n('height', 'Height', 8, unit: 'm'),
      _n('gravity', 'Gravity', 9.80665, unit: 'm/s²'),
    ],
    (values) {
      final mass = _positive(values, 'mass', 'Mass', zero: true);
      final height = _number(values, 'height', 'Height');
      final gravity = _number(values, 'gravity', 'Gravity');
      return ToolResult(
        primary: mass * gravity * height,
        unit: 'joules',
        latex:
            '${_compact(mass)}\\times${_compact(gravity)}\\times${_compact(height)}',
        details: [ResultDetail('Force (weight)', mass * gravity, suffix: ' N')],
      );
    },
  ),
  _calc(
    'newtons-second-law',
    'Force calculator',
    'Newton’s second law: F = ma.',
    Icons.science_rounded,
    [
      _n('mass', 'Mass', 1200, unit: 'kg'),
      _n('acceleration', 'Acceleration', 3.5, unit: 'm/s²'),
    ],
    (values) {
      final mass = _positive(values, 'mass', 'Mass', zero: true);
      final acceleration = _number(values, 'acceleration', 'Acceleration');
      return ToolResult(
        primary: mass * acceleration,
        unit: 'newtons',
        latex: '${_compact(mass)}\\times${_compact(acceleration)}',
        details: [
          ResultDetail('Mass', mass, suffix: ' kg'),
          ResultDetail('Acceleration', acceleration, suffix: ' m/s²'),
        ],
      );
    },
  ),
  _calc(
    'momentum',
    'Momentum calculator',
    'Linear momentum and stopping force estimate.',
    Icons.arrow_forward_rounded,
    [
      _n('mass', 'Mass', 1000, unit: 'kg'),
      _n('velocity', 'Velocity', 20, unit: 'm/s'),
      _n('time', 'Stop time', 2, unit: 's'),
    ],
    (values) {
      final mass = _positive(values, 'mass', 'Mass', zero: true);
      final velocity = _number(values, 'velocity', 'Velocity');
      final time = _positive(values, 'time', 'Stop time');
      final momentum = mass * velocity;
      return ToolResult(
        primary: momentum,
        unit: 'kg⋅m/s',
        latex: '${_compact(mass)}\\times${_compact(velocity)}',
        details: [
          ResultDetail(
            'Average stopping force',
            (momentum / time).abs(),
            suffix: ' N',
          ),
          ResultDetail('Impulse magnitude', momentum.abs(), suffix: ' N⋅s'),
        ],
      );
    },
  ),
  _calc(
    'wave',
    'Wave relation calculator',
    'Wavelength and period from speed and frequency.',
    Icons.waves_rounded,
    [
      _n('speed', 'Wave speed', 343, unit: 'm/s'),
      _n('frequency', 'Frequency', 440, unit: 'Hz'),
    ],
    (values) {
      final speed = _number(values, 'speed', 'Wave speed');
      final frequency = _positive(values, 'frequency', 'Frequency');
      return ToolResult(
        primary: speed / frequency,
        unit: 'm wavelength',
        latex: '\\frac{${_compact(speed)}}{${_compact(frequency)}}',
        details: [
          ResultDetail('Period', 1 / frequency, suffix: ' s'),
          ResultDetail('Frequency', frequency, suffix: ' Hz'),
        ],
      );
    },
  ),
  _calc(
    'ideal-gas',
    'Ideal gas law calculator',
    'Pressure from amount, temperature, and volume.',
    Icons.air_rounded,
    [
      _n('moles', 'Amount', 1, unit: 'mol'),
      _n('temperature', 'Temperature', 298.15, unit: 'K'),
      _n('volume', 'Volume', .0245, unit: 'm³'),
    ],
    (values) {
      const gasConstant = 8.31446261815324;
      final moles = _positive(values, 'moles', 'Amount', zero: true);
      final temperature = _positive(values, 'temperature', 'Temperature');
      final volume = _positive(values, 'volume', 'Volume');
      final pressure = moles * gasConstant * temperature / volume;
      return ToolResult(
        primary: pressure,
        unit: 'Pa',
        latex:
            '\\frac{${_compact(moles)}\\times${_compact(gasConstant)}\\times${_compact(temperature)}}{${_compact(volume)}}',
        details: [
          ResultDetail('Kilopascals', pressure / 1000, suffix: ' kPa'),
          const ResultDetail('Gas constant', '8.314462618 J/(mol⋅K)'),
        ],
        note: 'The ideal gas law is an approximation.',
      );
    },
  ),
  _calc(
    'molarity',
    'Molarity calculator',
    'Concentration from solute amount and solution volume.',
    Icons.science_rounded,
    [
      _n('moles', 'Solute amount', .25, unit: 'mol'),
      _n('liters', 'Solution volume', .5, unit: 'L'),
    ],
    (values) {
      final moles = _positive(values, 'moles', 'Solute amount', zero: true);
      final liters = _positive(values, 'liters', 'Solution volume');
      return ToolResult(
        primary: moles / liters,
        unit: 'mol/L',
        latex: '\\frac{${_compact(moles)}}{${_compact(liters)}}',
        details: [
          ResultDetail('Millimolar', moles / liters * 1000, suffix: ' mM'),
        ],
      );
    },
  ),
  _calc(
    'element-shape',
    'Element to shape calculator',
    'Estimate volume, mass, and weight for a pure element formed into a 3D shape.',
    Icons.view_in_ar_rounded,
    [
      _s(
        'element',
        'Element',
        '13',
        elementDensities
            .map(
              (element) => _o(
                '${element.atomicNumber}',
                '${element.atomicNumber}. ${element.name} (${element.symbol}) — ${element.density.toStringAsFixed(4)} g/cm³',
              ),
            )
            .toList(),
      ),
      _s('shape', '3D shape', 'cube', [
        _o('cube', 'Cube'),
        _o('box', 'Rectangular prism'),
        _o('sphere', 'Sphere'),
        _o('cylinder', 'Cylinder'),
        _o('cone', 'Cone'),
        _o('pyramid', 'Square pyramid'),
        _o('triPrism', 'Triangular prism'),
        _o('ellipsoid', 'Ellipsoid'),
      ]),
      _s('unit', 'Dimension units', 'cm', [
        _o('mm', 'Millimeters'),
        _o('cm', 'Centimeters'),
        _o('m', 'Meters'),
        _o('in', 'Inches'),
        _o('ft', 'Feet'),
      ]),
      _n(
        'side',
        'Side',
        10,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['cube'],
      ),
      _n(
        'length',
        'Length',
        10,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['box'],
      ),
      _n(
        'width',
        'Width',
        8,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['box'],
      ),
      _n(
        'boxHeight',
        'Height',
        6,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['box'],
      ),
      _n(
        'radius',
        'Radius',
        5,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['sphere', 'cylinder', 'cone'],
      ),
      _n(
        'roundHeight',
        'Height',
        10,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['cylinder', 'cone'],
      ),
      _n(
        'baseSide',
        'Base side',
        8,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['pyramid'],
      ),
      _n(
        'pyramidHeight',
        'Height',
        10,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['pyramid'],
      ),
      _n(
        'triangleBase',
        'Triangle base',
        8,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['triPrism'],
      ),
      _n(
        'triangleHeight',
        'Triangle height',
        6,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['triPrism'],
      ),
      _n(
        'prismLength',
        'Prism length',
        10,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['triPrism'],
      ),
      _n(
        'axisA',
        'Semi-axis a',
        6,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['ellipsoid'],
      ),
      _n(
        'axisB',
        'Semi-axis b',
        4,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['ellipsoid'],
      ),
      _n(
        'axisC',
        'Semi-axis c',
        3,
        unit: 'selected unit',
        showWhenField: 'shape',
        showWhenValues: ['ellipsoid'],
      ),
    ],
    (values) {
      final elementNumber = int.tryParse(values['element'] ?? '');
      final element = elementDensities.firstWhere(
        (item) => item.atomicNumber == elementNumber,
        orElse: () => elementDensities.first,
      );
      final factor = switch (values['unit']) {
        'mm' => .1,
        'm' => 100.0,
        'in' => 2.54,
        'ft' => 30.48,
        _ => 1.0,
      };
      double dimension(String id, String label) =>
          _positive(values, id, label) * factor;
      late final double volume;
      late final String latex;
      switch (values['shape']) {
        case 'box':
          final length = dimension('length', 'Length');
          final width = dimension('width', 'Width');
          final height = dimension('boxHeight', 'Height');
          volume = length * width * height;
          latex =
              '${_compact(length)}\\times${_compact(width)}\\times${_compact(height)}';
          break;
        case 'sphere':
          final radius = dimension('radius', 'Radius');
          volume = 4 / 3 * math.pi * math.pow(radius, 3);
          latex = '\\frac{4}{3}\\pi(${_compact(radius)})^3';
          break;
        case 'cylinder':
          final radius = dimension('radius', 'Radius');
          final height = dimension('roundHeight', 'Height');
          volume = math.pi * radius * radius * height;
          latex = '\\pi(${_compact(radius)})^2(${_compact(height)})';
          break;
        case 'cone':
          final radius = dimension('radius', 'Radius');
          final height = dimension('roundHeight', 'Height');
          volume = math.pi * radius * radius * height / 3;
          latex =
              '\\frac{1}{3}\\pi(${_compact(radius)})^2(${_compact(height)})';
          break;
        case 'pyramid':
          final side = dimension('baseSide', 'Base side');
          final height = dimension('pyramidHeight', 'Height');
          volume = side * side * height / 3;
          latex = '\\frac{1}{3}(${_compact(side)})^2(${_compact(height)})';
          break;
        case 'triPrism':
          final base = dimension('triangleBase', 'Triangle base');
          final triangleHeight = dimension('triangleHeight', 'Triangle height');
          final length = dimension('prismLength', 'Prism length');
          volume = .5 * base * triangleHeight * length;
          latex =
              '\\frac{1}{2}(${_compact(base)})(${_compact(triangleHeight)})(${_compact(length)})';
          break;
        case 'ellipsoid':
          final a = dimension('axisA', 'Semi-axis a');
          final b = dimension('axisB', 'Semi-axis b');
          final c = dimension('axisC', 'Semi-axis c');
          volume = 4 / 3 * math.pi * a * b * c;
          latex =
              '\\frac{4}{3}\\pi(${_compact(a)})(${_compact(b)})(${_compact(c)})';
          break;
        default:
          final side = dimension('side', 'Side');
          volume = math.pow(side, 3).toDouble();
          latex = '(${_compact(side)})^3';
          break;
      }
      final grams = volume * element.density;
      final kilograms = grams / 1000;
      final selectedUnit = values['unit'] ?? 'cm';
      final selectedVolume = volume / math.pow(factor, 3);
      final metricUnit = const {'mm', 'cm', 'm'}.contains(selectedUnit);
      final alternateVolume = metricUnit ? volume / 16.387064 : volume;
      return ToolResult(
        primary: selectedVolume,
        unit: '$selectedUnit³ volume',
        latex: latex,
        details: [
          ResultDetail('Element', '${element.name} (${element.symbol})'),
          ResultDetail(
            'Other-system volume',
            alternateVolume,
            suffix: metricUnit ? ' in³' : ' cm³',
          ),
          ResultDetail('Mass', kilograms, suffix: ' kg'),
          ResultDetail('Mass', grams, suffix: ' g'),
          ResultDetail('Weight', grams / 453.59237, suffix: ' lb'),
          ResultDetail('Density', element.density, suffix: ' g/cm³'),
          ResultDetail('Reference phase', element.phase),
        ],
        meta: {
          'shape': values['shape'] ?? 'cube',
          'element': element.symbol,
          'phase': element.phase,
          'atomicNumber': element.atomicNumber,
        },
        note:
            'Uses reference bulk density in g/cm³. Density varies with temperature, pressure, purity, and allotrope. Gas values are standard-condition references.${element.estimated ? ' This element uses a theoretical density estimate.' : ''}',
      );
    },
    note:
        'A mathematical material estimate. Several elements cannot form a stable macroscopic object under ordinary conditions; theoretical density values are labeled in the result.',
  ),
];

final List<CalculatorTool> everydayTools = [
  _calc(
    'trip-fuel-cost',
    'Trip fuel cost calculator',
    'Fuel needed and cost for a road trip.',
    Icons.local_gas_station_rounded,
    [
      _s('system', 'Units', 'metric', [
        _o('metric', 'Metric'),
        _o('us', 'Miles & US gallons'),
      ], segmented: true),
      _n(
        'distanceKm',
        'Trip distance',
        500,
        unit: 'km',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'economyMetric',
        'Fuel consumption',
        .08,
        unit: 'L/km',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'priceLiter',
        'Fuel price',
        1.65,
        unit: r'$/L',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'distanceMi',
        'Trip distance',
        300,
        unit: 'mi',
        showWhenField: 'system',
        showWhenValues: ['us'],
      ),
      _n(
        'economyMpg',
        'Fuel economy',
        28,
        unit: 'mpg (US)',
        showWhenField: 'system',
        showWhenValues: ['us'],
      ),
      _n(
        'priceGallon',
        'Fuel price',
        3.5,
        unit: r'$/gal',
        showWhenField: 'system',
        showWhenValues: ['us'],
      ),
    ],
    (values) {
      final metric = values['system'] != 'us';
      final distance = _positive(
        values,
        metric ? 'distanceKm' : 'distanceMi',
        'Distance',
        zero: true,
      );
      final economy = _positive(
        values,
        metric ? 'economyMetric' : 'economyMpg',
        metric ? 'Fuel consumption' : 'Fuel economy',
      );
      final price = _positive(
        values,
        metric ? 'priceLiter' : 'priceGallon',
        'Fuel price',
        zero: true,
      );
      final fuel = metric ? distance * economy : distance / economy;
      return ToolResult(
        primary: fuel * price,
        unit: r'$ trip cost',
        latex: metric
            ? '${_compact(distance)}\\times${_compact(economy)}\\times${_compact(price)}'
            : '\\frac{${_compact(distance)}}{${_compact(economy)}}\\times${_compact(price)}',
        details: [
          ResultDetail('Fuel needed', fuel, suffix: metric ? ' L' : ' US gal'),
          ResultDetail(
            metric ? 'Cost per kilometer' : 'Cost per mile',
            distance == 0 ? 0 : fuel * price / distance,
            prefix: r'$',
          ),
        ],
      );
    },
    currency: true,
  ),
  _calc(
    'paint',
    'Paint coverage calculator',
    'Paint volume from area, coverage, and coats.',
    Icons.format_paint_rounded,
    [
      _s('system', 'Units', 'metric', [
        _o('metric', 'Metric'),
        _o('imperial', 'US / Imperial'),
      ], segmented: true),
      _n(
        'areaM2',
        'Paintable area',
        60,
        unit: 'm²',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'coverageMetric',
        'Coverage',
        10,
        unit: 'm²/L',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'areaFt2',
        'Paintable area',
        650,
        unit: 'ft²',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n(
        'coverageImperial',
        'Coverage',
        350,
        unit: 'ft²/US gal',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n('coats', 'Coats', 2),
      _n('buffer', 'Extra buffer', 0, unit: '%'),
    ],
    (values) {
      final metric = values['system'] != 'imperial';
      final area = _positive(
        values,
        metric ? 'areaM2' : 'areaFt2',
        'Area',
        zero: true,
      );
      final coverage = _positive(
        values,
        metric ? 'coverageMetric' : 'coverageImperial',
        'Coverage',
      );
      final coats = math.max(1, _positive(values, 'coats', 'Coats').round());
      final buffer = _positive(values, 'buffer', 'Buffer', zero: true);
      final baseVolume = area * coats / coverage;
      final volume = baseVolume * (1 + buffer / 100);
      return ToolResult(
        primary: volume,
        unit: metric ? 'liters' : 'US gallons',
        latex:
            '\\frac{${_compact(area)}\\times$coats}{${_compact(coverage)}}\\left(1+\\frac{${_compact(buffer)}}{100}\\right)',
        details: [
          ResultDetail(
            'Before buffer',
            baseVolume,
            suffix: metric ? ' L' : ' US gal',
          ),
          ResultDetail('Buffer', buffer, suffix: '%'),
          ResultDetail(
            'Coated area',
            area * coats,
            suffix: metric ? ' m²' : ' ft²',
          ),
        ],
      );
    },
  ),
  _calc(
    'recipe-scale',
    'Recipe scaling calculator',
    'Scale an ingredient to a new serving count.',
    Icons.restaurant_menu_rounded,
    [
      _n('quantity', 'Original amount', 2.5, unit: 'units'),
      _n('servings', 'Original servings', 4),
      _n('newServings', 'New servings', 10),
    ],
    (values) {
      final quantity = _number(values, 'quantity', 'Amount');
      final servings = _positive(values, 'servings', 'Original servings');
      final next = _positive(values, 'newServings', 'New servings', zero: true);
      final factor = next / servings;
      return ToolResult(
        primary: quantity * factor,
        unit: 'scaled units',
        latex:
            '\\frac{${_compact(quantity)}\\times${_compact(next)}}{${_compact(servings)}}',
        details: [
          ResultDetail('Scale factor', factor),
          ResultDetail('Per serving', quantity / servings, suffix: ' units'),
        ],
      );
    },
  ),
  _calc(
    'unit-price',
    'Unit price comparison',
    'Compare two package prices on equal terms.',
    Icons.shopping_cart_rounded,
    [
      _n('priceA', 'Package A price', 6.49, unit: r'$'),
      _n('amountA', 'Package A amount', 18, unit: 'units'),
      _n('priceB', 'Package B price', 8.99, unit: r'$'),
      _n('amountB', 'Package B amount', 30, unit: 'units'),
    ],
    (values) {
      final priceA = _positive(values, 'priceA', 'Package A price', zero: true);
      final amountA = _positive(values, 'amountA', 'Package A amount');
      final priceB = _positive(values, 'priceB', 'Package B price', zero: true);
      final amountB = _positive(values, 'amountB', 'Package B amount');
      final unitA = priceA / amountA;
      final unitB = priceB / amountB;
      return ToolResult(
        primary: unitA <= unitB ? 'Package A' : 'Package B',
        unit: 'is the better value',
        latex: unitA <= unitB
            ? '\\frac{${_compact(priceA)}}{${_compact(amountA)}}'
            : '\\frac{${_compact(priceB)}}{${_compact(amountB)}}',
        details: [
          ResultDetail('Package A per unit', unitA, prefix: r'$'),
          ResultDetail('Package B per unit', unitB, prefix: r'$'),
          ResultDetail('Difference', (unitA - unitB).abs(), prefix: r'$'),
        ],
      );
    },
  ),
  _calc(
    'mileage',
    'Mileage reimbursement calculator',
    'Distance multiplied by a supplied reimbursement rate.',
    Icons.route_rounded,
    [
      _s('system', 'Units', 'imperial', [
        _o('imperial', 'Miles'),
        _o('metric', 'Kilometers'),
      ], segmented: true),
      _n(
        'distanceMi',
        'Business distance',
        240,
        unit: 'mi',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n(
        'rateMi',
        'Rate per mile',
        .70,
        unit: r'$/mi',
        showWhenField: 'system',
        showWhenValues: ['imperial'],
      ),
      _n(
        'distanceKm',
        'Business distance',
        386,
        unit: 'km',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'rateKm',
        'Rate per kilometer',
        .43,
        unit: r'$/km',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
    ],
    (values) {
      final imperial = values['system'] != 'metric';
      final distance = _positive(
        values,
        imperial ? 'distanceMi' : 'distanceKm',
        'Distance',
        zero: true,
      );
      final rate = _positive(
        values,
        imperial ? 'rateMi' : 'rateKm',
        'Rate',
        zero: true,
      );
      return ToolResult(
        primary: distance * rate,
        unit: r'$ reimbursement',
        latex: '${_compact(distance)}\\times${_compact(rate)}',
        details: [
          ResultDetail('Distance', distance, suffix: imperial ? ' mi' : ' km'),
          ResultDetail(
            'Rate',
            rate,
            prefix: r'$',
            suffix: imperial ? '/mi' : '/km',
          ),
        ],
        note: 'Enter the rate for your organization and jurisdiction.',
      );
    },
    currency: true,
  ),
  _calc(
    'work-time',
    'Work time calculator',
    'Elapsed paid time after an unpaid break.',
    Icons.schedule_rounded,
    [
      _s('format', 'Time entry', 'decimal', [
        _o('decimal', '24h decimal'),
        _o('clock', 'Actual time (12-hour)'),
      ], segmented: true),
      _n(
        'startDecimal',
        'Start time',
        8.5,
        unit: '24h decimal',
        help: '8.5 means 8:30.',
        showWhenField: 'format',
        showWhenValues: ['decimal'],
      ),
      _n(
        'endDecimal',
        'End time',
        17.25,
        unit: '24h decimal',
        showWhenField: 'format',
        showWhenValues: ['decimal'],
      ),
      _t(
        'startClock',
        'Start time',
        '00:00',
        help: 'Use 12-hour time; the colon is inserted automatically.',
        showWhenField: 'format',
        showWhenValues: ['clock'],
        time12: true,
        periodDefault: 'am',
      ),
      _t(
        'endClock',
        'End time',
        '00:00',
        help: 'Use 12-hour time; overnight shifts are handled automatically.',
        showWhenField: 'format',
        showWhenValues: ['clock'],
        time12: true,
        periodDefault: 'pm',
      ),
      _n('break', 'Unpaid break', 30, unit: 'minutes'),
    ],
    (values) {
      final clock = values['format'] == 'clock';
      final start = clock
          ? _clock12Hours(
              values['startClock'],
              values['startClockPeriod'],
              'Start time',
            )
          : _number(values, 'startDecimal', 'Start time');
      var end = clock
          ? _clock12Hours(
              values['endClock'],
              values['endClockPeriod'],
              'End time',
            )
          : _number(values, 'endDecimal', 'End time');
      final breakMinutes = _positive(values, 'break', 'Break', zero: true);
      if (end < start) end += 24;
      final hours = end - start - breakMinutes / 60;
      if (hours < 0)
        throw const FormatException('Break is longer than the shift.');
      final whole = hours.floor();
      final minutes = ((hours - whole) * 60).round();
      return ToolResult(
        primary: '${whole}h ${minutes}m',
        unit: 'paid time',
        latex:
            '(${_compact(end)}-${_compact(start)})-\\frac{${_compact(breakMinutes)}}{60}',
        details: [
          ResultDetail('Decimal hours', hours),
          ResultDetail('Break', breakMinutes, suffix: ' min'),
        ],
      );
    },
  ),
  _calc(
    'date-difference',
    'Date difference calculator',
    'Exact elapsed days between two dates.',
    Icons.date_range_rounded,
    [
      _d('start', 'Start date', '2025-01-01'),
      _d('end', 'End date', '2026-01-01'),
    ],
    (values) {
      final startValue = DateTime.tryParse(values['start'] ?? '');
      final endValue = DateTime.tryParse(values['end'] ?? '');
      if (startValue == null || endValue == null)
        throw const FormatException('Choose two valid dates.');
      final start = DateTime.utc(
        startValue.year,
        startValue.month,
        startValue.day,
      );
      final end = DateTime.utc(endValue.year, endValue.month, endValue.day);
      final days = end.difference(start).inDays.abs();
      final startSerial = start.millisecondsSinceEpoch ~/ 86400000;
      final endSerial = end.millisecondsSinceEpoch ~/ 86400000;
      int ordinal(DateTime date) =>
          date.difference(DateTime.utc(date.year, 1, 1)).inDays + 1;
      int daysInYear(int year) => DateTime.utc(
        year + 1,
        1,
        1,
      ).difference(DateTime.utc(year, 1, 1)).inDays;
      return ToolResult(
        primary: days,
        unit: 'days',
        latex: '\\left|$endSerial-$startSerial\\right|',
        details: [
          ResultDetail('Weeks', days / 7),
          ResultDetail('Months (average)', days / 30.436875),
          ResultDetail('Years (average)', days / 365.2425),
          ResultDetail(
            'Start day of year',
            '${ordinal(start)} of ${daysInYear(start.year)}',
          ),
          ResultDetail(
            'End day of year',
            '${ordinal(end)} of ${daysInYear(end.year)}',
          ),
          ResultDetail(
            'Direction',
            end.isBefore(start) ? 'Reverse' : 'Forward',
          ),
        ],
        note:
            'Calendar serial-day subtraction counts leap days exactly. Months and years are average-length equivalents.',
      );
    },
  ),
  _calc(
    'fuel-mix',
    'Two-stroke fuel mix',
    'Oil volume for a supplied fuel-to-oil ratio.',
    Icons.local_gas_station_rounded,
    [
      _s('system', 'Units', 'metric', [
        _o('metric', 'Liters'),
        _o('us', 'US gallons'),
      ], segmented: true),
      _n(
        'fuelLiters',
        'Fuel volume',
        5,
        unit: 'L',
        showWhenField: 'system',
        showWhenValues: ['metric'],
      ),
      _n(
        'fuelGallons',
        'Fuel volume',
        1.3,
        unit: 'US gal',
        showWhenField: 'system',
        showWhenValues: ['us'],
      ),
      _n('ratio', 'Fuel ratio', 50, unit: ':1'),
    ],
    (values) {
      final metric = values['system'] != 'us';
      final fuel = _positive(
        values,
        metric ? 'fuelLiters' : 'fuelGallons',
        'Fuel volume',
        zero: true,
      );
      final ratio = _positive(values, 'ratio', 'Ratio');
      final fuelLiters = metric ? fuel : fuel * 3.785411784;
      final oilLiters = fuelLiters / ratio;
      return ToolResult(
        primary: oilLiters * 1000,
        unit: 'mL oil',
        latex: '\\frac{${_compact(fuelLiters)}\\times1000}{${_compact(ratio)}}',
        details: [
          ResultDetail('Oil liters', oilLiters, suffix: ' L'),
          ResultDetail(
            'Oil US fl oz',
            oilLiters * 33.8140227,
            suffix: ' fl oz',
          ),
          ResultDetail('Mixture total', fuelLiters + oilLiters, suffix: ' L'),
        ],
      );
    },
  ),
];

final List<CalculatorTool> digitalTools = [
  _calc(
    'number-base',
    'Number base converter',
    'Integers between binary, octal, decimal, and hexadecimal.',
    Icons.code_rounded,
    [
      _t('value', 'Number', 'FF'),
      _s('from', 'From base', '16', [
        _o('2', 'Binary (2)'),
        _o('8', 'Octal (8)'),
        _o('10', 'Decimal (10)'),
        _o('16', 'Hexadecimal (16)'),
      ]),
      _s('to', 'To base', '10', [
        _o('2', 'Binary (2)'),
        _o('8', 'Octal (8)'),
        _o('10', 'Decimal (10)'),
        _o('16', 'Hexadecimal (16)'),
      ]),
    ],
    (values) {
      final source = (values['value'] ?? '').trim();
      final from = int.parse(values['from']!);
      final to = int.parse(values['to']!);
      final parsed = int.tryParse(source, radix: from);
      if (parsed == null)
        throw FormatException('“$source” is not a valid base-$from integer.');
      final converted = parsed.toRadixString(to).toUpperCase();
      const iecUnits = ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'];
      var iecIndex = 0;
      var iecValue = parsed.abs().toDouble();
      while (iecValue >= 1024 && iecIndex < iecUnits.length - 1) {
        iecValue /= 1024;
        iecIndex += 1;
      }
      return ToolResult(
        primary: converted,
        unit: 'base $to',
        latex: '\\mathrm{$converted}_{($to)}',
        details: [
          ResultDetail('Decimal', parsed),
          ResultDetail('Binary', parsed.toRadixString(2)),
          ResultDetail('Hexadecimal', parsed.toRadixString(16).toUpperCase()),
          ResultDetail(
            'IEC binary unit value',
            '${parsed < 0 ? '−' : ''}${_compact(iecValue)} ${iecUnits[iecIndex]}',
          ),
        ],
      );
    },
  ),
  _calc(
    'download-time',
    'Download time calculator',
    'Transfer time from file size and connection speed.',
    Icons.download_rounded,
    [
      _n('size', 'File size', 10, unit: 'GB'),
      _n('speed', 'Connection speed', 100, unit: 'Mbit/s'),
      _n('efficiency', 'Real-world efficiency', 90, unit: '%'),
    ],
    (values) {
      final size = _positive(values, 'size', 'File size', zero: true);
      final speed = _positive(values, 'speed', 'Connection speed');
      final efficiency = (_positive(values, 'efficiency', 'Efficiency') / 100)
          .clamp(.01, 1);
      final seconds = size * 8e9 / (speed * 1e6 * efficiency);
      final hours = seconds ~/ 3600;
      final minutes = (seconds % 3600) ~/ 60;
      final remaining = (seconds % 60).round();
      final text =
          '${hours > 0 ? '${hours}h ' : ''}${minutes > 0 ? '${minutes}m ' : ''}${remaining}s';
      return ToolResult(
        primary: text,
        unit: 'estimated time',
        latex:
            '\\frac{${_compact(size)}\\times8\\times1000}{${_compact(speed)}\\times${_compact(efficiency)}}',
        details: [
          ResultDetail('Seconds', seconds),
          ResultDetail(
            'Effective speed',
            speed * efficiency,
            suffix: ' Mbit/s',
          ),
        ],
        note:
            'Actual transfers also depend on latency, overhead, and server limits.',
      );
    },
  ),
  _calc(
    'screen-ppi',
    'Screen PPI calculator',
    'Pixel density from resolution and diagonal size.',
    Icons.phone_iphone_rounded,
    [
      _n('width', 'Horizontal pixels', 2556, unit: 'px'),
      _n('height', 'Vertical pixels', 1179, unit: 'px'),
      _n('diagonal', 'Diagonal size', 6.1, unit: 'in'),
    ],
    (values) {
      final width = _positive(values, 'width', 'Width');
      final height = _positive(values, 'height', 'Height');
      final diagonal = _positive(values, 'diagonal', 'Diagonal');
      final ppi = math.sqrt(width * width + height * height) / diagonal;
      final divisor = _gcd(width.round(), height.round());
      return ToolResult(
        primary: ppi,
        unit: 'pixels per inch',
        latex:
            '\\frac{\\sqrt{${_compact(width)}^2+${_compact(height)}^2}}{${_compact(diagonal)}}',
        details: [
          ResultDetail('Total pixels', width * height),
          ResultDetail(
            'Aspect ratio',
            '${width.round() ~/ divisor}:${height.round() ~/ divisor}',
          ),
          ResultDetail('Megapixels', width * height / 1e6),
        ],
      );
    },
  ),
  _calc(
    'aspect-ratio',
    'Aspect ratio calculator',
    'Scale dimensions while preserving proportion.',
    Icons.aspect_ratio_rounded,
    [
      _n('width', 'Ratio width', 16),
      _n('height', 'Ratio height', 9),
      _n('newWidth', 'New width', 1920, unit: 'px'),
    ],
    (values) {
      final width = _positive(values, 'width', 'Width');
      final height = _positive(values, 'height', 'Height');
      final next = _positive(values, 'newWidth', 'New width', zero: true);
      final newHeight = next * height / width;
      return ToolResult(
        primary: newHeight,
        unit: 'px height',
        latex:
            '\\frac{${_compact(next)}\\times${_compact(height)}}{${_compact(width)}}',
        details: [
          ResultDetail('Scale factor', next / width),
          ResultDetail(
            'Dimensions',
            '${_compact(next)} × ${_compact(newHeight)}',
          ),
        ],
      );
    },
  ),
];
