import 'package:flutter/material.dart';

import '../models/tool_models.dart';
import 'calculator_catalog.dart';
import 'unit_catalog.dart';

final _everydayUnitIds = <String>{
  'unit-length',
  'unit-area',
  'unit-volume',
  'unit-mass',
  'unit-temperature',
  'unit-time',
  'unit-speed',
  'unit-cooking',
  'unit-fuel-economy',
};

final _digitalUnitIds = <String>{
  'unit-storage',
  'unit-data-rate',
  'unit-typography',
};

List<UnitTool> _units(Set<String> ids) =>
    unitTools.where((tool) => ids.contains(tool.id)).toList();

final List<ToolSection> toolSections = [
  ToolSection(
    id: 'conversions',
    title: 'Everyday conversions',
    description: 'Length, mass, time & more',
    icon: Icons.straighten_rounded,
    tools: _units(_everydayUnitIds),
  ),
  ToolSection(
    id: 'science-conversions',
    title: 'Science conversions',
    description: 'Engineering and laboratory units',
    icon: Icons.science_rounded,
    tools: unitTools
        .where(
          (tool) =>
              !_everydayUnitIds.contains(tool.id) &&
              !_digitalUnitIds.contains(tool.id),
        )
        .toList(),
  ),
  ToolSection(
    id: 'finance',
    title: 'Finance & money',
    description: 'Loans, savings, prices & business',
    icon: Icons.account_balance_wallet_rounded,
    tools: financeTools,
  ),
  ToolSection(
    id: 'health',
    title: 'Health & fitness',
    description: 'General wellness estimates',
    icon: Icons.favorite_rounded,
    tools: healthTools,
  ),
  ToolSection(
    id: 'geometry',
    title: 'Geometry',
    description: 'Area, volume and dimensions',
    icon: Icons.architecture_rounded,
    tools: geometryTools,
  ),
  ToolSection(
    id: 'math',
    title: 'Math & statistics',
    description: 'Algebra, percentages and data',
    icon: Icons.calculate_rounded,
    tools: mathTools,
  ),
  ToolSection(
    id: 'science',
    title: 'Science & engineering',
    description: 'Physics, electricity and chemistry',
    icon: Icons.rocket_launch_rounded,
    tools: scienceTools,
  ),
  ToolSection(
    id: 'everyday',
    title: 'Everyday life',
    description: 'Trips, recipes, dates and projects',
    icon: Icons.home_rounded,
    tools: everydayTools,
  ),
  ToolSection(
    id: 'digital',
    title: 'Digital & computing',
    description: 'Data, displays and number systems',
    icon: Icons.code_rounded,
    tools: [..._units(_digitalUnitIds), ...digitalTools],
  ),
];

final List<EverythingTool> allTools = toolSections
    .expand((section) => section.tools)
    .toList(growable: false);
final Map<String, EverythingTool> toolById = {
  for (final tool in allTools) tool.id: tool,
};
final Map<String, ToolSection> sectionByToolId = {
  for (final section in toolSections)
    for (final tool in section.tools) tool.id: section,
};
