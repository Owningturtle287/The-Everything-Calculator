import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_math_fork/flutter_math.dart';

import '../core/currency_service.dart';
import '../core/history_controller.dart';
import '../core/number_format.dart';
import '../core/settings_controller.dart';
import '../data/tool_catalog.dart';
import '../models/tool_models.dart';
import '../theme/app_theme.dart';

class ToolScreen extends StatelessWidget {
  const ToolScreen({
    super.key,
    required this.tool,
    required this.settings,
    required this.history,
    this.initialValues = const {},
  });

  final EverythingTool tool;
  final SettingsController settings;
  final HistoryController history;
  final Map<String, String> initialValues;

  @override
  Widget build(BuildContext context) {
    final section = sectionByToolId[tool.id];
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Everything Calculator',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
      ),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 42),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 980),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _ToolHeader(tool: tool, category: section?.title ?? 'Tool'),
                  const SizedBox(height: 18),
                  if (tool case UnitTool unitTool)
                    UnitToolBody(
                      tool: unitTool,
                      settings: settings,
                      history: history,
                      initialValues: initialValues,
                    )
                  else if (tool case CalculatorTool calculatorTool)
                    CalculatorToolBody(
                      tool: calculatorTool,
                      settings: settings,
                      history: history,
                      initialValues: initialValues,
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ToolHeader extends StatelessWidget {
  const _ToolHeader({required this.tool, required this.category});
  final EverythingTool tool;
  final String category;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 54,
          height: 54,
          decoration: BoxDecoration(
            color: AppTheme.orange.withValues(alpha: .08),
            borderRadius: BorderRadius.circular(17),
            border: Border.all(color: AppTheme.orange.withValues(alpha: .3)),
          ),
          child: Icon(tool.icon, color: AppTheme.orangeDark),
        ),
        const SizedBox(width: 13),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                category.toUpperCase(),
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: AppTheme.orangeDark,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.3,
                ),
              ),
              const SizedBox(height: 5),
              Text(
                tool.title,
                style: Theme.of(context).textTheme.headlineLarge,
              ),
              const SizedBox(height: 6),
              Text(
                tool.description,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class UnitToolBody extends StatefulWidget {
  const UnitToolBody({
    super.key,
    required this.tool,
    required this.settings,
    required this.history,
    required this.initialValues,
  });
  final UnitTool tool;
  final SettingsController settings;
  final HistoryController history;
  final Map<String, String> initialValues;

  @override
  State<UnitToolBody> createState() => _UnitToolBodyState();
}

class _UnitToolBodyState extends State<UnitToolBody> {
  late final TextEditingController input;
  late int from;
  late int to;
  UnitConversionResult? result;
  String? error;

  @override
  void initState() {
    super.initState();
    input = TextEditingController(text: widget.initialValues['value'] ?? '')
      ..addListener(_calculate);
    from =
        int.tryParse(widget.initialValues['from'] ?? '') ??
        widget.tool.defaultFrom;
    to =
        int.tryParse(widget.initialValues['to'] ?? '') ?? widget.tool.defaultTo;
    if (from < 0 || from >= widget.tool.units.length) {
      from = widget.tool.defaultFrom;
    }
    if (to < 0 || to >= widget.tool.units.length) {
      to = widget.tool.defaultTo;
    }
    widget.settings.addListener(_calculate);
    WidgetsBinding.instance.addPostFrameCallback((_) => _calculate());
  }

  @override
  void dispose() {
    widget.settings.removeListener(_calculate);
    input
      ..removeListener(_calculate)
      ..dispose();
    super.dispose();
  }

  void _calculate() {
    if (input.text.trim().isEmpty) {
      if (!mounted) return;
      setState(() {
        result = null;
        error = null;
      });
      return;
    }
    final value = double.tryParse(input.text.replaceAll(',', ''));
    if (!mounted) return;
    if (value == null) {
      setState(() {
        result = null;
        error = 'Enter a valid number.';
      });
      return;
    }
    try {
      final converted = widget.tool.convert(value, from, to);
      setState(() {
        result = converted;
        error = null;
      });
    } on FormatException catch (exception) {
      setState(() {
        result = null;
        error = exception.message;
      });
    }
  }

  void _swap() {
    final previous = result;
    setState(() {
      final old = from;
      from = to;
      to = old;
    });
    if (previous != null) {
      input.text = formatNumber(
        previous.value,
        precision: widget.settings.precision,
        separators: false,
      );
      input.selection = TextSelection.collapsed(offset: input.text.length);
    } else {
      _calculate();
    }
  }

  @override
  Widget build(BuildContext context) {
    final left = _ToolForm(
      title: 'Enter a value',
      subtitle: 'The result and formula update instantly.',
      error: error,
      note: widget.tool.note,
      actions: [
        OutlinedButton(
          onPressed: () {
            input.clear();
            setState(() {
              from = widget.tool.defaultFrom;
              to = widget.tool.defaultTo;
            });
            _calculate();
          },
          child: const Text('Reset'),
        ),
        FilledButton.icon(
          onPressed: result == null ? null : () => _copy(context),
          icon: const Icon(Icons.copy_rounded, size: 18),
          label: const Text('Copy'),
        ),
        FilledButton.tonalIcon(
          onPressed: result == null ? null : _save,
          icon: const Icon(Icons.history_rounded, size: 18),
          label: const Text('Save'),
        ),
      ],
      child: Column(
        children: [
          _FieldLabel(
            label: 'From',
            child: Row(
              children: [
                Expanded(
                  flex: 4,
                  child: TextField(
                    controller: input,
                    readOnly: true,
                    showCursor: true,
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                    ),
                    decoration: const InputDecoration(hintText: 'Example: 1'),
                    onTap: () => _showSignedNumberPad(context, input),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 5,
                  child: DropdownButtonFormField<int>(
                    key: ValueKey('from-$from'),
                    initialValue: from,
                    isExpanded: true,
                    selectedItemBuilder: (_) => _selectedUnitItems(),
                    decoration: const InputDecoration(),
                    items: _unitItems(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => from = value);
                        _calculate();
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Center(
              child: IconButton.filled(
                onPressed: _swap,
                icon: const Icon(Icons.swap_vert_rounded),
                style: IconButton.styleFrom(
                  backgroundColor: AppTheme.orange,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ),
          _FieldLabel(
            label: 'To',
            child: DropdownButtonFormField<int>(
              key: ValueKey('to-$to'),
              initialValue: to,
              isExpanded: true,
              selectedItemBuilder: (_) => _selectedUnitItems(),
              decoration: const InputDecoration(),
              items: _unitItems(),
              onChanged: (value) {
                if (value != null) {
                  setState(() => to = value);
                  _calculate();
                }
              },
            ),
          ),
        ],
      ),
    );
    return _Workbench(
      left: left,
      right: _ResultPanel(
        result: result == null
            ? null
            : ToolResult(
                primary: result!.value,
                unit: result!.to.symbol,
                latex: result!.latex,
                details: [
                  ResultDetail('From', '${input.text} ${result!.from.symbol}'),
                  ResultDetail('To', result!.to.name),
                  ResultDetail(
                    'Mode',
                    widget.tool.kind == ConversionKind.fuelEconomy
                        ? 'Reciprocal'
                        : 'Exact factor',
                  ),
                ],
                note: widget.tool.note,
              ),
        settings: widget.settings,
        placeholder: error ?? 'Enter a value to see the conversion.',
      ),
    );
  }

  List<DropdownMenuItem<int>> _unitItems() => widget.tool.units
      .asMap()
      .entries
      .map(
        (entry) => DropdownMenuItem(
          value: entry.key,
          child: Text(
            '${entry.value.name} (${entry.value.symbol})',
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13),
          ),
        ),
      )
      .toList();

  List<Widget> _selectedUnitItems() => widget.tool.units
      .map(
        (unit) => Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              '${unit.name} (${unit.symbol})',
              maxLines: 1,
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ),
      )
      .toList();

  Future<void> _copy(BuildContext context) async {
    final current = result;
    if (current == null) return;
    await Clipboard.setData(
      ClipboardData(
        text:
            '${formatNumber(current.value, precision: widget.settings.precision, separators: widget.settings.separators)} ${current.to.symbol}',
      ),
    );
    if (context.mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Result copied')));
  }

  Future<void> _save() async {
    final current = result;
    if (current == null) return;
    final output =
        '${formatNumber(current.value, precision: widget.settings.precision, separators: widget.settings.separators)} ${current.to.symbol}'
            .trim();
    await widget.history.addTool(widget.tool.title, output, widget.tool.id, {
      'value': input.text.trim(),
      'from': '$from',
      'to': '$to',
    });
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Saved to history')));
    }
  }
}

class CalculatorToolBody extends StatefulWidget {
  const CalculatorToolBody({
    super.key,
    required this.tool,
    required this.settings,
    required this.history,
    required this.initialValues,
  });
  final CalculatorTool tool;
  final SettingsController settings;
  final HistoryController history;
  final Map<String, String> initialValues;

  @override
  State<CalculatorToolBody> createState() => _CalculatorToolBodyState();
}

class _CalculatorToolBodyState extends State<CalculatorToolBody> {
  final controllers = <String, TextEditingController>{};
  final selects = <String, String>{};
  final solves = <String, bool>{};
  final periods = <String, String>{};
  ToolResult? result;
  String? error;
  Timer? _currencyTimer;
  int _currencyRequest = 0;
  bool _loading = false;
  bool _showBmiChart = false;

  @override
  void initState() {
    super.initState();
    for (final field in widget.tool.fields) {
      if (field.type == ToolFieldType.select) {
        final restored = widget.initialValues[field.id];
        selects[field.id] =
            field.options.any((option) => option.value == restored)
            ? restored!
            : field.defaultValue;
      } else {
        controllers[field.id] = TextEditingController(
          text: widget.initialValues[field.id] ?? '',
        )..addListener(_calculate);
        if (field.solveToggle) {
          solves[field.id] =
              widget.initialValues['solve_${field.id}'] == 'true' ||
              (widget.initialValues['solve_${field.id}'] == null &&
                  field.solveByDefault);
        }
        if (field.type == ToolFieldType.time12) {
          final restored = widget.initialValues['${field.id}Period'];
          periods[field.id] = restored == 'pm' || restored == 'am'
              ? restored!
              : field.periodDefault;
        }
      }
    }
    widget.settings.addListener(_calculate);
    WidgetsBinding.instance.addPostFrameCallback((_) => _calculate());
  }

  @override
  void dispose() {
    _currencyTimer?.cancel();
    widget.settings.removeListener(_calculate);
    for (final controller in controllers.values) {
      controller
        ..removeListener(_calculate)
        ..dispose();
    }
    super.dispose();
  }

  Map<String, String> get _values {
    final values = <String, String>{};
    for (final field in widget.tool.fields) {
      values[field.id] = field.type == ToolFieldType.select
          ? selects[field.id]!
          : controllers[field.id]!.text;
      if (field.solveToggle) {
        values['solve_${field.id}'] = '${solves[field.id] ?? false}';
      }
      if (field.type == ToolFieldType.time12) {
        values['${field.id}Period'] = periods[field.id] ?? field.periodDefault;
      }
    }
    return values;
  }

  void _calculate() {
    if (!mounted) return;
    final values = _values;
    final visibleInputs = widget.tool.fields
        .where((field) => field.isVisible(values))
        .where((field) => field.type != ToolFieldType.select)
        .where((field) => !(field.solveToggle && (solves[field.id] ?? false)))
        .toList();
    final complete = widget.tool.id == 'calc-triangle'
        ? visibleInputs.any(
            (field) => (values[field.id] ?? '').trim().isNotEmpty,
          )
        : visibleInputs.every(
            (field) => (values[field.id] ?? '').trim().isNotEmpty,
          );
    if (!complete) {
      _currencyTimer?.cancel();
      setState(() {
        result = null;
        error = null;
        _loading = false;
      });
      return;
    }
    if (widget.tool.asyncType == 'currency') {
      _currencyTimer?.cancel();
      setState(() {
        result = null;
        error = null;
        _loading = true;
      });
      final snapshot = Map<String, String>.from(values);
      _currencyTimer = Timer(
        const Duration(milliseconds: 350),
        () => _calculateCurrency(snapshot),
      );
      return;
    }
    try {
      final calculated = widget.tool.calculate(values);
      setState(() {
        result = calculated;
        error = null;
        _loading = false;
      });
    } on FormatException catch (exception) {
      setState(() {
        result = null;
        error = exception.message;
        _loading = false;
      });
    } catch (exception) {
      setState(() {
        result = null;
        error = exception.toString();
        _loading = false;
      });
    }
  }

  Future<void> _calculateCurrency(Map<String, String> values) async {
    final request = ++_currencyRequest;
    try {
      final amount = double.parse((values['amount'] ?? '').replaceAll(',', ''));
      if (!amount.isFinite)
        throw const FormatException('Enter a valid amount.');
      final from = values['from'] ?? 'USD';
      final to = values['to'] ?? 'EUR';
      final quote = await CurrencyService.latest(from, to);
      if (!mounted || request != _currencyRequest) return;
      setState(() {
        result = ToolResult(
          primary: amount * quote.rate,
          unit: to,
          latex:
              '${amount.toStringAsPrecision(10)}\\times${quote.rate.toStringAsPrecision(10)}',
          details: [
            ResultDetail('From amount', amount, suffix: ' $from'),
            ResultDetail('Reference rate', quote.rate, suffix: ' $to / $from'),
            ResultDetail('Rate date', quote.date),
          ],
          note: quote.cached
              ? 'The network was unavailable, so the last rate loaded during this session is shown.'
              : 'Latest available Frankfurter reference rate. Banks, cards, and cash providers may add spreads or fees.',
        );
        error = null;
        _loading = false;
      });
    } catch (_) {
      if (!mounted || request != _currencyRequest) return;
      setState(() {
        result = null;
        error =
            'The latest exchange rate could not be loaded. Check the connection and try again.';
        _loading = false;
      });
    }
  }

  void _reset() {
    for (final field in widget.tool.fields) {
      if (field.type == ToolFieldType.select) {
        selects[field.id] = field.defaultValue;
      } else {
        controllers[field.id]!.clear();
        if (field.solveToggle) solves[field.id] = field.solveByDefault;
        if (field.type == ToolFieldType.time12) {
          periods[field.id] = field.periodDefault;
        }
      }
    }
    setState(() {});
    _calculate();
  }

  @override
  Widget build(BuildContext context) {
    return _Workbench(
      left: _ToolForm(
        title: 'Your inputs',
        subtitle: 'Change any field to recalculate instantly.',
        error: error,
        note: widget.tool.note,
        actions: [
          OutlinedButton(onPressed: _reset, child: const Text('Reset')),
          FilledButton.icon(
            onPressed: result == null ? null : () => _copy(context),
            icon: const Icon(Icons.copy_rounded, size: 18),
            label: const Text('Copy'),
          ),
          FilledButton.tonalIcon(
            onPressed: result == null ? null : _save,
            icon: const Icon(Icons.history_rounded, size: 18),
            label: const Text('Save'),
          ),
        ],
        child: Column(
          children: widget.tool.fields
              .where((field) => field.isVisible(_values))
              .map(_buildField)
              .toList(),
        ),
      ),
      right: _ResultPanel(
        result: result,
        settings: widget.settings,
        currency: widget.tool.currency,
        toolId: widget.tool.id,
        values: _values,
        showBmiChart: _showBmiChart,
        onToggleBmiChart: widget.tool.id == 'calc-bmi'
            ? () => setState(() => _showBmiChart = !_showBmiChart)
            : null,
        placeholder:
            error ??
            (_loading
                ? 'Loading the latest reference rate…'
                : 'Fill in the fields to see the answer.'),
      ),
    );
  }

  Widget _buildField(ToolField field) {
    if (field.type == ToolFieldType.select) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: _FieldLabel(
          label: field.label,
          help: field.help,
          child: field.segmented
              ? SegmentedButton<String>(
                  segments: field.options
                      .map(
                        (option) => ButtonSegment<String>(
                          value: option.value,
                          label: FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(option.label),
                          ),
                        ),
                      )
                      .toList(),
                  selected: {selects[field.id]!},
                  showSelectedIcon: false,
                  onSelectionChanged: (selection) {
                    setState(() => selects[field.id] = selection.first);
                    _calculate();
                  },
                )
              : DropdownButtonFormField<String>(
                  key: ValueKey('${field.id}-${selects[field.id]}'),
                  initialValue: selects[field.id],
                  isExpanded: true,
                  decoration: const InputDecoration(),
                  selectedItemBuilder: (_) => field.options
                      .map(
                        (option) => Align(
                          alignment: Alignment.centerLeft,
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text(option.label, maxLines: 1),
                          ),
                        ),
                      )
                      .toList(),
                  items: field.options
                      .map(
                        (option) => DropdownMenuItem(
                          value: option.value,
                          child: Text(
                            option.label,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setState(() => selects[field.id] = value);
                      _calculate();
                    }
                  },
                ),
        ),
      );
    }
    final controller = controllers[field.id]!;
    final solving = field.solveToggle && (solves[field.id] ?? false);
    final suffix = field.unit.isEmpty
        ? null
        : ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 116),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerRight,
              child: Text(
                field.unit,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          );
    Widget inputField;
    if (field.type == ToolFieldType.time12) {
      inputField = Row(
        children: [
          Expanded(
            child: TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              inputFormatters: const [_Time12Formatter()],
              style: const TextStyle(fontSize: 16),
              decoration: InputDecoration(hintText: '00:00', suffix: suffix),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 88,
            child: DropdownButtonFormField<String>(
              key: ValueKey('${field.id}-${periods[field.id]}'),
              initialValue: periods[field.id] ?? field.periodDefault,
              decoration: const InputDecoration(),
              items: const [
                DropdownMenuItem(value: 'am', child: Text('AM')),
                DropdownMenuItem(value: 'pm', child: Text('PM')),
              ],
              onChanged: (value) {
                if (value == null) return;
                setState(() => periods[field.id] = value);
                _calculate();
              },
            ),
          ),
        ],
      );
    } else {
      final signedNumber =
          field.type == ToolFieldType.number || field.numericList;
      inputField = TextField(
        controller: controller,
        enabled: !solving,
        readOnly: field.type == ToolFieldType.date || signedNumber,
        showCursor: field.type != ToolFieldType.date,
        keyboardType: signedNumber
            ? const TextInputType.numberWithOptions(decimal: true, signed: true)
            : TextInputType.text,
        style: const TextStyle(fontSize: 16),
        decoration: InputDecoration(
          hintText: 'Example: ${field.defaultValue}',
          suffix: suffix,
          suffixIcon: field.type == ToolFieldType.date
              ? const Icon(Icons.calendar_month_rounded)
              : null,
        ),
        onTap: field.type == ToolFieldType.date
            ? () => _pickDate(controller)
            : signedNumber
            ? () => _showSignedNumberPad(
                context,
                controller,
                allowList: field.numericList,
              )
            : null,
      );
    }
    if (widget.tool.id == 'calc-date-difference' &&
        field.type == ToolFieldType.date) {
      inputField = Align(
        alignment: Alignment.centerLeft,
        child: SizedBox(width: 245, child: inputField),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: _FieldLabel(
        label: field.label,
        help: field.help,
        trailing: field.solveToggle
            ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Checkbox(
                    value: solving,
                    visualDensity: VisualDensity.compact,
                    onChanged: (value) {
                      setState(() => solves[field.id] = value ?? false);
                      _calculate();
                    },
                  ),
                  const Text(
                    'Solve for',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                ],
              )
            : null,
        child: inputField,
      ),
    );
  }

  Future<void> _pickDate(TextEditingController controller) async {
    final current = DateTime.tryParse(controller.text) ?? DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: current,
      firstDate: DateTime(1900),
      lastDate: DateTime(2200),
    );
    if (picked != null)
      controller.text =
          '${picked.year.toString().padLeft(4, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
  }

  Future<void> _copy(BuildContext context) async {
    final current = result;
    if (current == null) return;
    final codeCurrency = widget.tool.id == 'calc-currency';
    final money =
        !codeCurrency && (widget.tool.currency || current.unit.contains(r'$'));
    final primary = current.primary is num
        ? codeCurrency
              ? formatMoney(
                  current.primary as num,
                  separators: widget.settings.separators,
                ).replaceFirst(r'$', '')
              : money
              ? formatMoney(
                  current.primary as num,
                  separators: widget.settings.separators,
                )
              : formatNumber(
                  current.primary as num,
                  precision: widget.settings.precision,
                  separators: widget.settings.separators,
                )
        : current.primary.toString();
    final unit = money
        ? current.unit.replaceFirst(RegExp(r'^\$\s*'), '')
        : current.unit;
    await Clipboard.setData(ClipboardData(text: '$primary $unit'.trim()));
    if (context.mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Result copied')));
  }

  Future<void> _save() async {
    final current = result;
    if (current == null) return;
    final codeCurrency = widget.tool.id == 'calc-currency';
    final money =
        !codeCurrency && (widget.tool.currency || current.unit.contains(r'$'));
    final primary = current.primary is num
        ? codeCurrency
              ? formatMoney(
                  current.primary as num,
                  separators: widget.settings.separators,
                ).replaceFirst(r'$', '')
              : money
              ? formatMoney(
                  current.primary as num,
                  separators: widget.settings.separators,
                )
              : formatNumber(
                  current.primary as num,
                  precision: widget.settings.precision,
                  separators: widget.settings.separators,
                )
        : current.primary.toString();
    final unit = money
        ? current.unit.replaceFirst(RegExp(r'^\$\s*'), '')
        : current.unit;
    await widget.history.addTool(
      widget.tool.title,
      '$primary $unit'.trim(),
      widget.tool.id,
      _values,
    );
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Saved to history')));
    }
  }
}

class _Workbench extends StatelessWidget {
  const _Workbench({required this.left, required this.right});
  final Widget left;
  final Widget right;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 760;
        final children = wide
            ? [
                Expanded(flex: 11, child: left),
                VerticalDivider(
                  width: 1,
                  color: Theme.of(context).colorScheme.outlineVariant,
                ),
                Expanded(flex: 9, child: right),
              ]
            : [
                left,
                Divider(
                  height: 1,
                  color: Theme.of(context).colorScheme.outlineVariant,
                ),
                right,
              ];
        return ClipRRect(
          borderRadius: BorderRadius.circular(27),
          child: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(27),
              border: Border.all(
                color: Theme.of(context).colorScheme.outlineVariant,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: .06),
                  blurRadius: 28,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: wide
                ? IntrinsicHeight(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: children,
                    ),
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: children,
                  ),
          ),
        );
      },
    );
  }
}

class _ToolForm extends StatelessWidget {
  const _ToolForm({
    required this.title,
    required this.subtitle,
    required this.child,
    required this.actions,
    this.error,
    this.note = '',
  });
  final String title;
  final String subtitle;
  final Widget child;
  final List<Widget> actions;
  final String? error;
  final String note;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 20),
          child,
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                error!,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.error,
                  fontSize: 12,
                ),
              ),
            ),
          const SizedBox(height: 12),
          if (actions.length == 3)
            Row(
              children: [
                actions.first,
                const Spacer(),
                Flexible(child: actions[1]),
                const SizedBox(width: 7),
                Flexible(child: actions[2]),
              ],
            )
          else
            Wrap(spacing: 9, runSpacing: 9, children: actions),
          if (note.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.orange.withValues(alpha: .08),
                borderRadius: BorderRadius.circular(13),
                border: Border.all(
                  color: AppTheme.orange.withValues(alpha: .26),
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(
                    Icons.info_outline_rounded,
                    size: 18,
                    color: AppTheme.orangeDark,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      note,
                      style: const TextStyle(fontSize: 12, height: 1.4),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel({
    required this.label,
    required this.child,
    this.help = '',
    this.trailing,
  });
  final String label;
  final String help;
  final Widget child;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                fontWeight: FontWeight.w700,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
      const SizedBox(height: 7),
      child,
      if (help.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(
            help,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ),
    ],
  );
}

class _ResultPanel extends StatelessWidget {
  const _ResultPanel({
    required this.result,
    required this.settings,
    required this.placeholder,
    this.currency = false,
    this.toolId = '',
    this.values = const {},
    this.showBmiChart = false,
    this.onToggleBmiChart,
  });
  final ToolResult? result;
  final SettingsController settings;
  final String placeholder;
  final bool currency;
  final String toolId;
  final Map<String, String> values;
  final bool showBmiChart;
  final VoidCallback? onToggleBmiChart;

  @override
  Widget build(BuildContext context) {
    final current = result;
    if (current == null) {
      return Container(
        constraints: const BoxConstraints(minHeight: 300),
        padding: const EdgeInsets.all(28),
        color: Theme.of(context).colorScheme.surfaceContainerLow,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.auto_awesome_rounded,
                color: AppTheme.orange,
                size: 34,
              ),
              const SizedBox(height: 10),
              Text(
                placeholder,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      );
    }
    final codeCurrency = toolId == 'calc-currency';
    final money = !codeCurrency && (currency || current.unit.contains(r'$'));
    final primary = current.primary is num
        ? codeCurrency
              ? formatMoney(
                  current.primary as num,
                  separators: settings.separators,
                ).replaceFirst(r'$', '')
              : money
              ? formatMoney(
                  current.primary as num,
                  separators: settings.separators,
                )
              : formatNumber(
                  current.primary as num,
                  precision: settings.precision,
                  separators: settings.separators,
                )
        : current.primary.toString();
    final unit = money
        ? current.unit.replaceFirst(RegExp(r'^\$\s*'), '')
        : current.unit;
    return Container(
      padding: const EdgeInsets.all(24),
      color: Theme.of(context).colorScheme.surfaceContainerLow,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (_hasLiveVisual(toolId)) ...[
            _LiveVisual(toolId: toolId, values: values, result: current),
            const SizedBox(height: 16),
          ],
          Text(
            'LIVE RESULT',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.4,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            primary,
            style: Theme.of(context).textTheme.displaySmall?.copyWith(
              fontWeight: FontWeight.w800,
              letterSpacing: -1.5,
            ),
          ),
          Text(
            unit,
            style: const TextStyle(
              color: AppTheme.orangeDark,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (current.latex.isNotEmpty) ...[
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: Theme.of(context).colorScheme.outlineVariant,
                ),
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Math.tex(
                  current.latex,
                  mathStyle: MathStyle.display,
                  textStyle: TextStyle(
                    fontSize: 18,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ),
            ),
          ],
          if (current.details.isNotEmpty) ...[
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: current.details.map((detail) {
                final isMoney = detail.prefix.contains(r'$');
                final codeAmount =
                    codeCurrency && detail.label == 'From amount';
                final value = detail.value is num
                    ? codeAmount
                          ? formatMoney(
                              detail.value as num,
                              separators: settings.separators,
                            ).replaceFirst(r'$', '')
                          : isMoney
                          ? formatMoney(
                              detail.value as num,
                              separators: settings.separators,
                            ).replaceFirst(r'$', '')
                          : formatNumber(
                              detail.value as num,
                              precision: settings.precision,
                              separators: settings.separators,
                            )
                    : detail.value.toString();
                return Container(
                  width: 150,
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: Theme.of(
                      context,
                    ).colorScheme.surface.withValues(alpha: .8),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Theme.of(context).colorScheme.outlineVariant,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        detail.label,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${detail.prefix}$value${detail.suffix}',
                        maxLines: 4,
                        style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
          if (onToggleBmiChart != null) ...[
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: onToggleBmiChart,
              icon: Icon(
                showBmiChart
                    ? Icons.expand_less_rounded
                    : Icons.table_chart_rounded,
              ),
              label: Text(
                showBmiChart ? 'Hide BMI chart' : 'Show full BMI chart',
              ),
            ),
            if (showBmiChart) const _BmiReferenceChart(),
          ],
          if (current.note.isNotEmpty) ...[
            const SizedBox(height: 16),
            Divider(color: Theme.of(context).colorScheme.outlineVariant),
            Text(
              current.note,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

bool _hasLiveVisual(String toolId) => const {
  'calc-circle',
  'calc-rectangle',
  'calc-triangle',
  'calc-trapezoid',
  'calc-sphere',
  'calc-cylinder',
  'calc-cone',
  'calc-rectangular-prism',
  'calc-regular-polygon',
  'calc-quadratic',
  'calc-element-shape',
}.contains(toolId);

class _LiveVisual extends StatefulWidget {
  const _LiveVisual({
    required this.toolId,
    required this.values,
    required this.result,
  });

  final String toolId;
  final Map<String, String> values;
  final ToolResult result;

  @override
  State<_LiveVisual> createState() => _LiveVisualState();
}

class _LiveVisualState extends State<_LiveVisual> {
  final TransformationController _graphTransform = TransformationController();
  late final TextEditingController _referenceController;
  double _referenceSide = 1;

  bool get _quadratic => widget.toolId == 'calc-quadratic';
  bool get _element => widget.toolId == 'calc-element-shape';
  bool get _hasReference => !_quadratic;
  bool get _is3d => const {
    'calc-sphere',
    'calc-cylinder',
    'calc-cone',
    'calc-rectangular-prism',
    'calc-element-shape',
  }.contains(widget.toolId);

  @override
  void initState() {
    super.initState();
    _referenceController = TextEditingController(text: '1')
      ..addListener(_updateReference);
  }

  void _updateReference() {
    final parsed = double.tryParse(_referenceController.text.replaceAll(',', ''));
    if (parsed == null || !parsed.isFinite || parsed <= 0 || !mounted) return;
    setState(() => _referenceSide = parsed.clamp(.000001, 1e9).toDouble());
  }

  @override
  void dispose() {
    _graphTransform.dispose();
    _referenceController
      ..removeListener(_updateReference)
      ..dispose();
    super.dispose();
  }

  String _referenceLabel(double value) {
    if (value >= 100) return value.toStringAsFixed(0);
    if (value >= 10)
      return value.toStringAsFixed(1).replaceFirst(RegExp(r'\.0$'), '');
    if (value >= 1)
      return value
          .toStringAsFixed(2)
          .replaceFirst(RegExp(r'0+$'), '')
          .replaceFirst(RegExp(r'\.$'), '');
    return value
        .toStringAsFixed(3)
        .replaceFirst(RegExp(r'0+$'), '')
        .replaceFirst(RegExp(r'\.$'), '');
  }

  String _quadraticEquation() {
    final a = (widget.result.meta['a'] as num?)?.toDouble() ?? 1;
    final b = (widget.result.meta['b'] as num?)?.toDouble() ?? 0;
    final c = (widget.result.meta['c'] as num?)?.toDouble() ?? 0;
    String number(double value) {
      if (value == value.roundToDouble()) return value.round().toString();
      return value
          .toStringAsFixed(4)
          .replaceFirst(RegExp(r'0+$'), '')
          .replaceFirst(RegExp(r'\.$'), '');
    }

    final bSign = b < 0 ? '−' : '+';
    final cSign = c < 0 ? '−' : '+';
    return 'y = ${number(a)}x² $bSign ${number(b.abs())}x $cSign ${number(c.abs())}';
  }

  double _visualHeight() {
    if (_quadratic) return 278;
    double width = 1;
    double height = 1;
    if (_element) {
      final shape = widget.values['shape'] ?? 'cube';
      switch (shape) {
        case 'cube':
          width = height = _visualNumber(widget.values, 'cubeSide').abs();
        case 'box':
          width = _visualNumber(widget.values, 'boxLength').abs() + .55 * _visualNumber(widget.values, 'boxWidth').abs();
          height = _visualNumber(widget.values, 'boxHeight').abs() + .32 * _visualNumber(widget.values, 'boxWidth').abs();
        case 'sphere':
          width = height = 2 * _visualNumber(widget.values, 'sphereRadius').abs();
        case 'cylinder':
          width = 2 * _visualNumber(widget.values, 'cylinderRadius').abs();
          height = _visualNumber(widget.values, 'cylinderHeight').abs() + .5 * _visualNumber(widget.values, 'cylinderRadius').abs();
        case 'cone':
          width = 2 * _visualNumber(widget.values, 'coneRadius').abs();
          height = _visualNumber(widget.values, 'coneHeight').abs() + .5 * _visualNumber(widget.values, 'coneRadius').abs();
        case 'pyramid':
          width = _visualNumber(widget.values, 'pyramidLength').abs() + .55 * _visualNumber(widget.values, 'pyramidWidth').abs();
          height = _visualNumber(widget.values, 'pyramidHeight').abs() + .32 * _visualNumber(widget.values, 'pyramidWidth').abs();
        case 'triangular':
          width = _visualNumber(widget.values, 'prismLength').abs() + .55 * _visualNumber(widget.values, 'triangleBase').abs();
          height = _visualNumber(widget.values, 'triangleHeight').abs() + .32 * _visualNumber(widget.values, 'triangleBase').abs();
        case 'ellipsoid':
          width = 2 * _visualNumber(widget.values, 'axisA').abs();
          height = 2 * _visualNumber(widget.values, 'axisB').abs();
      }
    }
    switch (widget.toolId) {
      case 'calc-rectangle':
        width = _visualNumber(widget.values, 'length').abs();
        height = _visualNumber(widget.values, 'width').abs();
      case 'calc-trapezoid':
        width = math.max(
          _visualNumber(widget.values, 'a').abs(),
          _visualNumber(widget.values, 'b').abs(),
        );
        height = _visualNumber(widget.values, 'height').abs();
      case 'calc-cylinder' || 'calc-cone':
        width = 2 * _visualNumber(widget.values, 'radius').abs();
        height = _visualNumber(widget.values, 'height').abs();
      case 'calc-rectangular-prism':
        width =
            _visualNumber(widget.values, 'length').abs() +
            .55 * _visualNumber(widget.values, 'width').abs();
        height =
            _visualNumber(widget.values, 'height').abs() +
            .32 * _visualNumber(widget.values, 'width').abs();
    }
    final ratio = height / math.max(width, .000001);
    return (220 + math.max(0, ratio - 1) * 24).clamp(220, 390).toDouble();
  }

  @override
  Widget build(BuildContext context) {
    final reference = _referenceSide;
    final painter = switch (widget.toolId) {
      'calc-quadratic' => _QuadraticPainter(widget.result.meta),
      'calc-element-shape' => _ElementShapePainter(
        widget.values,
        widget.result.meta,
        reference,
      ),
      _ => _GeometryPainter(
        widget.toolId,
        widget.values,
        widget.result.meta,
        reference,
      ),
    };
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 7),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _quadratic ? 'LIVE GRAPH · 0.2 SUBDIVISIONS' : 'LIVE VISUAL',
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 5),
          SizedBox(
            height: _visualHeight(),
            width: double.infinity,
            child: _quadratic
                ? LayoutBuilder(
                    builder: (context, constraints) => ClipRect(
                      child: InteractiveViewer(
                        transformationController: _graphTransform,
                        minScale: .85,
                        maxScale: 6,
                        panEnabled: true,
                        scaleEnabled: true,
                        panAxis: PanAxis.free,
                        boundaryMargin: const EdgeInsets.all(180),
                        interactionEndFrictionCoefficient: .00001,
                        child: SizedBox(
                          width: constraints.maxWidth,
                          height: constraints.maxHeight,
                          child: CustomPaint(painter: painter),
                        ),
                      ),
                    ),
                  )
                : CustomPaint(painter: painter),
          ),
          if (_quadratic) ...[
            Row(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Text(
                      _quadraticEquation(),
                      maxLines: 1,
                      softWrap: false,
                      style: const TextStyle(
                        color: Color(0xFFD73C32),
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Reset graph zoom',
                  onPressed: () {
                    final reset = _graphTransform.value.clone()..setIdentity();
                    _graphTransform.value = reset;
                  },
                  icon: const Icon(Icons.center_focus_strong_rounded, size: 18),
                ),
              ],
            ),
            Text(
              'Pinch to zoom and drag to inspect the graph. Red dot = apex.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
          if (_hasReference) ...[
            const SizedBox(height: 7),
            Row(
              children: [
                Text(
                  'Reference side',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  width: 82,
                  child: TextField(
                    controller: _referenceController,
                    readOnly: true,
                    showCursor: true,
                    textAlign: TextAlign.right,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                    decoration: const InputDecoration(isDense: true, contentPadding: EdgeInsets.symmetric(horizontal: 9, vertical: 8)),
                    onTap: () => _showSignedNumberPad(context, _referenceController),
                  ),
                ),
                const SizedBox(width: 5),
                Text(
                  _element ? (widget.values['dimensionUnit'] ?? 'units') : 'units',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
            Text(
              'Red ${_is3d ? 'cube' : 'square'} side = ${_referenceLabel(reference)} unit${reference == 1 ? '' : 's'} · Green dimensions retain their entered proportions.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

double _visualNumber(
  Map<String, String> values,
  String id, [
  double fallback = 1,
]) => double.tryParse((values[id] ?? '').replaceAll(',', '')) ?? fallback;

class _GeometryPainter extends CustomPainter {
  const _GeometryPainter(
    this.toolId,
    this.values,
    this.meta,
    this.referenceSide,
  );
  final String toolId;
  final Map<String, String> values;
  final Map<String, Object> meta;
  final double referenceSide;

  Rect _boundsOf(Iterable<Offset> points) {
    final list = points.toList();
    final xs = list.map((point) => point.dx);
    final ys = list.map((point) => point.dy);
    final minX = xs.reduce(math.min);
    final maxX = xs.reduce(math.max);
    final minY = ys.reduce(math.min);
    final maxY = ys.reduce(math.max);
    return Rect.fromLTRB(minX, minY, maxX, maxY);
  }

  double _fitScale(
    Rect shapeArea,
    Rect shapeBounds,
    Rect referenceArea,
    Rect referenceBounds,
  ) {
    double fit(Rect area, Rect bounds) {
      final width = bounds.width.abs();
      final height = bounds.height.abs();
      final horizontal = width <= 1e-10 ? double.infinity : area.width / width;
      final vertical = height <= 1e-10 ? double.infinity : area.height / height;
      return math.min(horizontal, vertical);
    }

    final fitted = math.min(
      fit(shapeArea, shapeBounds),
      fit(referenceArea, referenceBounds),
    );
    return (fitted.isFinite && fitted > 0 ? fitted : 1) * .84;
  }

  Offset _origin(Rect area, Rect bounds, double scale) => Offset(
    area.center.dx - bounds.center.dx * scale,
    area.center.dy - bounds.center.dy * scale,
  );

  Offset _map(Offset point, Offset origin, double scale) =>
      Offset(origin.dx + point.dx * scale, origin.dy + point.dy * scale);

  Path _path(List<Offset> points, Offset origin, double scale) {
    final first = _map(points.first, origin, scale);
    final path = Path()..moveTo(first.dx, first.dy);
    for (final point in points.skip(1)) {
      final mapped = _map(point, origin, scale);
      path.lineTo(mapped.dx, mapped.dy);
    }
    return path..close();
  }

  Offset _iso(double x, double y, double z) =>
      Offset(x + .55 * z, -y + .32 * z);

  List<Offset> _isoVertices(double length, double height, double depth) => [
    _iso(0, 0, 0),
    _iso(length, 0, 0),
    _iso(0, height, 0),
    _iso(0, 0, depth),
    _iso(length, height, 0),
    _iso(length, 0, depth),
    _iso(0, height, depth),
    _iso(length, height, depth),
  ];

  void _drawIsoPrism(
    Canvas canvas,
    Rect area,
    double length,
    double height,
    double depth,
    double scale,
    Paint stroke, [
    Paint? fill,
  ]) {
    final vertices = _isoVertices(length, height, depth);
    final bounds = _boundsOf(vertices);
    final origin = _origin(area, bounds, scale);
    final faces = <List<Offset>>[
      [vertices[0], vertices[1], vertices[4], vertices[2]],
      [vertices[1], vertices[5], vertices[7], vertices[4]],
      [vertices[2], vertices[4], vertices[7], vertices[6]],
    ];
    for (final face in faces) {
      final path = _path(face, origin, scale);
      if (fill != null) canvas.drawPath(path, fill);
      canvas.drawPath(path, stroke);
    }
    for (final edge in const <(int, int)>[
      (0, 3),
      (3, 5),
      (3, 6),
      (5, 7),
      (6, 7),
    ]) {
      canvas.drawLine(
        _map(vertices[edge.$1], origin, scale),
        _map(vertices[edge.$2], origin, scale),
        stroke,
      );
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final greenFill = Paint()
      ..color = const Color(0x5539A96B)
      ..style = PaintingStyle.fill;
    final green = Paint()
      ..color = const Color(0xFF238B57)
      ..strokeWidth = 2.4
      ..style = PaintingStyle.stroke;
    final red = Paint()
      ..color = const Color(0xFFD73C32)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final redFill = Paint()
      ..color = const Color(0x33D73C32)
      ..style = PaintingStyle.fill;
    final shapeArea = Rect.fromLTWH(
      10,
      8,
      size.width * .70 - 16,
      size.height - 38,
    );
    final referenceArea = Rect.fromLTWH(
      size.width * .70 + 7,
      8,
      size.width * .30 - 17,
      size.height - 38,
    );
    final reference = math.max(referenceSide.abs(), 1e-10);

    void drawPlanar(List<Offset> points) {
      final shapeBounds = _boundsOf(points);
      final referenceBounds = Rect.fromLTWH(0, 0, reference, reference);
      final scale = _fitScale(
        shapeArea,
        shapeBounds,
        referenceArea,
        referenceBounds,
      );
      final shapeOrigin = _origin(shapeArea, shapeBounds, scale);
      final shapePath = _path(points, shapeOrigin, scale);
      canvas.drawPath(shapePath, greenFill);
      canvas.drawPath(shapePath, green);
      final referenceOrigin = _origin(referenceArea, referenceBounds, scale);
      final referenceRect = Rect.fromLTWH(
          referenceOrigin.dx,
          referenceOrigin.dy,
          reference * scale,
          reference * scale,
        );
      canvas.drawRect(referenceRect, redFill);
      canvas.drawRect(referenceRect, red);
    }

    switch (toolId) {
      case 'calc-circle':
        final radius = _visualNumber(values, 'radius').abs();
        final diameter = 2 * radius;
        final shapeBounds = Rect.fromLTWH(0, 0, diameter, diameter);
        final referenceBounds = Rect.fromLTWH(0, 0, reference, reference);
        final scale = _fitScale(
          shapeArea,
          shapeBounds,
          referenceArea,
          referenceBounds,
        );
        final shapeOrigin = _origin(shapeArea, shapeBounds, scale);
        canvas.drawOval(
          Rect.fromLTWH(
            shapeOrigin.dx,
            shapeOrigin.dy,
            diameter * scale,
            diameter * scale,
          ),
          greenFill,
        );
        canvas.drawOval(
          Rect.fromLTWH(
            shapeOrigin.dx,
            shapeOrigin.dy,
            diameter * scale,
            diameter * scale,
          ),
          green,
        );
        final referenceOrigin = _origin(referenceArea, referenceBounds, scale);
        final referenceRect = Rect.fromLTWH(
            referenceOrigin.dx,
            referenceOrigin.dy,
            reference * scale,
            reference * scale,
          );
        canvas.drawRect(referenceRect, redFill);
        canvas.drawRect(referenceRect, red);
      case 'calc-rectangle':
        final length = _visualNumber(values, 'length').abs();
        final width = _visualNumber(values, 'width').abs();
        drawPlanar([
          Offset.zero,
          Offset(length, 0),
          Offset(length, width),
          Offset(0, width),
        ]);
      case 'calc-triangle':
        final sides = meta['sides'];
        final angles = meta['angles'];
        var a = 3.0;
        var b = 4.0;
        var c = 5.0;
        var angleA = 36.87;
        var angleB = 53.13;
        var angleC = 90.0;
        if (sides is List && sides.length == 3) {
          a = (sides[0] as num).toDouble();
          b = (sides[1] as num).toDouble();
          c = (sides[2] as num).toDouble();
        }
        if (angles is List && angles.length == 3) {
          angleA = (angles[0] as num).toDouble();
          angleB = (angles[1] as num).toDouble();
          angleC = (angles[2] as num).toDouble();
        }
        final x = (b * b + c * c - a * a) / (2 * c);
        final y = math.sqrt(math.max(0, b * b - x * x));
        final points = [Offset.zero, Offset(c, 0), Offset(x, -y)];
        final shapeBounds = _boundsOf(points);
        final referenceBounds = Rect.fromLTWH(0, 0, reference, reference);
        final scale = _fitScale(shapeArea, shapeBounds, referenceArea, referenceBounds) * .88;
        final shapeOrigin = _origin(shapeArea, shapeBounds, scale);
        final mapped = points.map((point) => _map(point, shapeOrigin, scale)).toList();
        final shapePath = _path(points, shapeOrigin, scale);
        canvas.drawPath(shapePath, greenFill);
        canvas.drawPath(shapePath, green);
        final referenceOrigin = _origin(referenceArea, referenceBounds, scale);
        final referenceRect = Rect.fromLTWH(referenceOrigin.dx, referenceOrigin.dy, reference * scale, reference * scale);
        canvas.drawRect(referenceRect, redFill);
        canvas.drawRect(referenceRect, red);
        Offset midpoint(Offset first, Offset second) => Offset((first.dx + second.dx) / 2, (first.dy + second.dy) / 2);
        _paintCenteredLabel(canvas, 'Leg 3 (c)', midpoint(mapped[0], mapped[1]) + const Offset(0, 12), const Color(0xFF3F4842));
        _paintCenteredLabel(canvas, 'Leg 2 (b)', midpoint(mapped[0], mapped[2]) + const Offset(-22, -1), const Color(0xFF3F4842));
        _paintCenteredLabel(canvas, 'Leg 1 (a)', midpoint(mapped[1], mapped[2]) + const Offset(22, -1), const Color(0xFF3F4842));
        _paintCenteredLabel(canvas, 'A · ∠1 ${_visualCompact(angleA)}°', mapped[0] + const Offset(24, -12), const Color(0xFF3F4842));
        _paintCenteredLabel(canvas, 'B · ∠2 ${_visualCompact(angleB)}°', mapped[1] + const Offset(-24, -12), const Color(0xFF3F4842));
        _paintCenteredLabel(canvas, 'C · ∠3 ${_visualCompact(angleC)}°', mapped[2] + const Offset(0, 12), const Color(0xFF3F4842));
      case 'calc-trapezoid':
        final a = _visualNumber(values, 'a').abs();
        final b = _visualNumber(values, 'b').abs();
        final height = _visualNumber(values, 'height').abs();
        drawPlanar([
          Offset(-a / 2, height / 2),
          Offset(a / 2, height / 2),
          Offset(b / 2, -height / 2),
          Offset(-b / 2, -height / 2),
        ]);
      case 'calc-regular-polygon':
        final count =
            (meta['sides'] as num?)?.toInt() ??
            _visualNumber(values, 'sides', 6).round().clamp(3, 30);
        final side = _visualNumber(values, 'length').abs();
        final radius = side / (2 * math.sin(math.pi / count));
        final points = <Offset>[];
        for (var index = 0; index < count; index += 1) {
          final angle = -math.pi / 2 + 2 * math.pi * index / count;
          points.add(
            Offset(radius * math.cos(angle), radius * math.sin(angle)),
          );
        }
        drawPlanar(points);
      case 'calc-sphere':
        final radius = _visualNumber(values, 'radius').abs();
        final sphereBounds = Rect.fromLTWH(
          -radius,
          -radius,
          2 * radius,
          2 * radius,
        );
        final referenceBounds = _boundsOf(
          _isoVertices(reference, reference, reference),
        );
        final scale = _fitScale(
          shapeArea,
          sphereBounds,
          referenceArea,
          referenceBounds,
        );
        final origin = _origin(shapeArea, sphereBounds, scale);
        final rect = Rect.fromLTWH(
          origin.dx - radius * scale,
          origin.dy - radius * scale,
          2 * radius * scale,
          2 * radius * scale,
        );
        canvas.drawOval(rect, greenFill);
        canvas.drawOval(rect, green);
        canvas.drawOval(
          Rect.fromCenter(
            center: rect.center,
            width: rect.width,
            height: rect.height * .3,
          ),
          green,
        );
        canvas.drawArc(rect, -.65, 1.3, false, green);
        _drawIsoPrism(
          canvas,
          referenceArea,
          reference,
          reference,
          reference,
          scale,
          red,
          redFill,
        );
      case 'calc-cylinder':
        final radius = _visualNumber(values, 'radius').abs();
        final height = _visualNumber(values, 'height').abs();
        final ellipseHeight = radius * .56;
        final cylinderBounds = Rect.fromLTWH(
          -radius,
          -height / 2 - ellipseHeight / 2,
          2 * radius,
          height + ellipseHeight,
        );
        final referenceBounds = _boundsOf(
          _isoVertices(reference, reference, reference),
        );
        final scale = _fitScale(
          shapeArea,
          cylinderBounds,
          referenceArea,
          referenceBounds,
        );
        final origin = _origin(shapeArea, cylinderBounds, scale);
        final top = Rect.fromCenter(
          center: _map(Offset(0, -height / 2), origin, scale),
          width: 2 * radius * scale,
          height: ellipseHeight * scale,
        );
        final bottom = Rect.fromCenter(
          center: _map(Offset(0, height / 2), origin, scale),
          width: 2 * radius * scale,
          height: ellipseHeight * scale,
        );
        canvas.drawRect(
          Rect.fromLTRB(top.left, top.center.dy, top.right, bottom.center.dy),
          greenFill,
        );
        canvas.drawOval(top, greenFill);
        canvas.drawOval(bottom, greenFill);
        canvas.drawLine(
          Offset(top.left, top.center.dy),
          Offset(bottom.left, bottom.center.dy),
          green,
        );
        canvas.drawLine(
          Offset(top.right, top.center.dy),
          Offset(bottom.right, bottom.center.dy),
          green,
        );
        canvas.drawOval(top, green);
        canvas.drawOval(bottom, green);
        _drawIsoPrism(
          canvas,
          referenceArea,
          reference,
          reference,
          reference,
          scale,
          red,
          redFill,
        );
      case 'calc-cone':
        final radius = _visualNumber(values, 'radius').abs();
        final height = _visualNumber(values, 'height').abs();
        final ellipseHeight = radius * .56;
        final coneBounds = Rect.fromLTWH(
          -radius,
          -height / 2,
          2 * radius,
          height + ellipseHeight / 2,
        );
        final referenceBounds = _boundsOf(
          _isoVertices(reference, reference, reference),
        );
        final scale = _fitScale(
          shapeArea,
          coneBounds,
          referenceArea,
          referenceBounds,
        );
        final origin = _origin(shapeArea, coneBounds, scale);
        final top = _map(Offset(0, -height / 2), origin, scale);
        final base = Rect.fromCenter(
          center: _map(Offset(0, height / 2), origin, scale),
          width: 2 * radius * scale,
          height: ellipseHeight * scale,
        );
        final path = Path()
          ..moveTo(top.dx, top.dy)
          ..lineTo(base.left, base.center.dy)
          ..quadraticBezierTo(
            base.center.dx,
            base.bottom,
            base.right,
            base.center.dy,
          )
          ..close();
        canvas.drawPath(path, greenFill);
        canvas.drawPath(path, green);
        canvas.drawOval(base, green);
        _drawIsoPrism(
          canvas,
          referenceArea,
          reference,
          reference,
          reference,
          scale,
          red,
          redFill,
        );
      case 'calc-rectangular-prism':
        final length = _visualNumber(values, 'length').abs();
        final width = _visualNumber(values, 'width').abs();
        final height = _visualNumber(values, 'height').abs();
        final shapeBounds = _boundsOf(_isoVertices(length, height, width));
        final referenceBounds = _boundsOf(
          _isoVertices(reference, reference, reference),
        );
        final scale = _fitScale(
          shapeArea,
          shapeBounds,
          referenceArea,
          referenceBounds,
        );
        _drawIsoPrism(
          canvas,
          shapeArea,
          length,
          height,
          width,
          scale,
          green,
          greenFill,
        );
        _drawIsoPrism(
          canvas,
          referenceArea,
          reference,
          reference,
          reference,
          scale,
          red,
          redFill,
        );
    }
    _paintCenteredLabel(
      canvas,
      'Reference ${_visualCompact(reference)}×${_visualCompact(reference)}${const {'calc-sphere', 'calc-cylinder', 'calc-cone', 'calc-rectangular-prism'}.contains(toolId) ? '×${_visualCompact(reference)}' : ''}',
      Offset(referenceArea.center.dx, size.height - 18),
      const Color(0xFFD73C32),
    );
  }

  @override
  bool shouldRepaint(covariant _GeometryPainter oldDelegate) =>
      oldDelegate.toolId != toolId ||
      oldDelegate.values.toString() != values.toString() ||
      oldDelegate.meta.toString() != meta.toString() ||
      oldDelegate.referenceSide != referenceSide;
}

String _visualCompact(double value) => value
    .toStringAsFixed(value.abs() < 1 ? 4 : 2)
    .replaceFirst(RegExp(r'0+$'), '')
    .replaceFirst(RegExp(r'\.$'), '');

void _paintCenteredLabel(Canvas canvas, String text, Offset center, Color color) {
  final painter = TextPainter(
    text: TextSpan(
      text: text,
      style: TextStyle(color: color, fontSize: 9, fontWeight: FontWeight.w400),
    ),
    textDirection: TextDirection.ltr,
  )..layout();
  painter.paint(canvas, Offset(center.dx - painter.width / 2, center.dy - painter.height / 2));
}

class _QuadraticPainter extends CustomPainter {
  const _QuadraticPainter(this.meta);
  final Map<String, Object> meta;

  @override
  void paint(Canvas canvas, Size size) {
    final plot = Rect.fromLTRB(35, 12, size.width - 12, size.height - 27);
    const xMin = -10.0;
    const xMax = 10.0;
    const yMin = -10.0;
    const yMax = 10.0;
    double sx(double x) => plot.left + (x - xMin) / (xMax - xMin) * plot.width;
    double sy(double y) =>
        plot.bottom - (y - yMin) / (yMax - yMin) * plot.height;

    final grid = Paint()
      ..color = const Color(0x2A68717A)
      ..strokeWidth = .75
      ..isAntiAlias = false;
    final dots = Paint()
      ..color = const Color(0x3D68717A)
      ..isAntiAlias = true;
    final axis = Paint()
      ..color = const Color(0xFF68717A)
      ..strokeWidth = 1.7
      ..isAntiAlias = false;

    canvas.save();
    canvas.clipRect(plot);
    for (var xStep = -50; xStep <= 50; xStep += 1) {
      final x = xStep / 5;
      for (var yStep = -50; yStep <= 50; yStep += 1) {
        final y = yStep / 5;
        canvas.drawCircle(Offset(sx(x), sy(y)), .42, dots);
      }
    }
    for (var x = -10; x <= 10; x += 1) {
      canvas.drawLine(
        Offset(sx(x.toDouble()), plot.top),
        Offset(sx(x.toDouble()), plot.bottom),
        grid,
      );
    }
    for (var y = -10; y <= 10; y += 1) {
      canvas.drawLine(
        Offset(plot.left, sy(y.toDouble())),
        Offset(plot.right, sy(y.toDouble())),
        grid,
      );
    }
    canvas.drawLine(Offset(plot.left, sy(0)), Offset(plot.right, sy(0)), axis);
    canvas.drawLine(Offset(sx(0), plot.top), Offset(sx(0), plot.bottom), axis);

    final a = (meta['a'] as num?)?.toDouble() ?? 1;
    final b = (meta['b'] as num?)?.toDouble() ?? 0;
    final c = (meta['c'] as num?)?.toDouble() ?? 0;
    final curve = Paint()
      ..color = const Color(0xFF238B57)
      ..strokeWidth = 1.9
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true;
    final path = Path();
    var started = false;
    final samples = math.max(1200, (plot.width * 5).round());
    for (var step = 0; step <= samples; step += 1) {
      final x = xMin + (xMax - xMin) * step / samples;
      final y = a * x * x + b * x + c;
      if (y < yMin - .5 || y > yMax + .5) {
        started = false;
        continue;
      }
      final point = Offset(sx(x), sy(y));
      if (!started) {
        path.moveTo(point.dx, point.dy);
        started = true;
      } else {
        path.lineTo(point.dx, point.dy);
      }
    }
    canvas.drawPath(path, curve);
    if (a.abs() > 1e-12) {
      final vertexX = -b / (2 * a);
      final vertexY = a * vertexX * vertexX + b * vertexX + c;
      if (vertexX >= xMin &&
          vertexX <= xMax &&
          vertexY >= yMin &&
          vertexY <= yMax) {
        canvas.drawCircle(
          Offset(sx(vertexX), sy(vertexY)),
          3.8,
          Paint()
            ..color = const Color(0xFFD73C32)
            ..isAntiAlias = true,
        );
      }
    }
    canvas.restore();

    for (var x = -10; x <= 10; x += 1) {
      if (x == 0) continue;
      _paintGraphLabel(
        canvas,
        '$x',
        Offset(sx(x.toDouble()), sy(0) + 7),
        centered: true,
      );
    }
    for (var y = -10; y <= 10; y += 2) {
      if (y == 0) continue;
      _paintGraphLabel(
        canvas,
        '$y',
        Offset(plot.left - 6, sy(y.toDouble())),
        alignRight: true,
      );
    }
    _paintGraphLabel(canvas, '0', Offset(sx(0) - 6, sy(0) + 7));
  }

  @override
  bool shouldRepaint(covariant _QuadraticPainter oldDelegate) =>
      oldDelegate.meta.toString() != meta.toString();
}

void _paintGraphLabel(
  Canvas canvas,
  String text,
  Offset anchor, {
  bool centered = false,
  bool alignRight = false,
}) {
  final painter = TextPainter(
    text: TextSpan(
      text: text,
      style: const TextStyle(
        color: Color(0xFF68717A),
        fontSize: 8.5,
        fontWeight: FontWeight.w400,
        height: 1,
      ),
    ),
    textDirection: TextDirection.ltr,
  )..layout();
  var dx = anchor.dx;
  if (centered) dx -= painter.width / 2;
  if (alignRight) dx -= painter.width;
  painter.paint(canvas, Offset(dx, anchor.dy - painter.height / 2));
}

class _ElementShapePainter extends CustomPainter {
  const _ElementShapePainter(this.values, this.meta, this.referenceSide);
  final Map<String, String> values;
  final Map<String, Object> meta;
  final double referenceSide;

  Color _materialColor() => switch (meta['element']) {
    'Au' => const Color(0xFFFFC72C),
    'Ag' => const Color(0xFFC9D1D7),
    'Cu' => const Color(0xFFC87548),
    'C' => const Color(0xFF25282B),
    'Pb' => const Color(0xFF6D737B),
    'Fe' => const Color(0xFF777C80),
    'Al' => const Color(0xFFB8C0C8),
    'S' => const Color(0xFFE5D52A),
    'Br' => const Color(0xFF8B2C1D),
    _ => const Color(0xFF7696A8),
  };

  Rect _boundsOf(Iterable<Offset> points) {
    final list = points.toList();
    return Rect.fromLTRB(
      list.map((point) => point.dx).reduce(math.min),
      list.map((point) => point.dy).reduce(math.min),
      list.map((point) => point.dx).reduce(math.max),
      list.map((point) => point.dy).reduce(math.max),
    );
  }

  Offset _iso(double x, double y, double z) => Offset(x + .55 * z, -y + .32 * z);

  List<Offset> _boxVertices(double length, double height, double depth) => [
    _iso(0, 0, 0),
    _iso(length, 0, 0),
    _iso(0, height, 0),
    _iso(0, 0, depth),
    _iso(length, height, 0),
    _iso(length, 0, depth),
    _iso(0, height, depth),
    _iso(length, height, depth),
  ];

  double _fit(Rect shapeArea, Rect shapeBounds, Rect referenceArea, Rect referenceBounds) {
    double fitOne(Rect area, Rect bounds) => math.min(
      area.width / math.max(bounds.width.abs(), 1e-10),
      area.height / math.max(bounds.height.abs(), 1e-10),
    );

    return math.min(fitOne(shapeArea, shapeBounds), fitOne(referenceArea, referenceBounds)) * .82;
  }

  Offset _origin(Rect area, Rect bounds, double scale) => Offset(
    area.center.dx - bounds.center.dx * scale,
    area.center.dy - bounds.center.dy * scale,
  );

  Offset _map(Offset point, Offset origin, double scale) => Offset(origin.dx + point.dx * scale, origin.dy + point.dy * scale);

  Path _path(List<Offset> points, Offset origin, double scale) {
    final first = _map(points.first, origin, scale);
    final path = Path()..moveTo(first.dx, first.dy);
    for (final point in points.skip(1)) {
      final mapped = _map(point, origin, scale);
      path.lineTo(mapped.dx, mapped.dy);
    }
    return path..close();
  }

  void _drawFaces(Canvas canvas, List<Offset> vertices, List<List<int>> faces, Rect area, double scale, Paint fill, Paint stroke) {
    final origin = _origin(area, _boundsOf(vertices), scale);
    for (final face in faces) {
      final path = _path(face.map((index) => vertices[index]).toList(), origin, scale);
      canvas.drawPath(path, fill);
      canvas.drawPath(path, stroke);
    }
  }

  void _drawBox(Canvas canvas, Rect area, double length, double height, double depth, double scale, Paint fill, Paint stroke) {
    final vertices = _boxVertices(length, height, depth);
    _drawFaces(canvas, vertices, const [[0, 1, 4, 2], [1, 5, 7, 4], [2, 4, 7, 6]], area, scale, fill, stroke);
    final origin = _origin(area, _boundsOf(vertices), scale);
    for (final edge in const <(int, int)>[(0, 3), (3, 5), (3, 6), (5, 7), (6, 7)]) {
      canvas.drawLine(_map(vertices[edge.$1], origin, scale), _map(vertices[edge.$2], origin, scale), stroke);
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final color = _materialColor();
    final shapeArea = Rect.fromLTWH(10, 8, size.width * .70 - 16, size.height - 38);
    final referenceArea = Rect.fromLTWH(size.width * .70 + 7, 8, size.width * .30 - 17, size.height - 38);
    final reference = math.max(referenceSide.abs(), 1e-10);
    final referenceBounds = _boundsOf(_boxVertices(reference, reference, reference));
    final materialFill = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color.lerp(color, Colors.white, meta['element'] == 'C' ? .08 : .48)!,
          color,
          Color.lerp(color, Colors.black, .32)!,
        ],
        stops: const [0, .5, 1],
      ).createShader(shapeArea)
      ..style = PaintingStyle.fill;
    final materialStroke = Paint()
      ..color = Color.lerp(color, Colors.black, .48)!
      ..strokeWidth = 2.1
      ..style = PaintingStyle.stroke;
    final redFill = Paint()
      ..color = const Color(0x33D73C32)
      ..style = PaintingStyle.fill;
    final redStroke = Paint()
      ..color = const Color(0xFFD73C32)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final shape = values['shape'] ?? 'cube';
    Rect shapeBounds;
    late double scale;
    if (shape == 'cube' || shape == 'box') {
      final length = shape == 'cube' ? _visualNumber(values, 'cubeSide').abs() : _visualNumber(values, 'boxLength').abs();
      final height = shape == 'cube' ? length : _visualNumber(values, 'boxHeight').abs();
      final depth = shape == 'cube' ? length : _visualNumber(values, 'boxWidth').abs();
      shapeBounds = _boundsOf(_boxVertices(length, height, depth));
      scale = _fit(shapeArea, shapeBounds, referenceArea, referenceBounds);
      _drawBox(canvas, shapeArea, length, height, depth, scale, materialFill, materialStroke);
    } else if (shape == 'sphere' || shape == 'ellipsoid') {
      final a = shape == 'sphere' ? _visualNumber(values, 'sphereRadius').abs() : _visualNumber(values, 'axisA').abs();
      final b = shape == 'sphere' ? a : _visualNumber(values, 'axisB').abs();
      final c = shape == 'sphere' ? a : _visualNumber(values, 'axisC').abs();
      final projectedWidth = 2 * math.hypot(a, .55 * c);
      final projectedHeight = 2 * math.hypot(b, .32 * c);
      shapeBounds = Rect.fromLTWH(0, 0, projectedWidth, projectedHeight);
      scale = _fit(shapeArea, shapeBounds, referenceArea, referenceBounds);
      final origin = _origin(shapeArea, shapeBounds, scale);
      final rect = Rect.fromLTWH(origin.dx, origin.dy, projectedWidth * scale, projectedHeight * scale);
      canvas.drawOval(rect, materialFill);
      canvas.drawOval(rect, materialStroke);
      canvas.drawOval(Rect.fromCenter(center: rect.center, width: rect.width, height: math.max(2, c * .55 * scale)), materialStroke);
    } else if (shape == 'cylinder' || shape == 'cone') {
      final radius = _visualNumber(values, shape == 'cylinder' ? 'cylinderRadius' : 'coneRadius').abs();
      final height = _visualNumber(values, shape == 'cylinder' ? 'cylinderHeight' : 'coneHeight').abs();
      final ellipseHeight = radius * .56;
      shapeBounds = Rect.fromLTWH(-radius, -height / 2 - ellipseHeight / 2, 2 * radius, height + ellipseHeight);
      scale = _fit(shapeArea, shapeBounds, referenceArea, referenceBounds);
      final origin = _origin(shapeArea, shapeBounds, scale);
      final top = shape == 'cone'
          ? _map(Offset(0, -height / 2), origin, scale)
          : null;
      final topOval = Rect.fromCenter(center: _map(Offset(0, -height / 2), origin, scale), width: 2 * radius * scale, height: ellipseHeight * scale);
      final bottomOval = Rect.fromCenter(center: _map(Offset(0, height / 2), origin, scale), width: 2 * radius * scale, height: ellipseHeight * scale);
      if (shape == 'cylinder') {
        canvas.drawRect(Rect.fromLTRB(topOval.left, topOval.center.dy, topOval.right, bottomOval.center.dy), materialFill);
        canvas.drawOval(topOval, materialFill);
        canvas.drawLine(Offset(topOval.left, topOval.center.dy), Offset(bottomOval.left, bottomOval.center.dy), materialStroke);
        canvas.drawLine(Offset(topOval.right, topOval.center.dy), Offset(bottomOval.right, bottomOval.center.dy), materialStroke);
        canvas.drawOval(topOval, materialStroke);
        canvas.drawOval(bottomOval, materialStroke);
      } else {
        final path = Path()
          ..moveTo(top!.dx, top.dy)
          ..lineTo(bottomOval.left, bottomOval.center.dy)
          ..quadraticBezierTo(bottomOval.center.dx, bottomOval.bottom, bottomOval.right, bottomOval.center.dy)
          ..close();
        canvas.drawPath(path, materialFill);
        canvas.drawPath(path, materialStroke);
        canvas.drawOval(bottomOval, materialStroke);
      }
    } else if (shape == 'pyramid') {
      final length = _visualNumber(values, 'pyramidLength').abs();
      final depth = _visualNumber(values, 'pyramidWidth').abs();
      final height = _visualNumber(values, 'pyramidHeight').abs();
      final points = [_iso(0, 0, 0), _iso(length, 0, 0), _iso(length, 0, depth), _iso(0, 0, depth), _iso(length / 2, height, depth / 2)];
      shapeBounds = _boundsOf(points);
      scale = _fit(shapeArea, shapeBounds, referenceArea, referenceBounds);
      _drawFaces(canvas, points, const [[0, 1, 4], [1, 2, 4], [2, 3, 4], [3, 0, 4]], shapeArea, scale, materialFill, materialStroke);
    } else {
      final base = _visualNumber(values, 'triangleBase').abs();
      final height = _visualNumber(values, 'triangleHeight').abs();
      final length = _visualNumber(values, 'prismLength').abs();
      final points = [_iso(0, 0, 0), _iso(0, 0, base), _iso(0, height, base / 2), _iso(length, 0, 0), _iso(length, 0, base), _iso(length, height, base / 2)];
      shapeBounds = _boundsOf(points);
      scale = _fit(shapeArea, shapeBounds, referenceArea, referenceBounds);
      _drawFaces(canvas, points, const [[0, 1, 2], [3, 5, 4], [0, 3, 4, 1], [1, 4, 5, 2], [2, 5, 3, 0]], shapeArea, scale, materialFill, materialStroke);
    }
    _drawBox(canvas, referenceArea, reference, reference, reference, scale, redFill, redStroke);
    _paintCenteredLabel(canvas, '${meta['element'] ?? ''} · ${meta['phase'] ?? ''}', Offset(shapeArea.center.dx, size.height - 18), color);
    _paintCenteredLabel(canvas, 'Reference ${_visualCompact(reference)}³', Offset(referenceArea.center.dx, size.height - 18), const Color(0xFFD73C32));
  }

  @override
  bool shouldRepaint(covariant _ElementShapePainter oldDelegate) =>
      oldDelegate.values.toString() != values.toString() ||
      oldDelegate.meta.toString() != meta.toString() ||
      oldDelegate.referenceSide != referenceSide;
}

class _BmiReferenceChart extends StatelessWidget {
  const _BmiReferenceChart();

  @override
  Widget build(BuildContext context) {
    const rows = <(String, String)>[
      ('Below healthy range', '< 18.5'),
      ('Healthy range', '18.5–24.9'),
      ('Overweight range', '25.0–29.9'),
      ('Obesity class 1', '30.0–34.9'),
      ('Obesity class 2', '35.0–39.9'),
      ('Obesity class 3', '40.0 or higher'),
    ];
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Adult BMI screening reference',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Table(
            border: TableBorder.all(
              color: Theme.of(context).colorScheme.outlineVariant,
              borderRadius: BorderRadius.circular(8),
            ),
            columnWidths: const {
              0: FlexColumnWidth(1.5),
              1: FlexColumnWidth(1),
            },
            children: [
              const TableRow(
                children: [
                  _BmiCell('Category', header: true),
                  _BmiCell('BMI (kg/m²)', header: true),
                ],
              ),
              ...rows.map(
                (row) =>
                    TableRow(children: [_BmiCell(row.$1), _BmiCell(row.$2)]),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Original table using public-health threshold facts; BMI is a screening measure, not a diagnosis.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}

class _BmiCell extends StatelessWidget {
  const _BmiCell(this.text, {this.header = false});
  final String text;
  final bool header;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 11,
        fontWeight: header ? FontWeight.w800 : FontWeight.w600,
      ),
    ),
  );
}

class _Time12Formatter extends TextInputFormatter {
  const _Time12Formatter();

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    var digits = newValue.text.replaceAll(RegExp(r'\D'), '');
    if (newValue.text.length < oldValue.text.length &&
        oldValue.text.endsWith(':') &&
        digits.length == 2) {
      digits = digits.substring(0, 1);
    }
    if (digits.length > 4) digits = digits.substring(0, 4);
    final text = digits.length <= 2
        ? '$digits${digits.length == 2 ? ':' : ''}'
        : '${digits.substring(0, 2)}:${digits.substring(2)}';
    return TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }
}

String _groupSignedNumber(String input) {
  var raw = input.replaceAll(',', '').replaceAll('−', '-');
  if (raw.isEmpty || raw == '-') return raw;
  final negative = raw.startsWith('-');
  if (negative) raw = raw.substring(1);
  final parts = raw.split('.');
  final integer = parts.first.isEmpty ? '0' : parts.first;
  final buffer = StringBuffer();
  for (var index = 0; index < integer.length; index += 1) {
    if (index > 0 && (integer.length - index) % 3 == 0) buffer.write(',');
    buffer.write(integer[index]);
  }
  final decimal = parts.length > 1 ? '.${parts.sublist(1).join()}' : '';
  return '${negative ? '-' : ''}${buffer.toString()}$decimal';
}

Future<void> _showSignedNumberPad(
  BuildContext context,
  TextEditingController controller, {
  bool allowList = false,
}) async {
  await showModalBottomSheet<void>(
    context: context,
    useSafeArea: true,
    isScrollControlled: true,
    builder: (sheetContext) => StatefulBuilder(
      builder: (context, setSheetState) {
        void press(String key) {
          if (key == 'done') {
            Navigator.pop(sheetContext);
            return;
          }
          var raw = allowList
              ? controller.text
              : controller.text.replaceAll(',', '').replaceAll('−', '-');
          if (key == 'backspace') {
            if (raw.isNotEmpty) raw = raw.substring(0, raw.length - 1);
          } else if (key == '-') {
            if (allowList) {
              final separator = raw.lastIndexOf(RegExp(r'[,\s]'));
              final start = separator + 1;
              raw =
                  raw.substring(0, start) +
                  (raw.substring(start).startsWith('-') ? '' : '-') +
                  raw.substring(start).replaceFirst('-', '');
            } else {
              raw = raw.startsWith('-') ? raw.substring(1) : '-$raw';
            }
          } else if (key == ',') {
            if (allowList &&
                raw.trim().isNotEmpty &&
                !raw.trimRight().endsWith(',')) {
              raw = '${raw.trimRight()}, ';
            }
          } else if (key == '.') {
            final current = allowList
                ? raw.substring(raw.lastIndexOf(RegExp(r'[,\s]')) + 1)
                : raw;
            if (!current.contains('.')) raw += '.';
          } else if (raw.length < 80) {
            raw += key;
          }
          final text = allowList ? raw : _groupSignedNumber(raw);
          controller.value = TextEditingValue(
            text: text,
            selection: TextSelection.collapsed(offset: text.length),
          );
          setSheetState(() {});
        }

        final keys = <String>[
          '7',
          '8',
          '9',
          'backspace',
          '4',
          '5',
          '6',
          '-',
          '1',
          '2',
          '3',
          if (allowList) ',' else 'blank',
          '0',
          '00',
          '000',
          '.',
        ];
        return Padding(
          padding: EdgeInsets.fromLTRB(
            16,
            12,
            16,
            16 + MediaQuery.viewInsetsOf(context).bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Signed numeric keypad',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  TextButton(
                    onPressed: () => controller.clear(),
                    child: const Text('Clear'),
                  ),
                ],
              ),
              Container(
                constraints: const BoxConstraints(minHeight: 48),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  controller.text.isEmpty ? '0' : controller.text,
                  textAlign: TextAlign.right,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 4,
                childAspectRatio: 1.75,
                crossAxisSpacing: 7,
                mainAxisSpacing: 7,
                children: keys.map((key) {
                  final blank = key == 'blank';
                  return FilledButton.tonal(
                    onPressed: blank ? null : () => press(key),
                    child: key == 'backspace'
                        ? const Icon(Icons.backspace_rounded)
                        : blank
                        ? const SizedBox.shrink()
                        : Text(
                            key == '-' ? '−' : key,
                            style: const TextStyle(fontSize: 18),
                          ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 7),
              FilledButton(
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                  backgroundColor: AppTheme.orange,
                  foregroundColor: Colors.white,
                ),
                onPressed: () => press('done'),
                child: const Text('Done'),
              ),
            ],
          ),
        );
      },
    ),
  );
}
