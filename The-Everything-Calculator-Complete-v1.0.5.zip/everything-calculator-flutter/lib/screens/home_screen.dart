import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_math_fork/flutter_math.dart';

import '../core/expression_engine.dart';
import '../core/history_controller.dart';
import '../core/number_format.dart';
import '../core/settings_controller.dart';
import '../data/tool_catalog.dart';
import '../models/tool_models.dart';
import '../theme/app_theme.dart';
import '../widgets/everything_logo.dart';
import '../widgets/history_sheet.dart';
import '../widgets/settings_sheet.dart';
import '../widgets/tool_drawer.dart';
import 'tool_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.settings, required this.history});

  final SettingsController settings;
  final HistoryController history;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final expression = TextEditingController();
  final expressionFocus = FocusNode();
  ExpressionResult? calculation;
  String? error;
  double ans = 0;
  double lastValidValue = 0;
  double memory = 0;
  bool scientific = false;
  bool second = false;

  static const basicKeys = [
    ('AC', 'clear', _KeyKind.utility),
    ('( )', 'parenthesis', _KeyKind.utility),
    ('÷', '/', _KeyKind.operator),
    ('⌫', 'backspace', _KeyKind.utility),
    ('7', '7', _KeyKind.number),
    ('8', '8', _KeyKind.number),
    ('9', '9', _KeyKind.number),
    ('+', '+', _KeyKind.operator),
    ('4', '4', _KeyKind.number),
    ('5', '5', _KeyKind.number),
    ('6', '6', _KeyKind.number),
    ('−', '-', _KeyKind.operator),
    ('1', '1', _KeyKind.number),
    ('2', '2', _KeyKind.number),
    ('3', '3', _KeyKind.number),
    ('×', '*', _KeyKind.operator),
    ('%', '%', _KeyKind.utility),
    ('0', '0', _KeyKind.number),
    ('.', '.', _KeyKind.number),
    ('=', 'equals', _KeyKind.equals),
  ];

  List<(String, String)> get scienceKeys => [
    ('(', '('),
    (')', ')'),
    ('mc', 'memory-clear'),
    ('m+', 'memory-add'),
    ('m−', 'memory-subtract'),
    ('mr', 'memory-recall'),
    (second ? '1st' : '2nd', 'second'),
    ('x²', '^2'),
    ('x³', '^3'),
    ('xʸ', '^'),
    ('eˣ', 'exp('),
    ('10ˣ', '10^('),
    ('1/x', '1/('),
    ('²√x', 'sqrt('),
    ('³√x', 'cbrt('),
    ('ʸ√x', '^(1/'),
    ('ln', 'ln('),
    ('log₁₀', 'log('),
    ('x!', '!'),
    (second ? 'sin⁻¹' : 'sin', second ? 'asin(' : 'sin('),
    (second ? 'cos⁻¹' : 'cos', second ? 'acos(' : 'cos('),
    (second ? 'tan⁻¹' : 'tan', second ? 'atan(' : 'tan('),
    ('e', 'e'),
    ('EE', 'e'),
    ('Rand', 'random'),
    (second ? 'asinh' : 'sinh', second ? 'asinh(' : 'sinh('),
    (second ? 'acosh' : 'cosh', second ? 'acosh(' : 'cosh('),
    (second ? 'atanh' : 'tanh', second ? 'atanh(' : 'tanh('),
    ('π', 'pi'),
    (widget.settings.angleUnit == AngleUnit.degrees ? 'DEG' : 'RAD', 'angle'),
  ];

  @override
  void initState() {
    super.initState();
    expression.addListener(_update);
    widget.settings.addListener(_update);
    _update();
  }

  @override
  void dispose() {
    widget.settings.removeListener(_update);
    expression
      ..removeListener(_update)
      ..dispose();
    expressionFocus.dispose();
    super.dispose();
  }

  void _update() {
    if (!mounted) return;
    try {
      final result = calculateExpression(
        expression.text,
        context: ExpressionContext(angle: widget.settings.angleUnit, ans: ans),
      );
      setState(() {
        calculation = result;
        if (expression.text.trim().isNotEmpty) lastValidValue = result.value;
        error = null;
      });
    } on ExpressionException catch (exception) {
      setState(() {
        calculation = null;
        error = _incomplete(exception) ? null : exception.message;
      });
    }
  }

  bool _incomplete(ExpressionException exception) {
    final normalized = normalizeExpression(expression.text);
    return normalized.isEmpty ||
        RegExp(r'[+\-*/^(,]$').hasMatch(normalized) ||
        exception.message.startsWith('Finish') ||
        exception.message.startsWith('Expected “)”');
  }

  void _press(String key) {
    if (widget.settings.haptics) HapticFeedback.selectionClick();
    if (key == 'clear') {
      expression.clear();
      expressionFocus.requestFocus();
      return;
    }
    if (key == 'equals') {
      _commit();
      return;
    }
    if (key == 'backspace') {
      _backspace();
      return;
    }
    if (key == 'parenthesis') {
      final cursor = expression.selection.isValid
          ? expression.selection.start
          : expression.text.length;
      final before = expression.text.substring(0, cursor);
      final opens = '('.allMatches(before).length;
      final closes = ')'.allMatches(before).length;
      _insert(opens > closes ? ')' : '(');
      return;
    }
    if (key == 'memory-clear') {
      setState(() => memory = 0);
      _notify('Memory cleared');
      return;
    }
    if (key == 'memory-add' || key == 'memory-subtract') {
      final value = calculation?.value ?? lastValidValue;
      setState(() => memory += key == 'memory-add' ? value : -value);
      _notify(
        key == 'memory-add' ? 'Added to memory' : 'Subtracted from memory',
      );
      return;
    }
    if (key == 'memory-recall') {
      _insert(_compactInput(memory));
      return;
    }
    if (key == 'random') {
      _insert(_compactInput(math.Random().nextDouble()));
      return;
    }
    if (key == 'second') {
      setState(() => second = !second);
      return;
    }
    if (key == 'angle') {
      widget.settings.setAngle(
        widget.settings.angleUnit == AngleUnit.degrees
            ? AngleUnit.radians
            : AngleUnit.degrees,
      );
      _notify(
        'Angle mode: ${widget.settings.angleUnit == AngleUnit.degrees ? 'RAD' : 'DEG'}',
      );
      return;
    }
    _insert(key);
  }

  String _compactInput(double value) => value
      .toStringAsPrecision(15)
      .replaceFirst(RegExp(r'\.0+$'), '')
      .replaceFirst(RegExp(r'(\.\d*?[1-9])0+$'), r'$1');

  void _notify(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _insert(String text) {
    final selection = expression.selection;
    final start = selection.isValid ? selection.start : expression.text.length;
    final end = selection.isValid ? selection.end : expression.text.length;
    expression.value = TextEditingValue(
      text: expression.text.replaceRange(start, end, text),
      selection: TextSelection.collapsed(offset: start + text.length),
    );
    expressionFocus.requestFocus();
  }

  void _backspace() {
    final selection = expression.selection;
    final start = selection.isValid ? selection.start : expression.text.length;
    final end = selection.isValid ? selection.end : expression.text.length;
    if (start != end) {
      expression.value = TextEditingValue(
        text: expression.text.replaceRange(start, end, ''),
        selection: TextSelection.collapsed(offset: start),
      );
    } else if (start > 0) {
      final before = expression.text.substring(0, start);
      final function = RegExp(
        r'(?:sqrt|cbrt|sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|asinh|acosh|atanh|log|ln|exp|abs)\($',
      ).firstMatch(before);
      final count = function?.group(0)?.length ?? 1;
      expression.value = TextEditingValue(
        text: expression.text.replaceRange(start - count, start, ''),
        selection: TextSelection.collapsed(offset: start - count),
      );
    }
    expressionFocus.requestFocus();
  }

  Future<void> _commit() async {
    final current = calculation;
    if (current == null || expression.text.trim().isEmpty) return;
    ans = current.value;
    await widget.history.add(expression.text.trim(), current.value);
    if (mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Added to history')));
  }

  void _openTool(
    EverythingTool tool, {
    Map<String, String> initialValues = const {},
  }) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ToolScreen(
          tool: tool,
          settings: widget.settings,
          history: widget.history,
          initialValues: initialValues,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Shortcuts(
      shortcuts: const {
        SingleActivator(LogicalKeyboardKey.escape): _ClearIntent(),
      },
      child: Actions(
        actions: {
          _ClearIntent: CallbackAction<_ClearIntent>(
            onInvoke: (_) {
              expression.clear();
              return null;
            },
          ),
        },
        child: Scaffold(
          appBar: AppBar(
            toolbarHeight: 58,
            titleSpacing: 12,
            title: Row(
              children: [
                EverythingLogo(
                  showWordmark: MediaQuery.sizeOf(context).width >= 640,
                  size: 45,
                ),
                const SizedBox(width: 10),
                const Text(
                  'v1.0.5',
                  style: TextStyle(
                    color: AppTheme.orangeDark,
                    fontSize: 8.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Align(
                    alignment: Alignment.centerRight,
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 138),
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(
                          minimumSize: const Size.fromHeight(42),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        onPressed: _showToolbox,
                        icon: const Icon(Icons.business_center_rounded),
                        label: const Text('Toolbox'),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            actions: [
              PopupMenuButton<_MenuAction>(
                tooltip: 'Menu',
                icon: const Icon(Icons.menu_rounded),
                position: PopupMenuPosition.under,
                onSelected: (action) => switch (action) {
                  _MenuAction.settings => _showSettings(),
                  _MenuAction.history => _showHistory(),
                  _MenuAction.about => _showAbout(),
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: _MenuAction.settings,
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.settings_rounded),
                      title: Text('Settings'),
                      subtitle: Text('Theme, precision & app details'),
                    ),
                  ),
                  PopupMenuItem(
                    value: _MenuAction.history,
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.history_rounded),
                      title: Text('History'),
                      subtitle: Text('Recent calculations'),
                    ),
                  ),
                  PopupMenuItem(
                    value: _MenuAction.about,
                    child: ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Icon(Icons.info_outline_rounded),
                      title: Text('About'),
                      subtitle: Text('What this app can do'),
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 6),
            ],
          ),
          body: SafeArea(
            top: false,
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(12, 14, 12, 48),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 900),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const _Intro(),
                      const SizedBox(height: 16),
                      _CalculatorCard(
                        expression: expression,
                        calculation: calculation,
                        lastValidValue: lastValidValue,
                        error: error,
                        scientific: scientific,
                        settings: widget.settings,
                        scienceKeys: scienceKeys,
                        basicKeys: basicKeys,
                        onKey: _press,
                        onModeChanged: (value) =>
                            setState(() => scientific = value),
                      ),
                      const SizedBox(height: 44),
                      _FavoriteFolders(
                        settings: widget.settings,
                        onOpen: _openTool,
                        onAddTool: (folderId) => _showToolbox(targetFolderId: folderId),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showToolbox({String? targetFolderId}) => showGeneralDialog<void>(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Close toolbox',
    barrierColor: Colors.black45,
    transitionDuration: const Duration(milliseconds: 260),
    pageBuilder: (dialogContext, _, _) => SafeArea(
      child: Align(
        alignment: Alignment.topCenter,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
          child: ToolDrawer(
            selectionPrompt: targetFolderId == null
                ? null
                : 'Add a tool to ${widget.settings.folderById(targetFolderId)?.name ?? 'folder'}',
            onToolSelected: (tool) async {
              Navigator.pop(dialogContext);
              if (targetFolderId != null) {
                final added = await widget.settings.addToolToFolder(targetFolderId, tool.id);
                _notify(added ? '${tool.shortTitle} added to folder' : '${tool.shortTitle} is already in that folder');
              } else {
                _openTool(tool);
              }
            },
          ),
        ),
      ),
    ),
    transitionBuilder: (_, animation, _, child) => FadeTransition(
      opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
      child: SlideTransition(
        position: Tween<Offset>(begin: const Offset(0, -.08), end: Offset.zero)
            .animate(
              CurvedAnimation(parent: animation, curve: Curves.easeOutCubic),
            ),
        child: child,
      ),
    ),
  );

  Future<void> _showSettings() => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => SettingsSheet(settings: widget.settings),
  );

  Future<void> _showHistory() => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    builder: (_) => FractionallySizedBox(
      heightFactor: .82,
      child: HistorySheet(
        history: widget.history,
        settings: widget.settings,
        onSelect: (entry) {
          if (entry.isTool) {
            final tool = toolById[entry.toolId];
            if (tool != null) _openTool(tool, initialValues: entry.values);
            return;
          }
          expression.text = entry.expression;
          expression.selection = TextSelection.collapsed(
            offset: expression.text.length,
          );
          expressionFocus.requestFocus();
        },
      ),
    ),
  );

  Future<void> _showAbout() => showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      icon: const EverythingLogo(showWordmark: false, size: 52),
      title: const Text('Calculate without limits.'),
      content: Text(
        'Version 1.0.5\n\nThe Everything Calculator combines a live scientific expression engine with ${allTools.length} focused converters and calculators. Your settings, favorite folders, and calculation history stay on this device.',
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Got it'),
        ),
      ],
    ),
  );
}

class _ModeSwitcher extends StatelessWidget {
  const _ModeSwitcher({required this.scientific, required this.onChanged});
  final bool scientific;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) => Align(
    alignment: Alignment.center,
    child: SizedBox(
      width: 270,
      child: SegmentedButton<bool>(
        segments: const [
          ButtonSegment(value: false, label: Text('Basic')),
          ButtonSegment(value: true, label: Text('Scientific')),
        ],
        selected: {scientific},
        showSelectedIcon: false,
        onSelectionChanged: (selection) => onChanged(selection.first),
      ),
    ),
  );
}

class _Intro extends StatelessWidget {
  const _Intro();

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Text(
        'The Everything Calculator',
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.headlineLarge?.copyWith(
          fontWeight: FontWeight.w800,
          letterSpacing: -1.1,
          height: 1.03,
        ),
      ),
      const SizedBox(height: 5),
      Text(
        'Calculate without limits.',
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    ],
  );
}

class _CalculatorCard extends StatelessWidget {
  const _CalculatorCard({
    required this.expression,
    required this.calculation,
    required this.lastValidValue,
    required this.error,
    required this.scientific,
    required this.settings,
    required this.scienceKeys,
    required this.basicKeys,
    required this.onKey,
    required this.onModeChanged,
  });
  final TextEditingController expression;
  final ExpressionResult? calculation;
  final double lastValidValue;
  final String? error;
  final bool scientific;
  final SettingsController settings;
  final List<(String, String)> scienceKeys;
  final List<(String, String, _KeyKind)> basicKeys;
  final ValueChanged<String> onKey;
  final ValueChanged<bool> onModeChanged;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: Container(
        decoration: BoxDecoration(
          color: scheme.surface,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: scheme.outlineVariant),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .07),
              blurRadius: 28,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 9, 16, 8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    scheme.surface,
                    AppTheme.orange.withValues(alpha: .07),
                  ],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Text(
                        'LIVE FORMULA',
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.4,
                        ),
                      ),
                      const Spacer(),
                      TextButton.icon(
                        onPressed: calculation == null
                            ? null
                            : () async {
                                await Clipboard.setData(
                                  ClipboardData(
                                    text: formatNumber(
                                      calculation!.value,
                                      precision: settings.precision,
                                      separators: settings.separators,
                                    ),
                                  ),
                                );
                                if (context.mounted)
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Result copied'),
                                    ),
                                  );
                              },
                        icon: const Icon(Icons.copy_rounded, size: 16),
                        label: const Text('Copy'),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 44,
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        reverse: true,
                        child: calculation != null
                            ? Math.tex(
                                calculation!.latex,
                                mathStyle: MathStyle.display,
                                textStyle: TextStyle(
                                  fontSize: 25,
                                  color: scheme.onSurface,
                                ),
                              )
                            : Text(
                                expression.text.isEmpty ? '0' : expression.text,
                                style: const TextStyle(
                                  fontFamily: 'monospace',
                                fontSize: 20,
                                ),
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      const Text(
                        '=',
                        style: TextStyle(
                          color: AppTheme.orange,
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Flexible(
                        child: Text(
                          calculation == null
                              ? formatNumber(
                                  lastValidValue,
                                  precision: settings.precision,
                                  separators: settings.separators,
                                )
                              : formatNumber(
                                  calculation!.value,
                                  precision: settings.precision,
                                  separators: settings.separators,
                                ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.displayMedium
                              ?.copyWith(
                                fontWeight: FontWeight.w700,
                                fontSize: 34,
                                letterSpacing: -1.4,
                              ),
                        ),
                      ),
                    ],
                  ),
                  if (error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Text(
                        error!,
                        textAlign: TextAlign.right,
                        style: TextStyle(color: scheme.error, fontSize: 12),
                      ),
                    ),
                ],
              ),
            ),
            if (scientific)
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 6,
                  childAspectRatio: MediaQuery.sizeOf(context).width < 480
                      ? 1.34
                      : 1.72,
                  crossAxisSpacing: 5,
                  mainAxisSpacing: 5,
                  children: scienceKeys
                      .map(
                        (key) => _CalculatorKey(
                          label: key.$1,
                          kind: _KeyKind.function,
                          onTap: () => onKey(key.$2),
                        ),
                      )
                      .toList(),
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 4,
                childAspectRatio: MediaQuery.sizeOf(context).width < 480
                    ? 1.78
                    : 2.1,
                crossAxisSpacing: 6,
                mainAxisSpacing: 6,
                children: basicKeys
                    .map(
                      (key) => _CalculatorKey(
                        label: key.$1,
                        kind: key.$3,
                        onTap: () => onKey(key.$2),
                      ),
                    )
                    .toList(),
              ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: scheme.surfaceContainerLow,
                border: Border(top: BorderSide(color: scheme.outlineVariant)),
              ),
              child: _ModeSwitcher(
                scientific: scientific,
                onChanged: onModeChanged,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

enum _KeyKind { number, utility, operator, equals, function }

class _CalculatorKey extends StatelessWidget {
  const _CalculatorKey({
    required this.label,
    required this.kind,
    required this.onTap,
  });
  final String label;
  final _KeyKind kind;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final equals = kind == _KeyKind.equals;
    final operator = kind == _KeyKind.operator;
    return Material(
      color: equals
          ? AppTheme.orange
          : operator
          ? AppTheme.orange.withValues(alpha: .08)
          : scheme.surfaceContainer,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(13),
        side: BorderSide(
          color: equals
              ? Colors.transparent
              : operator
              ? AppTheme.orange.withValues(alpha: .4)
              : scheme.outlineVariant,
        ),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: equals
                  ? Colors.white
                  : operator
                  ? AppTheme.orangeDark
                  : scheme.onSurface,
              fontWeight: FontWeight.w700,
              fontSize: kind == _KeyKind.function ? 12 : 16,
            ),
          ),
        ),
      ),
    );
  }
}

class _FavoriteFolders extends StatefulWidget {
  const _FavoriteFolders({
    required this.settings,
    required this.onOpen,
    required this.onAddTool,
  });
  final SettingsController settings;
  final ValueChanged<EverythingTool> onOpen;
  final ValueChanged<String> onAddTool;

  @override
  State<_FavoriteFolders> createState() => _FavoriteFoldersState();
}

class _FavoriteFoldersState extends State<_FavoriteFolders> {
  final search = TextEditingController();
  String? currentFolderId;

  @override
  void initState() {
    super.initState();
    widget.settings.addListener(_settingsChanged);
  }

  @override
  void didUpdateWidget(covariant _FavoriteFolders oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.settings != widget.settings) {
      oldWidget.settings.removeListener(_settingsChanged);
      widget.settings.addListener(_settingsChanged);
    }
  }

  @override
  void dispose() {
    widget.settings.removeListener(_settingsChanged);
    search.dispose();
    super.dispose();
  }

  void _settingsChanged() {
    if (!mounted) return;
    if (currentFolderId != null && widget.settings.folderById(currentFolderId) == null) {
      currentFolderId = null;
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final current = widget.settings.folderById(currentFolderId);
    final query = search.text.trim().toLowerCase();
    final folders = widget.settings
        .folderChildren(current?.id)
        .where((folder) => folder.name.toLowerCase().contains(query))
        .toList();
    final tools = (current?.toolIds ?? const <String>[])
        .map((id) => toolById[id])
        .whereType<EverythingTool>()
        .where(
          (tool) => query.isEmpty ||
              '${tool.title} ${tool.description} ${sectionByToolId[tool.id]?.title ?? ''}'
                  .toLowerCase()
                  .contains(query),
        )
        .toList();
    final columns = MediaQuery.sizeOf(context).width >= 760 ? 4 : 2;
    final cards = <Widget>[
      ...folders.map(
        (folder) => _FolderCard(
          folder: folder,
          itemCount: folder.toolIds.length + widget.settings.folderChildren(folder.id).length,
          onOpen: () {
            setState(() {
              currentFolderId = folder.id;
              search.clear();
            });
          },
          onRename: () => _renameFolder(folder),
          onMove: () => _moveFolder(folder),
          onDelete: () => _deleteFolder(folder),
        ),
      ),
      ...tools.map(
        (tool) => _FavoriteToolCard(
          tool: tool,
          onTap: () => widget.onOpen(tool),
          onRemove: () => widget.settings.removeToolFromFolder(current!.id, tool.id),
        ),
      ),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'FAVORITE FOLDERS',
          style: TextStyle(
            color: AppTheme.orangeDark,
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.4,
          ),
        ),
        const SizedBox(height: 7),
        Text('Keep your tools organized your way.', style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12),
        Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            TextButton(
              onPressed: () => setState(() {
                currentFolderId = null;
                search.clear();
              }),
              child: const Text('Favorite folders'),
            ),
            for (final folder in widget.settings.folderPath(current?.id)) ...[
              const Text('/'),
              TextButton(
                onPressed: folder.id == current?.id
                    ? null
                    : () => setState(() {
                        currentFolderId = folder.id;
                        search.clear();
                      }),
                child: Text(folder.name),
              ),
            ],
          ],
        ),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            SizedBox(
              width: 280,
              child: TextField(
                controller: search,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search_rounded),
                  hintText: 'Search this folder',
                  isDense: true,
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            OutlinedButton.icon(
              onPressed: _createFolder,
              icon: const Icon(Icons.create_new_folder_rounded),
              label: const Text('New folder'),
            ),
            if (current != null)
              FilledButton.icon(
                onPressed: () => widget.onAddTool(current.id),
                icon: const Icon(Icons.add_rounded),
                label: const Text('Add tool'),
              ),
          ],
        ),
        const SizedBox(height: 14),
        if (cards.isEmpty)
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
            ),
            child: Text(
              query.isNotEmpty
                  ? 'No matching folders or tools here.'
                  : current == null
                  ? 'Create a folder to organize your favorite calculators.'
                  : 'This folder is empty. Add a tool or create a nested folder.',
              textAlign: TextAlign.center,
            ),
          )
        else
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: columns,
            childAspectRatio: columns == 4 ? 1.08 : .92,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            children: cards,
          ),
      ],
    );
  }

  Future<String?> _askForName(String title, String initial) async {
    final controller = TextEditingController(text: initial);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 48,
          decoration: const InputDecoration(labelText: 'Folder name'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    controller.dispose();
    return result?.trim();
  }

  Future<void> _createFolder() async {
    final name = await _askForName('Create folder', 'Folder ${widget.settings.folderChildren(currentFolderId).length + 1}');
    if (name == null || name.isEmpty) return;
    await widget.settings.createFolder(name, parentId: currentFolderId);
  }

  Future<void> _renameFolder(FavoriteFolder folder) async {
    final name = await _askForName('Rename folder', folder.name);
    if (name == null || name.isEmpty) return;
    await widget.settings.renameFolder(folder.id, name);
  }

  Future<void> _moveFolder(FavoriteFolder folder) async {
    final excluded = widget.settings.folderDescendants(folder.id)..add(folder.id);
    final destinations = widget.settings.favoriteFolders.where((item) => !excluded.contains(item.id)).toList();
    final selected = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: Text('Move “${folder.name}”'),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.pop(context, '__root__'),
            child: const ListTile(leading: Icon(Icons.home_filled), title: Text('Favorite folders (top level)')),
          ),
          ...destinations.map(
            (destination) => SimpleDialogOption(
              onPressed: () => Navigator.pop(context, destination.id),
              child: ListTile(
                leading: const Icon(Icons.folder_rounded),
                title: Text(widget.settings.folderPath(destination.id).map((item) => item.name).join(' / ')),
              ),
            ),
          ),
        ],
      ),
    );
    if (selected == null) return;
    await widget.settings.moveFolder(folder.id, selected == '__root__' ? null : selected);
  }

  Future<void> _deleteFolder(FavoriteFolder folder) async {
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Delete “${folder.name}”?'),
            content: const Text('Nested folders and saved tool shortcuts inside it will also be removed.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete')),
            ],
          ),
        ) ??
        false;
    if (confirmed) await widget.settings.deleteFolder(folder.id);
  }
}

enum _FolderAction { rename, move, delete }

class _FolderCard extends StatelessWidget {
  const _FolderCard({required this.folder, required this.itemCount, required this.onOpen, required this.onRename, required this.onMove, required this.onDelete});
  final FavoriteFolder folder;
  final int itemCount;
  final VoidCallback onOpen;
  final VoidCallback onRename;
  final VoidCallback onMove;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) => Card(
    clipBehavior: Clip.antiAlias,
    child: Stack(
      children: [
        Positioned.fill(
          child: InkWell(
            onTap: onOpen,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 58,
                  height: 58,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppTheme.orange.withValues(alpha: .08),
                    borderRadius: BorderRadius.circular(17),
                    border: Border.all(color: AppTheme.orange.withValues(alpha: .3)),
                  ),
                  child: const Icon(Icons.folder_rounded, color: AppTheme.orangeDark, size: 31),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text(folder.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
                const SizedBox(height: 3),
                Text('$itemCount item${itemCount == 1 ? '' : 's'}', style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ),
        Positioned(
          top: 2,
          right: 2,
          child: PopupMenuButton<_FolderAction>(
            tooltip: 'Folder options',
            onSelected: (action) {
              switch (action) {
                case _FolderAction.rename:
                  onRename();
                case _FolderAction.move:
                  onMove();
                case _FolderAction.delete:
                  onDelete();
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: _FolderAction.rename, child: Text('Rename')),
              PopupMenuItem(value: _FolderAction.move, child: Text('Move')),
              PopupMenuItem(value: _FolderAction.delete, child: Text('Delete')),
            ],
          ),
        ),
      ],
    ),
  );
}

class _FavoriteToolCard extends StatelessWidget {
  const _FavoriteToolCard({required this.tool, required this.onTap, required this.onRemove});
  final EverythingTool tool;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final icon = sectionByToolId[tool.id]?.id == 'science' ? Icons.rocket_launch_rounded : tool.icon;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Stack(
        children: [
          Positioned.fill(
            child: InkWell(
              onTap: onTap,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 58,
                    height: 58,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppTheme.orange.withValues(alpha: .07),
                      borderRadius: BorderRadius.circular(17),
                      border: Border.all(color: AppTheme.orange.withValues(alpha: .3)),
                    ),
                    child: Icon(icon, color: AppTheme.orangeDark, size: 29),
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text(tool.shortTitle, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          ),
          Positioned(top: 0, right: 0, child: IconButton(tooltip: 'Remove from folder', onPressed: onRemove, icon: const Icon(Icons.close_rounded, size: 18))),
        ],
      ),
    );
  }
}

enum _MenuAction { settings, history, about }

class _ClearIntent extends Intent {
  const _ClearIntent();
}
