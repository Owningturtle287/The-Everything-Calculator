import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/history_controller.dart';
import 'core/settings_controller.dart';
import 'screens/home_screen.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = SettingsController();
  final history = HistoryController();
  await Future.wait([settings.load(), history.load()]);
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(EverythingCalculatorApp(settings: settings, history: history));
}

class EverythingCalculatorApp extends StatelessWidget {
  const EverythingCalculatorApp({
    super.key,
    required this.settings,
    required this.history,
  });

  final SettingsController settings;
  final HistoryController history;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) => MaterialApp(
        title: 'The Everything Calculator',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: settings.themeMode,
        home: HomeScreen(settings: settings, history: history),
      ),
    );
  }
}
