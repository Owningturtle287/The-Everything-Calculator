import 'dart:convert';
import 'dart:io';

class CurrencyQuote {
  const CurrencyQuote({
    required this.from,
    required this.to,
    required this.rate,
    required this.date,
    this.cached = false,
  });

  final String from;
  final String to;
  final double rate;
  final String date;
  final bool cached;

  CurrencyQuote asCached() =>
      CurrencyQuote(from: from, to: to, rate: rate, date: date, cached: true);
}

class CurrencyService {
  CurrencyService._();

  static final _lastKnown = <String, CurrencyQuote>{};

  static Future<CurrencyQuote> latest(String from, String to) async {
    final base = from.toUpperCase();
    final target = to.toUpperCase();
    final key = '$base-$target';
    if (base == target) {
      return CurrencyQuote(
        from: base,
        to: target,
        rate: 1,
        date: DateTime.now().toIso8601String().substring(0, 10),
      );
    }

    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 10);
    try {
      Object? lastError;
      final endpoints = <Uri>[
        Uri.https('api.frankfurter.dev', '/v2/rate/$base/$target'),
        Uri.https('api.frankfurter.dev', '/v1/latest', {
          'from': base,
          'to': target,
        }),
      ];
      for (final uri in endpoints) {
        try {
          final quote = await _requestQuote(client, uri, base, target);
          _lastKnown[key] = quote;
          return quote;
        } catch (error) {
          lastError = error;
        }
      }
      throw lastError ??
          const HttpException('Exchange-rate service unavailable.');
    } catch (_) {
      final fallback = _lastKnown[key];
      if (fallback != null) return fallback.asCached();
      rethrow;
    } finally {
      client.close(force: true);
    }
  }

  static Future<CurrencyQuote> _requestQuote(
    HttpClient client,
    Uri uri,
    String base,
    String target,
  ) async {
    final request = await client.getUrl(uri);
    request.headers.set(HttpHeaders.cacheControlHeader, 'no-cache');
    request.headers.set(HttpHeaders.acceptHeader, 'application/json');
    final response = await request.close().timeout(const Duration(seconds: 12));
    final body = await utf8.decoder.bind(response).join();
    if (response.statusCode != HttpStatus.ok) {
      throw HttpException(
        'Exchange-rate service returned ${response.statusCode}.',
        uri: uri,
      );
    }
    final decoded = jsonDecode(body);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('The exchange-rate response was invalid.');
    }
    final nestedRates = decoded['rates'];
    final rawRate =
        decoded['rate'] ??
        (nestedRates is Map<String, dynamic> ? nestedRates[target] : null);
    final rate = rawRate is num
        ? rawRate.toDouble()
        : double.tryParse('$rawRate');
    if (rate == null || !rate.isFinite || rate <= 0) {
      throw const FormatException('The exchange-rate response was incomplete.');
    }
    return CurrencyQuote(
      from: base,
      to: target,
      rate: rate,
      date: decoded['date']?.toString() ?? 'latest available',
    );
  }
}
