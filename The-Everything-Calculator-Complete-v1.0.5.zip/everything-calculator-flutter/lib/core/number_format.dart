String formatNumber(num value, {int precision = 8, bool separators = true}) {
  var number = value.toDouble();
  if (number.isNaN) return 'Not a number';
  if (number == double.infinity) return '∞';
  if (number == double.negativeInfinity) return '−∞';
  if (number == -0.0) number = 0;
  final absolute = number.abs();
  if (absolute != 0 &&
      (absolute >= 1e12 || absolute < _pow10(-precision.clamp(1, 6)))) {
    return number
        .toStringAsExponential(precision.clamp(1, 15))
        .replaceFirst(RegExp(r'\.0+e'), 'e')
        .replaceFirst(RegExp(r'(\.\d*?[1-9])0+e'), r'$1e')
        .replaceFirst('e+', 'e');
  }
  var raw = number
      .toStringAsFixed(precision.clamp(1, 15))
      .replaceFirst(RegExp(r'\.?0+$'), '');
  if (!separators) return raw;
  final negative = raw.startsWith('-');
  if (negative) raw = raw.substring(1);
  final parts = raw.split('.');
  final integer = parts.first;
  final buffer = StringBuffer();
  for (var index = 0; index < integer.length; index += 1) {
    if (index > 0 && (integer.length - index) % 3 == 0) buffer.write(',');
    buffer.write(integer[index]);
  }
  final formatted = parts.length == 2
      ? '${buffer.toString()}.${parts[1]}'
      : buffer.toString();
  return negative ? '−$formatted' : formatted;
}

String formatMoney(num value, {bool separators = true}) {
  var raw = value.toDouble().toStringAsFixed(2);
  final negative = raw.startsWith('-');
  if (negative) raw = raw.substring(1);
  if (!separators) return negative ? '−\$$raw' : '\$$raw';
  final parts = raw.split('.');
  final integer = parts.first;
  final buffer = StringBuffer();
  for (var index = 0; index < integer.length; index += 1) {
    if (index > 0 && (integer.length - index) % 3 == 0) buffer.write(',');
    buffer.write(integer[index]);
  }
  final formatted = '${buffer.toString()}.${parts[1]}';
  return negative ? '−\$$formatted' : '\$$formatted';
}

double _pow10(int exponent) {
  var result = 1.0;
  if (exponent >= 0) {
    for (var index = 0; index < exponent; index += 1) result *= 10;
  } else {
    for (var index = 0; index > exponent; index -= 1) result /= 10;
  }
  return result;
}
