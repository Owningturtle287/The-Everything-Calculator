import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'expression_engine.dart';

class FavoriteFolder {
  FavoriteFolder({
    required this.id,
    required this.name,
    required this.parentId,
    List<String>? toolIds,
  }) : toolIds = toolIds ?? <String>[];

  final String id;
  String name;
  String? parentId;
  List<String> toolIds;

  factory FavoriteFolder.fromJson(Map<String, Object?> json) => FavoriteFolder(
    id: (json['id'] ?? '').toString(),
    name: (json['name'] ?? '').toString(),
    parentId: json['parentId']?.toString(),
    toolIds: (json['toolIds'] as List<Object?>? ?? const <Object?>[])
        .map((value) => value.toString())
        .where((value) => value.isNotEmpty)
        .toSet()
        .toList(),
  );

  Map<String, Object?> toJson() => {
    'id': id,
    'name': name,
    'parentId': parentId,
    'toolIds': toolIds,
  };
}

List<FavoriteFolder> _starterFolders([List<String> imported = const []]) {
  final folders = List<FavoriteFolder>.generate(
    4,
    (index) => FavoriteFolder(
      id: 'starter-folder-${index + 1}',
      name: 'Folder ${index + 1}',
      parentId: null,
    ),
  );
  if (imported.isNotEmpty) {
    folders.first
      ..name = 'Saved tools'
      ..toolIds = imported.toSet().toList();
  }
  return folders;
}

class SettingsController extends ChangeNotifier {
  SettingsController() : _preferences = SharedPreferencesAsync();

  final SharedPreferencesAsync _preferences;
  static const _folderKey = 'favoriteFoldersV2';
  static int _folderSequence = 0;

  ThemeMode themeMode = ThemeMode.system;
  AngleUnit angleUnit = AngleUnit.degrees;
  int precision = 8;
  bool separators = true;
  bool haptics = true;
  List<FavoriteFolder> favoriteFolders = _starterFolders();

  Future<void> load() async {
    final theme = await _preferences.getString('theme');
    themeMode = switch (theme) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    angleUnit = await _preferences.getString('angle') == 'rad'
        ? AngleUnit.radians
        : AngleUnit.degrees;
    final storedPrecision = await _preferences.getInt('precision');
    if (storedPrecision != null && storedPrecision >= 1 && storedPrecision <= 15) {
      precision = storedPrecision;
    }
    separators = await _preferences.getBool('separators') ?? true;
    haptics = await _preferences.getBool('haptics') ?? true;
    final encodedFolders = await _preferences.getString(_folderKey);
    var loadedFolders = <FavoriteFolder>[];
    if (encodedFolders != null) {
      try {
        final decoded = jsonDecode(encodedFolders) as Map<String, Object?>;
        loadedFolders = (decoded['folders'] as List<Object?>? ?? const [])
            .whereType<Map>()
            .map((item) => FavoriteFolder.fromJson(Map<String, Object?>.from(item)))
            .where((folder) => folder.id.isNotEmpty)
            .toList();
      } catch (_) {
        loadedFolders = <FavoriteFolder>[];
      }
    }
    if (loadedFolders.isEmpty) {
      final legacy = await _preferences.getStringList('favorites');
      loadedFolders = _starterFolders(
        (legacy ?? const <String>[]).where((id) => id.isNotEmpty).toList(),
      );
    }
    final ids = loadedFolders.map((folder) => folder.id).toSet();
    for (final folder in loadedFolders) {
      folder.name = folder.name.trim().isEmpty ? 'Folder' : folder.name.trim();
      if (!ids.contains(folder.parentId) || folder.parentId == folder.id) {
        folder.parentId = null;
      }
    }
    favoriteFolders = loadedFolders;
    notifyListeners();
  }

  FavoriteFolder? folderById(String? id) {
    if (id == null) return null;
    for (final folder in favoriteFolders) {
      if (folder.id == id) return folder;
    }
    return null;
  }

  List<FavoriteFolder> folderChildren(String? parentId) => favoriteFolders
      .where((folder) => folder.parentId == parentId)
      .toList(growable: false);

  List<FavoriteFolder> folderPath(String? id) {
    final result = <FavoriteFolder>[];
    final seen = <String>{};
    var current = folderById(id);
    while (current != null && seen.add(current.id)) {
      result.insert(0, current);
      current = folderById(current.parentId);
    }
    return result;
  }

  Set<String> folderDescendants(String id) {
    final result = <String>{};
    void visit(String parentId) {
      for (final folder in folderChildren(parentId)) {
        if (result.add(folder.id)) visit(folder.id);
      }
    }

    visit(id);
    return result;
  }

  Future<FavoriteFolder> createFolder(String name, {String? parentId}) async {
    final clean = name.trim().isEmpty ? 'Folder' : name.trim();
    final id = 'folder-${DateTime.now().microsecondsSinceEpoch}-${_folderSequence++}';
    final folder = FavoriteFolder(
      id: id,
      name: clean.length > 48 ? clean.substring(0, 48) : clean,
      parentId: folderById(parentId)?.id,
    );
    favoriteFolders.add(folder);
    notifyListeners();
    await _saveFolders();
    return folder;
  }

  Future<void> renameFolder(String id, String name) async {
    final folder = folderById(id);
    final clean = name.trim();
    if (folder == null || clean.isEmpty) return;
    folder.name = clean.length > 48 ? clean.substring(0, 48) : clean;
    notifyListeners();
    await _saveFolders();
  }

  Future<void> moveFolder(String id, String? parentId) async {
    final folder = folderById(id);
    if (folder == null) return;
    final excluded = folderDescendants(id)..add(id);
    if (parentId != null && (excluded.contains(parentId) || folderById(parentId) == null)) return;
    folder.parentId = parentId;
    notifyListeners();
    await _saveFolders();
  }

  Future<void> deleteFolder(String id) async {
    final removed = folderDescendants(id)..add(id);
    favoriteFolders = favoriteFolders.where((folder) => !removed.contains(folder.id)).toList();
    notifyListeners();
    await _saveFolders();
  }

  Future<bool> addToolToFolder(String folderId, String toolId) async {
    final folder = folderById(folderId);
    if (folder == null || toolId.isEmpty || folder.toolIds.contains(toolId)) return false;
    folder.toolIds.add(toolId);
    notifyListeners();
    await _saveFolders();
    return true;
  }

  Future<void> removeToolFromFolder(String folderId, String toolId) async {
    final folder = folderById(folderId);
    if (folder == null) return;
    folder.toolIds.remove(toolId);
    notifyListeners();
    await _saveFolders();
  }

  Future<void> setTheme(ThemeMode value) async {
    themeMode = value;
    notifyListeners();
    await _preferences.setString('theme', value.name);
  }

  Future<void> setAngle(AngleUnit value) async {
    angleUnit = value;
    notifyListeners();
    await _preferences.setString(
      'angle',
      value == AngleUnit.degrees ? 'deg' : 'rad',
    );
  }

  Future<void> setPrecision(int value) async {
    precision = value.clamp(1, 15).toInt();
    notifyListeners();
    await _preferences.setInt('precision', precision);
  }

  Future<void> setSeparators(bool value) async {
    separators = value;
    notifyListeners();
    await _preferences.setBool('separators', value);
  }

  Future<void> setHaptics(bool value) async {
    haptics = value;
    notifyListeners();
    await _preferences.setBool('haptics', value);
  }

  Future<void> reset() async {
    themeMode = ThemeMode.system;
    angleUnit = AngleUnit.degrees;
    precision = 8;
    separators = true;
    haptics = true;
    favoriteFolders = _starterFolders();
    notifyListeners();
    await Future.wait([
      _preferences.setString('theme', 'system'),
      _preferences.setString('angle', 'deg'),
      _preferences.setInt('precision', 8),
      _preferences.setBool('separators', true),
      _preferences.setBool('haptics', true),
      _saveFolders(),
      _preferences.remove('favorites'),
    ]);
  }

  Future<void> _saveFolders() => _preferences.setString(
    _folderKey,
    jsonEncode({
      'version': 2,
      'folders': favoriteFolders.map((folder) => folder.toJson()).toList(),
    }),
  );
}
