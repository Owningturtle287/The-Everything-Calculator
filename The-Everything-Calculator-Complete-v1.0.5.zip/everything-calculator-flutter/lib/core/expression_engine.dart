import 'dart:math' as math;

class ExpressionException implements Exception {
  const ExpressionException(this.message, [this.position]);

  final String message;
  final int? position;

  @override
  String toString() => message;
}

enum TokenType { number, identifier, operator, eof }

class Token {
  const Token(this.type, this.value, this.position);

  final TokenType type;
  final String value;
  final int position;
}

String normalizeExpression(String input) => input
    .replaceAll('×', '*')
    .replaceAll('÷', '/')
    .replaceAll('−', '-')
    .replaceAll('π', 'pi')
    .replaceAll('√', 'sqrt')
    .replaceAll(RegExp(r'\s+'), ' ')
    .trim();

class Tokenizer {
  Tokenizer(String input) : input = normalizeExpression(input) {
    next();
  }

  final String input;
  int index = 0;
  late Token current;

  void next() {
    while (index < input.length && RegExp(r'\s').hasMatch(input[index])) {
      index += 1;
    }
    if (index >= input.length) {
      current = Token(TokenType.eof, '', index);
      return;
    }

    final start = index;
    final remaining = input.substring(index);
    final character = input[index];
    if (RegExp(r'[0-9.]').hasMatch(character)) {
      final match = RegExp(
        r'^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?',
        caseSensitive: false,
      ).firstMatch(remaining);
      if (match == null) {
        throw ExpressionException('Invalid number.', start);
      }
      index += match.group(0)!.length;
      current = Token(TokenType.number, match.group(0)!, start);
      return;
    }

    if (RegExp(r'[a-z_]', caseSensitive: false).hasMatch(character)) {
      final match = RegExp(
        r'^[a-z_][a-z0-9_]*',
        caseSensitive: false,
      ).firstMatch(remaining)!;
      index += match.group(0)!.length;
      current = Token(
        TokenType.identifier,
        match.group(0)!.toLowerCase(),
        start,
      );
      return;
    }

    if ('+-*/^%!(),'.contains(character)) {
      index += 1;
      current = Token(TokenType.operator, character, start);
      return;
    }
    throw ExpressionException('Unexpected character “$character”.', start);
  }

  bool match(String value) {
    if (current.value != value) return false;
    next();
    return true;
  }

  void expect(String value) {
    if (!match(value)) {
      throw ExpressionException('Expected “$value”.', current.position);
    }
  }
}

sealed class ExprNode {
  const ExprNode();
}

class NumberNode extends ExprNode {
  const NumberNode(this.value, this.raw);
  final double value;
  final String raw;
}

class ConstantNode extends ExprNode {
  const ConstantNode(this.name);
  final String name;
}

class GroupNode extends ExprNode {
  const GroupNode(this.argument);
  final ExprNode argument;
}

class UnaryNode extends ExprNode {
  const UnaryNode(this.operator, this.argument);
  final String operator;
  final ExprNode argument;
}

class PostfixNode extends ExprNode {
  const PostfixNode(this.operator, this.argument);
  final String operator;
  final ExprNode argument;
}

class BinaryNode extends ExprNode {
  const BinaryNode(
    this.operator,
    this.left,
    this.right, {
    this.implicit = false,
  });

  final String operator;
  final ExprNode left;
  final ExprNode right;
  final bool implicit;
}

class FunctionNode extends ExprNode {
  const FunctionNode(this.name, this.argument);
  final String name;
  final ExprNode argument;
}

class ExpressionParser {
  ExpressionParser(String input) : tokens = Tokenizer(input);

  final Tokenizer tokens;

  static const functions = {
    'sin',
    'cos',
    'tan',
    'asin',
    'acos',
    'atan',
    'sqrt',
    'cbrt',
    'ln',
    'log',
    'exp',
    'abs',
    'floor',
    'ceil',
    'round',
    'sinh',
    'cosh',
    'tanh',
    'asinh',
    'acosh',
    'atanh',
  };

  static const constants = {'pi', 'e', 'ans'};

  ExprNode parse() {
    final node = parseExpression();
    if (tokens.current.type != TokenType.eof) {
      throw ExpressionException(
        'Unexpected “${tokens.current.value}”.',
        tokens.current.position,
      );
    }
    return node;
  }

  ExprNode parseExpression() {
    var node = parseTerm();
    while (tokens.current.value == '+' || tokens.current.value == '-') {
      final operator = tokens.current.value;
      tokens.next();
      node = BinaryNode(operator, node, parseTerm());
    }
    return node;
  }

  ExprNode parseTerm() {
    var node = parseUnary();
    while (true) {
      if (tokens.current.value == '*' || tokens.current.value == '/') {
        final operator = tokens.current.value;
        tokens.next();
        node = BinaryNode(operator, node, parseUnary());
      } else if (_isImplicitMultiplication()) {
        node = BinaryNode('*', node, parseUnary(), implicit: true);
      } else {
        break;
      }
    }
    return node;
  }

  bool _isImplicitMultiplication() {
    final token = tokens.current;
    return token.type == TokenType.number ||
        token.type == TokenType.identifier ||
        token.value == '(';
  }

  ExprNode parseUnary() {
    if (tokens.match('+')) return UnaryNode('+', parseUnary());
    if (tokens.match('-')) return UnaryNode('-', parseUnary());
    return parsePower();
  }

  ExprNode parsePower() {
    var node = parsePostfix();
    if (tokens.match('^')) {
      node = BinaryNode('^', node, parseUnary());
    }
    return node;
  }

  ExprNode parsePostfix() {
    var node = parsePrimary();
    while (tokens.current.value == '%' || tokens.current.value == '!') {
      final operator = tokens.current.value;
      tokens.next();
      node = PostfixNode(operator, node);
    }
    return node;
  }

  ExprNode parsePrimary() {
    final token = tokens.current;
    if (token.type == TokenType.number) {
      tokens.next();
      final value = double.tryParse(token.value);
      if (value == null) {
        throw ExpressionException('Invalid number.', token.position);
      }
      return NumberNode(value, token.value);
    }

    if (token.type == TokenType.identifier) {
      tokens.next();
      if (constants.contains(token.value)) return ConstantNode(token.value);
      if (!functions.contains(token.value)) {
        throw ExpressionException(
          'Unknown function or constant “${token.value}”.',
          token.position,
        );
      }
      tokens.expect('(');
      final argument = parseExpression();
      tokens.expect(')');
      return FunctionNode(token.value, argument);
    }

    if (tokens.match('(')) {
      final node = parseExpression();
      tokens.expect(')');
      return GroupNode(node);
    }
    if (token.type == TokenType.eof) {
      throw ExpressionException(
        'Finish the expression to see a result.',
        token.position,
      );
    }
    throw ExpressionException('Expected a number or function.', token.position);
  }
}

class ExpressionContext {
  const ExpressionContext({this.angle = AngleUnit.degrees, this.ans = 0});
  final AngleUnit angle;
  final double ans;
}

enum AngleUnit { degrees, radians }

double factorial(double value) {
  if (value < 0 || value != value.roundToDouble()) {
    throw const ExpressionException(
      'Factorial is defined for non-negative whole numbers.',
    );
  }
  if (value > 170) {
    throw const ExpressionException('That factorial is too large to display.');
  }
  var result = 1.0;
  for (var index = 2; index <= value; index += 1) {
    result *= index;
  }
  return result;
}

double evaluateExpressionNode(ExprNode node, ExpressionContext context) {
  double radians(double value) =>
      context.angle == AngleUnit.degrees ? value * math.pi / 180 : value;
  double angle(double value) =>
      context.angle == AngleUnit.degrees ? value * 180 / math.pi : value;

  final double result;
  switch (node) {
    case NumberNode():
      result = node.value;
      break;
    case ConstantNode():
      result = switch (node.name) {
        'pi' => math.pi,
        'e' => math.e,
        _ => context.ans,
      };
      break;
    case GroupNode():
      result = evaluateExpressionNode(node.argument, context);
      break;
    case UnaryNode():
      final value = evaluateExpressionNode(node.argument, context);
      result = node.operator == '-' ? -value : value;
      break;
    case PostfixNode():
      final value = evaluateExpressionNode(node.argument, context);
      result = node.operator == '%' ? value / 100 : factorial(value);
      break;
    case BinaryNode():
      final left = evaluateExpressionNode(node.left, context);
      final right = evaluateExpressionNode(node.right, context);
      result = switch (node.operator) {
        '+' => left + right,
        '-' => left - right,
        '*' => left * right,
        '/' when right == 0 => throw const ExpressionException(
          'Cannot divide by zero.',
        ),
        '/' => left / right,
        _ => math.pow(left, right).toDouble(),
      };
      break;
    case FunctionNode():
      final value = evaluateExpressionNode(node.argument, context);
      result = switch (node.name) {
        'sin' => math.sin(radians(value)),
        'cos' => math.cos(radians(value)),
        'tan' => math.tan(radians(value)),
        'asin' => angle(math.asin(value)),
        'acos' => angle(math.acos(value)),
        'atan' => angle(math.atan(value)),
        'sqrt' when value < 0 => throw const ExpressionException(
          'Square root requires a non-negative number.',
        ),
        'sqrt' => math.sqrt(value),
        'cbrt' =>
          value < 0
              ? -math.pow(-value, 1 / 3).toDouble()
              : math.pow(value, 1 / 3).toDouble(),
        'ln' when value <= 0 => throw const ExpressionException(
          'Natural logarithm requires a positive number.',
        ),
        'ln' => math.log(value),
        'log' when value <= 0 => throw const ExpressionException(
          'Logarithm requires a positive number.',
        ),
        'log' => math.log(value) / math.log(10),
        'exp' => math.exp(value),
        'sinh' => (math.exp(value) - math.exp(-value)) / 2,
        'cosh' => (math.exp(value) + math.exp(-value)) / 2,
        'tanh' =>
          value > 20
              ? 1
              : value < -20
              ? -1
              : (math.exp(2 * value) - 1) / (math.exp(2 * value) + 1),
        'asinh' => math.log(value + math.sqrt(value * value + 1)),
        'acosh' when value < 1 => throw const ExpressionException(
          'Inverse hyperbolic cosine requires a value of 1 or greater.',
        ),
        'acosh' => math.log(value + math.sqrt(value * value - 1)),
        'atanh' when value.abs() >= 1 => throw const ExpressionException(
          'Inverse hyperbolic tangent requires a value between −1 and 1.',
        ),
        'atanh' => .5 * math.log((1 + value) / (1 - value)),
        'abs' => value.abs(),
        'floor' => value.floorToDouble(),
        'ceil' => value.ceilToDouble(),
        _ => value.roundToDouble(),
      };
      break;
  }
  if (!result.isFinite) {
    throw const ExpressionException(
      'The result is outside the supported range.',
    );
  }
  return result;
}

int _precedence(ExprNode node) => switch (node) {
  BinaryNode(operator: '+' || '-') => 1,
  BinaryNode(operator: '*' || '/') => 2,
  UnaryNode() => 3,
  BinaryNode(operator: '^') => 4,
  PostfixNode() => 5,
  _ => 6,
};

String nodeToLatex(ExprNode node, [int parentPrecedence = 0]) {
  final precedence = _precedence(node);
  final String content;
  switch (node) {
    case NumberNode():
      content = node.raw;
      break;
    case ConstantNode():
      content = switch (node.name) {
        'pi' => r'\pi',
        'ans' => r'\mathrm{Ans}',
        _ => 'e',
      };
      break;
    case GroupNode():
      content = '\\left(${nodeToLatex(node.argument)}\\right)';
      break;
    case UnaryNode():
      content = '${node.operator}${nodeToLatex(node.argument, precedence)}';
      break;
    case PostfixNode():
      final operator = node.operator == '%' ? r'\%' : '!';
      content = '${nodeToLatex(node.argument, precedence)}$operator';
      break;
    case FunctionNode():
      final argument = nodeToLatex(node.argument);
      content = switch (node.name) {
        'sqrt' => '\\sqrt{$argument}',
        'cbrt' => '\\sqrt[3]{$argument}',
        'abs' => '\\left|$argument\\right|',
        _ => '\\${node.name}\\left($argument\\right)',
      };
      break;
    case BinaryNode():
      final left = nodeToLatex(node.left, precedence);
      final right = nodeToLatex(
        node.right,
        node.operator == '^' ? precedence - 1 : precedence,
      );
      content = switch (node.operator) {
        '/' => '\\frac{$left}{$right}',
        '^' => '{$left}^{$right}',
        '*' => '$left${node.implicit ? r'\,' : r'\times'}$right',
        '-' => '$left-$right',
        _ => '$left+$right',
      };
      break;
  }
  return parentPrecedence > 0 && precedence < parentPrecedence
      ? '\\left($content\\right)'
      : content;
}

class ExpressionResult {
  const ExpressionResult({
    required this.ast,
    required this.value,
    required this.latex,
  });

  final ExprNode ast;
  final double value;
  final String latex;
}

ExpressionResult calculateExpression(
  String expression, {
  ExpressionContext context = const ExpressionContext(),
}) {
  final normalized = normalizeExpression(expression);
  final ast = normalized.isEmpty
      ? const NumberNode(0, '0')
      : ExpressionParser(normalized).parse();
  return ExpressionResult(
    ast: ast,
    value: evaluateExpressionNode(ast, context),
    latex: nodeToLatex(ast),
  );
}
