import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HistoryEntry {
  const HistoryEntry({
    required this.expression,
    required this.result,
    required this.timestamp,
    this.toolId,
    this.values = const {},
  });

  final String expression;
  final Object result;
  final DateTime timestamp;
  final String? toolId;
  final Map<String, String> values;

  bool get isTool => toolId != null;

  Map<String, Object> toJson() => {
    'expression': expression,
    'result': result,
    'timestamp': timestamp.toIso8601String(),
    if (toolId != null) 'toolId': toolId!,
    if (values.isNotEmpty) 'values': values,
  };

  static HistoryEntry? fromJson(Object? raw) {
    if (raw is! Map) return null;
    final expression = raw['expression'];
    final result = raw['result'];
    final timestamp = raw['timestamp'];
    if (expression is! String ||
        (result is! num && result is! String) ||
        timestamp is! String)
      return null;
    final parsed = DateTime.tryParse(timestamp);
    if (parsed == null) return null;
    return HistoryEntry(
      expression: expression,
      result: result is num ? result.toDouble() : result,
      timestamp: parsed,
      toolId: raw['toolId'] is String ? raw['toolId'] as String : null,
      values: raw['values'] is Map
          ? (raw['values'] as Map).map(
              (key, value) => MapEntry(key.toString(), value.toString()),
            )
          : const {},
    );
  }
}

class HistoryController extends ChangeNotifier {
  HistoryController() : _preferences = SharedPreferencesAsync();

  static const _key = 'calculation_history_v1';
  final SharedPreferencesAsync _preferences;
  final List<HistoryEntry> _entries = [];

  List<HistoryEntry> get entries => List.unmodifiable(_entries);

  Future<void> load() async {
    final encoded = await _preferences.getString(_key);
    if (encoded == null) return;
    try {
      final decoded = jsonDecode(encoded);
      if (decoded is List) {
        _entries
          ..clear()
          ..addAll(
            decoded
                .map(HistoryEntry.fromJson)
                .whereType<HistoryEntry>()
                .take(50),
          );
        notifyListeners();
      }
    } catch (_) {
      // Ignore damaged local history and start clean.
    }
  }

  Future<void> add(String expression, double result) async {
    if (expression.trim().isEmpty || !result.isFinite) return;
    if (_entries.isNotEmpty &&
        _entries.first.expression == expression &&
        _entries.first.result == result)
      return;
    _entries.insert(
      0,
      HistoryEntry(
        expression: expression,
        result: result,
        timestamp: DateTime.now(),
      ),
    );
    if (_entries.length > 50) _entries.removeRange(50, _entries.length);
    notifyListeners();
    await _save();
  }

  Future<void> addTool(
    String title,
    String result,
    String toolId,
    Map<String, String> values,
  ) async {
    if (title.trim().isEmpty || result.trim().isEmpty) return;
    if (_entries.isNotEmpty &&
        _entries.first.toolId == toolId &&
        _entries.first.result == result &&
        _mapsEqual(_entries.first.values, values)) {
      return;
    }
    _entries.insert(
      0,
      HistoryEntry(
        expression: title,
        result: result,
        timestamp: DateTime.now(),
        toolId: toolId,
        values: Map<String, String>.from(values),
      ),
    );
    if (_entries.length > 50) _entries.removeRange(50, _entries.length);
    notifyListeners();
    await _save();
  }

  Future<void> clear() async {
    _entries.clear();
    notifyListeners();
    await _preferences.remove(_key);
  }

  Future<void> _save() => _preferences.setString(
    _key,
    jsonEncode(_entries.map((entry) => entry.toJson()).toList()),
  );
}

bool _mapsEqual(Map<String, String> a, Map<String, String> b) {
  if (a.length != b.length) return false;
  for (final entry in a.entries) {
    if (b[entry.key] != entry.value) return false;
  }
  return true;
}
