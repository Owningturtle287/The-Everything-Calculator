import 'package:flutter/material.dart';

import '../core/settings_controller.dart';
import '../theme/app_theme.dart';

class SettingsSheet extends StatelessWidget {
  const SettingsSheet({super.key, required this.settings});

  final SettingsController settings;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: settings,
      builder: (context, _) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'MAKE IT YOURS',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: AppTheme.orangeDark,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.4,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Settings',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'Choose the appearance and result formatting. RAD/DEG is controlled from the scientific keypad.',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'Appearance',
                style: Theme.of(
                  context,
                ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 10),
              SegmentedButton<ThemeMode>(
                segments: const [
                  ButtonSegment(
                    value: ThemeMode.light,
                    icon: Icon(Icons.light_mode_rounded),
                    label: Text('Light'),
                  ),
                  ButtonSegment(
                    value: ThemeMode.dark,
                    icon: Icon(Icons.dark_mode_rounded),
                    label: Text('Dark'),
                  ),
                  ButtonSegment(
                    value: ThemeMode.system,
                    icon: Icon(Icons.settings_suggest_rounded),
                    label: Text('System'),
                  ),
                ],
                selected: {settings.themeMode},
                showSelectedIcon: false,
                onSelectionChanged: (selection) =>
                    settings.setTheme(selection.first),
              ),
              const SizedBox(height: 18),
              _SettingRow(
                title: 'Decimal precision',
                subtitle: 'Maximum digits after the decimal.',
                child: DropdownButton<int>(
                  value: settings.precision,
                  underline: const SizedBox.shrink(),
                  items: List<int>.generate(15, (index) => index + 1)
                      .map(
                        (value) => DropdownMenuItem(
                          value: value,
                          child: Text('$value digits'),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value != null) settings.setPrecision(value);
                  },
                ),
              ),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: const Text('Thousands separators'),
                subtitle: const Text('Format large results for readability.'),
                activeTrackColor: AppTheme.orange,
                value: settings.separators,
                onChanged: settings.setSeparators,
              ),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: const Text('Key feedback'),
                subtitle: const Text('Subtle vibration on supported devices.'),
                activeTrackColor: AppTheme.orange,
                value: settings.haptics,
                onChanged: settings.setHaptics,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.end,
                children: [
                  OutlinedButton(
                    onPressed: settings.reset,
                    child: const Text('Reset'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => _showChangeLog(context),
                    icon: const Icon(Icons.history_edu_rounded, size: 18),
                    label: const Text('Change log'),
                  ),
                  FilledButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.check_rounded),
                    label: const Text('Done'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showChangeLog(BuildContext context) => showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Version 1.0.5'),
      content: const SingleChildScrollView(
        child: Text(
          '• Half-width toolbox and a shorter main calculator that keeps scientific equals in view\n'
          '• Searchable, nameable favorite folders with nesting, rename, move, and delete\n'
          '• Revised signed keypad with 000 plus mortgage lifetime loan cost\n'
          '• Typed reference dimensions and corrected true-scale geometry/element visuals\n'
          '• Labeled triangle visual and a crisp pannable/zoomable quadratic graph\n'
          '• Reliable rocket branding and the corrected rectangle equation badge\n\n'
          'Version 1.0.4\n'
          '• Larger logo, quieter version badge, corrected divide/backspace placement, and denser toolbox rows\n'
          '• Narrower date inputs and an automatic triangle solver with result classification\n'
          '• True-proportion geometry visuals with an adjustable, equally scaled red reference\n'
          '• Lighter labels plus a zoomable quadratic graph with 0.2 subdivisions and a marked apex\n'
          '• Rocket branding for Science & engineering and corrected geometry badges\n'
          '• Direct Frankfurter v2 currency rates with a v1 and session-cache fallback\n\n'
          'Version 1.0.3\n'
          '• Compact main calculator, unlimited favorites, grouped signed input, live visuals, expanded conversions, and the 118-element shape calculator.',
        ),
      ),
      actions: [
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Done'),
        ),
      ],
    ),
  );
}

class _SettingRow extends StatelessWidget {
  const _SettingRow({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          child,
        ],
      ),
    );
  }
}
