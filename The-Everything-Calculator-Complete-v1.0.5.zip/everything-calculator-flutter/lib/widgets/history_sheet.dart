import 'package:flutter/material.dart';

import '../core/history_controller.dart';
import '../core/number_format.dart';
import '../core/settings_controller.dart';
import '../theme/app_theme.dart';

class HistorySheet extends StatelessWidget {
  const HistorySheet({
    super.key,
    required this.history,
    required this.settings,
    required this.onSelect,
  });

  final HistoryController history;
  final SettingsController settings;
  final ValueChanged<HistoryEntry> onSelect;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([history, settings]),
      builder: (context, _) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'RECENT WORK',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: AppTheme.orangeDark,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.4,
                              ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'History',
                          style: Theme.of(context).textTheme.headlineMedium,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Expanded(
                child: history.entries.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.history_rounded,
                              color: AppTheme.orange,
                              size: 38,
                            ),
                            SizedBox(height: 10),
                            Text('Completed calculations will appear here.'),
                          ],
                        ),
                      )
                    : ListView.separated(
                        itemCount: history.entries.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          final entry = history.entries[index];
                          return Material(
                            color: Theme.of(
                              context,
                            ).colorScheme.surfaceContainer,
                            borderRadius: BorderRadius.circular(15),
                            child: ListTile(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              title: Text(
                                entry.expression,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontFamily: 'monospace',
                                  fontSize: 13,
                                ),
                              ),
                              subtitle: Text(
                                entry.result is num
                                    ? formatNumber(
                                        entry.result as num,
                                        precision: settings.precision,
                                        separators: settings.separators,
                                      )
                                    : entry.result.toString(),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 17,
                                ),
                              ),
                              trailing: Text(
                                _relativeDate(entry.timestamp),
                                style: Theme.of(context).textTheme.labelSmall
                                    ?.copyWith(
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.onSurfaceVariant,
                                    ),
                              ),
                              onTap: () {
                                Navigator.pop(context);
                                onSelect(entry);
                              },
                            ),
                          );
                        },
                      ),
              ),
              if (history.entries.isNotEmpty) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: history.clear,
                  icon: const Icon(Icons.delete_outline_rounded),
                  label: const Text('Clear history'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  String _relativeDate(DateTime date) {
    final difference = DateTime.now().difference(date);
    if (difference.inMinutes < 1) return 'now';
    if (difference.inHours < 1) return '${difference.inMinutes}m';
    if (difference.inDays < 1) return '${difference.inHours}h';
    return '${date.month}/${date.day}';
  }
}
