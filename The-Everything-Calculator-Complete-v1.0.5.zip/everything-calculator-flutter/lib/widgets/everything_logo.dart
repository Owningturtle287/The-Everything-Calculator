import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class EverythingLogo extends StatelessWidget {
  const EverythingLogo({super.key, this.showWordmark = true, this.size = 42});

  final bool showWordmark;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFFFF9A3D), Color(0xFFF05A16)],
            ),
            borderRadius: BorderRadius.circular(size * .29),
            boxShadow: const [
              BoxShadow(
                color: Color(0x33D74800),
                blurRadius: 12,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: Stack(
            children: [
              Center(
                child: Icon(
                  Icons.calculate_rounded,
                  color: Colors.white,
                  size: size * .68,
                ),
              ),
              Positioned(
                right: size * .08,
                top: size * .06,
                child: Icon(
                  Icons.auto_awesome_rounded,
                  color: const Color(0xFFFFF4E8),
                  size: size * .22,
                ),
              ),
            ],
          ),
        ),
        if (showWordmark) ...[
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'The Everything',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  fontWeight: FontWeight.w800,
                  height: 1,
                ),
              ),
              const SizedBox(height: 3),
              const Text(
                'CALCULATOR',
                style: TextStyle(
                  color: AppTheme.orangeDark,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.2,
                  height: 1,
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }
}
