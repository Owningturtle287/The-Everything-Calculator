import 'package:flutter/material.dart';

import '../data/tool_catalog.dart';
import '../data/tool_badges.dart';
import '../models/tool_models.dart';
import '../theme/app_theme.dart';
import 'everything_logo.dart';

class ToolDrawer extends StatefulWidget {
  const ToolDrawer({
    super.key,
    required this.onToolSelected,
    this.selectionPrompt,
  });

  final ValueChanged<EverythingTool> onToolSelected;
  final String? selectionPrompt;

  @override
  State<ToolDrawer> createState() => _ToolDrawerState();
}

class _ToolDrawerState extends State<ToolDrawer> {
  final search = TextEditingController();

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = search.text.trim().toLowerCase();
    final sections = toolSections
        .map((section) {
          final tools = query.isEmpty
              ? section.tools
              : section.tools
                    .where((tool) => tool.searchableText.contains(query))
                    .toList();
          return (section: section, tools: tools);
        })
        .where((item) => item.tools.isNotEmpty)
        .toList();
    return Drawer(
      width: (MediaQuery.sizeOf(context).width * .54).clamp(214, 280).toDouble(),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
      clipBehavior: Clip.antiAlias,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 9, 10, 7),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const EverythingLogo(showWordmark: false, size: 42),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'THE TOOLBOX',
                          style: Theme.of(context).textTheme.labelSmall
                              ?.copyWith(
                                color: AppTheme.orangeDark,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 1.3,
                              ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          widget.selectionPrompt ?? 'Everything, organized.',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        Text(
                          '${allTools.length} converters and calculators',
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(
                                color: Theme.of(
                                  context,
                                ).colorScheme.onSurfaceVariant,
                              ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: search,
                textInputAction: TextInputAction.search,
                style: const TextStyle(fontSize: 16),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search_rounded),
                  hintText: 'Search tools or units',
                  isDense: true,
                ),
                onChanged: (_) => setState(() {}),
              ),
            ),
            const SizedBox(height: 6),
            Expanded(
              child: sections.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'No tools found. Try a unit or topic like “mile,” “loan,” or “energy.”',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : ListView.builder(
                      key: ValueKey(query),
                      padding: const EdgeInsets.fromLTRB(8, 0, 8, 18),
                      itemCount: sections.length,
                      itemBuilder: (context, index) {
                        final item = sections[index];
                        return ExpansionTile(
                          key: ValueKey('${item.section.id}-$query'),
                          initiallyExpanded: query.isNotEmpty,
                          leading: _CategoryIcon(icon: item.section.icon),
                          tilePadding: const EdgeInsets.symmetric(
                            horizontal: 10,
                          ),
                          visualDensity: const VisualDensity(vertical: -2),
                          minTileHeight: 58,
                          title: Text(
                            item.section.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                              height: 1.08,
                            ),
                          ),
                          subtitle: Text(
                            '${item.section.description} · ${item.section.tools.length}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(
                              color: Theme.of(
                                context,
                              ).colorScheme.outlineVariant,
                            ),
                          ),
                          collapsedShape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                          ),
                          childrenPadding: const EdgeInsets.fromLTRB(8, 0, 6, 4),
                          children: item.tools
                              .map(
                                (tool) => ListTile(
                                  dense: true,
                                  minTileHeight: 38,
                                  visualDensity: const VisualDensity(
                                    vertical: -3,
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  title: Text(
                                    tool.shortTitle,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 14.5,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  trailing: _ToolBadge(label: toolBadge(tool)),
                                  onTap: () => widget.onToolSelected(tool),
                                ),
                              )
                              .toList(),
                        );
                      },
                    ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(18, 12, 18, 14),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerLow,
                border: Border(
                  top: BorderSide(
                    color: Theme.of(context).colorScheme.outlineVariant,
                  ),
                ),
              ),
              child: const Row(
                children: [
                  Icon(
                    Icons.auto_awesome_rounded,
                    color: AppTheme.orange,
                    size: 19,
                  ),
                  SizedBox(width: 9),
                  Expanded(
                    child: Text(
                      'The catalog is built to keep growing.',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CategoryIcon extends StatelessWidget {
  const _CategoryIcon({required this.icon});
  final IconData icon;

  @override
  Widget build(BuildContext context) => Container(
    width: 46,
    height: 46,
    decoration: BoxDecoration(
      color: AppTheme.orange.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: AppTheme.orange.withValues(alpha: .28)),
    ),
    child: Icon(icon, size: 24, color: AppTheme.orangeDark),
  );
}

class _ToolBadge extends StatelessWidget {
  const _ToolBadge({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) => ConstrainedBox(
    constraints: const BoxConstraints(maxWidth: 82),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      decoration: BoxDecoration(
        color: AppTheme.orange.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: AppTheme.orange.withValues(alpha: .28)),
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(
          label,
          maxLines: 1,
          style: const TextStyle(
            color: AppTheme.orangeDark,
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    ),
  );
}
