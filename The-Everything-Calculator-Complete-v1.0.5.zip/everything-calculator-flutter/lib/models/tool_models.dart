import 'package:flutter/material.dart';

abstract class EverythingTool {
  const EverythingTool({
    required this.id,
    required this.title,
    required this.shortTitle,
    required this.description,
    required this.icon,
  });

  final String id;
  final String title;
  final String shortTitle;
  final String description;
  final IconData icon;

  String get searchableText => '$title $shortTitle $description'.toLowerCase();
}

enum ConversionKind { linear, fuelEconomy }

class UnitItem {
  const UnitItem(
    this.name,
    this.symbol,
    this.factor, {
    this.offset = 0,
    this.key,
  });

  final String name;
  final String symbol;
  final double factor;
  final double offset;
  final String? key;
}

class UnitTool extends EverythingTool {
  const UnitTool({
    required super.id,
    required super.title,
    required super.shortTitle,
    required super.description,
    required super.icon,
    required this.units,
    this.defaultFrom = 0,
    this.defaultTo = 1,
    this.note = '',
    this.kind = ConversionKind.linear,
  });

  final List<UnitItem> units;
  final int defaultFrom;
  final int defaultTo;
  final String note;
  final ConversionKind kind;

  UnitConversionResult convert(double value, int fromIndex, int toIndex) {
    if (!value.isFinite) throw const FormatException('Enter a valid number.');
    if (fromIndex < 0 ||
        fromIndex >= units.length ||
        toIndex < 0 ||
        toIndex >= units.length) {
      throw const FormatException('Choose valid units.');
    }
    final from = units[fromIndex];
    final to = units[toIndex];
    late final double converted;
    late final String latex;
    if (kind == ConversionKind.fuelEconomy) {
      if (value <= 0) {
        throw const FormatException('Fuel economy must be greater than zero.');
      }
      final litersPer100 = switch (from.key) {
        'l100' => value,
        'kml' => 100 / value,
        'mpgus' => 235.214583 / value,
        _ => 282.480936 / value,
      };
      converted = switch (to.key) {
        'l100' => litersPer100,
        'kml' => 100 / litersPer100,
        'mpgus' => 235.214583 / litersPer100,
        _ => 282.480936 / litersPer100,
      };
      latex =
          '${_compact(value)}\\;${from.symbol} = ${_compact(converted)}\\;${to.symbol}';
    } else {
      final base = (value + from.offset) * from.factor;
      converted = base / to.factor - to.offset;
      latex = id == 'unit-temperature'
          ? _temperatureLatex(value, from.symbol, to.symbol)
          : (from.offset != 0 || to.offset != 0)
          ? r'\left(' +
                '(${_compact(value)}+${_compact(from.offset)})\\times${_compact(from.factor)}' +
                r'\right)\div' +
                '${_compact(to.factor)}-${_compact(to.offset)}'
          : '${_compact(value)}\\times\\frac{${_compact(from.factor)}}{${_compact(to.factor)}}';
    }
    if (!converted.isFinite) {
      throw const FormatException(
        'The converted value is outside the supported range.',
      );
    }
    return UnitConversionResult(
      value: converted,
      from: from,
      to: to,
      latex: latex,
    );
  }

  @override
  String get searchableText =>
      '$title $shortTitle $description ${units.map((unit) => '${unit.name} ${unit.symbol}').join(' ')}'
          .toLowerCase();
}

String _temperatureLatex(double value, String from, String to) {
  final input = _compact(value);
  return switch ('$from>$to') {
    '°C>°F' => '$input\\times\\frac{9}{5}+32',
    '°F>°C' => '($input-32)\\times\\frac{5}{9}',
    '°C>K' => '$input+273.15',
    'K>°C' => '$input-273.15',
    '°F>K' => '($input+459.67)\\times\\frac{5}{9}',
    'K>°F' => '$input\\times\\frac{9}{5}-459.67',
    '°C>°R' => '($input+273.15)\\times\\frac{9}{5}',
    '°R>°C' => '$input\\times\\frac{5}{9}-273.15',
    '°F>°R' => '$input+459.67',
    '°R>°F' => '$input-459.67',
    'K>°R' => '$input\\times\\frac{9}{5}',
    '°R>K' => '$input\\times\\frac{5}{9}',
    _ => input,
  };
}

String _compact(double value) {
  if (value == value.roundToDouble()) return value.toInt().toString();
  return value.toStringAsPrecision(10).replaceFirst(RegExp(r'\.?0+$'), '');
}

class UnitConversionResult {
  const UnitConversionResult({
    required this.value,
    required this.from,
    required this.to,
    required this.latex,
  });

  final double value;
  final UnitItem from;
  final UnitItem to;
  final String latex;
}

enum ToolFieldType { number, text, select, date, time12 }

class ToolOption {
  const ToolOption(this.value, this.label);
  final String value;
  final String label;
}

class ToolField {
  const ToolField({
    required this.id,
    required this.label,
    required this.type,
    required this.defaultValue,
    this.unit = '',
    this.help = '',
    this.options = const [],
    this.segmented = false,
    this.showWhenField,
    this.showWhenValues = const [],
    this.numericList = false,
    this.solveToggle = false,
    this.solveByDefault = false,
    this.periodDefault = 'am',
  });

  factory ToolField.number(
    String id,
    String label,
    num defaultValue, {
    String unit = '',
    String help = '',
    String? showWhenField,
    List<String> showWhenValues = const [],
    bool solveToggle = false,
    bool solveByDefault = false,
  }) => ToolField(
    id: id,
    label: label,
    type: ToolFieldType.number,
    defaultValue: defaultValue.toString(),
    unit: unit,
    help: help,
    showWhenField: showWhenField,
    showWhenValues: showWhenValues,
    solveToggle: solveToggle,
    solveByDefault: solveByDefault,
  );

  factory ToolField.text(
    String id,
    String label,
    String defaultValue, {
    String help = '',
    String? showWhenField,
    List<String> showWhenValues = const [],
    bool numericList = false,
    bool time12 = false,
    String periodDefault = 'am',
  }) => ToolField(
    id: id,
    label: label,
    type: time12 ? ToolFieldType.time12 : ToolFieldType.text,
    defaultValue: defaultValue,
    help: help,
    showWhenField: showWhenField,
    showWhenValues: showWhenValues,
    numericList: numericList,
    periodDefault: periodDefault,
  );

  factory ToolField.date(
    String id,
    String label,
    String defaultValue, {
    String? showWhenField,
    List<String> showWhenValues = const [],
  }) => ToolField(
    id: id,
    label: label,
    type: ToolFieldType.date,
    defaultValue: defaultValue,
    showWhenField: showWhenField,
    showWhenValues: showWhenValues,
  );

  factory ToolField.select(
    String id,
    String label,
    String defaultValue,
    List<ToolOption> options, {
    bool segmented = false,
    String? showWhenField,
    List<String> showWhenValues = const [],
  }) => ToolField(
    id: id,
    label: label,
    type: ToolFieldType.select,
    defaultValue: defaultValue,
    options: options,
    segmented: segmented,
    showWhenField: showWhenField,
    showWhenValues: showWhenValues,
  );

  final String id;
  final String label;
  final ToolFieldType type;
  final String defaultValue;
  final String unit;
  final String help;
  final List<ToolOption> options;
  final bool segmented;
  final String? showWhenField;
  final List<String> showWhenValues;
  final bool numericList;
  final bool solveToggle;
  final bool solveByDefault;
  final String periodDefault;

  bool isVisible(Map<String, String> values) {
    final source = showWhenField;
    return source == null || showWhenValues.contains(values[source]);
  }
}

typedef ToolCalculator = ToolResult Function(Map<String, String> values);

class CalculatorTool extends EverythingTool {
  const CalculatorTool({
    required super.id,
    required super.title,
    required super.shortTitle,
    required super.description,
    required super.icon,
    required this.fields,
    required this.calculate,
    this.note = '',
    this.currency = false,
    this.asyncType = '',
  });

  final List<ToolField> fields;
  final ToolCalculator calculate;
  final String note;
  final bool currency;
  final String asyncType;

  @override
  String get searchableText =>
      '$title $shortTitle $description ${fields.map((field) => '${field.label} ${field.unit}').join(' ')}'
          .toLowerCase();
}

class ToolResult {
  const ToolResult({
    required this.primary,
    this.unit = '',
    this.latex = '',
    this.details = const [],
    this.note = '',
    this.meta = const {},
  });

  final Object primary;
  final String unit;
  final String latex;
  final List<ResultDetail> details;
  final String note;
  final Map<String, Object> meta;
}

class ResultDetail {
  const ResultDetail(
    this.label,
    this.value, {
    this.prefix = '',
    this.suffix = '',
  });
  final String label;
  final Object value;
  final String prefix;
  final String suffix;
}

class ToolSection {
  const ToolSection({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.tools,
  });

  final String id;
  final String title;
  final String description;
  final IconData icon;
  final List<EverythingTool> tools;
}
