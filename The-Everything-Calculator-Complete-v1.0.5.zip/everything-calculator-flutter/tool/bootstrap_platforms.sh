#!/usr/bin/env bash
set -euo pipefail

flutter create \
  --platforms=android,ios \
  --org com.everythingcalculator \
  --project-name everything_calculator \
  .

android_manifest="android/app/src/main/AndroidManifest.xml"
if [[ -f "$android_manifest" ]] && ! grep -q 'android.permission.INTERNET' "$android_manifest"; then
  sed -i '/<manifest/a\    <uses-permission android:name="android.permission.INTERNET" />' "$android_manifest"
fi

flutter pub get
flutter test

echo "Platform runners are ready. Use 'flutter run' to launch the app."
