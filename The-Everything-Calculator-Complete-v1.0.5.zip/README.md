# The Everything Calculator

This workspace contains two matching implementations:

- `everything-calculator-flutter/` — Flutter/Dart source for iPhone and Android
- `everything-calculator-web/` — dependency-free responsive HTML/CSS/JavaScript clone

Both version 1.0.5 implementations include:

- Basic and scientific calculation with a live-updating formula
- Textbook-shaped fractions, powers, roots, and functions
- A 30-key scientific panel with memory, inverse functions, and local RAD/DEG control
- Four starter favorite folders plus unlimited persisted, searchable nested folders
- Persisted light, dark, and system appearance settings
- A compact half-width top-drop toolbox organized into nine searchable categories
- 92 converter/calculator tools spanning daily units, science, digital data, finance, health, geometry, math/statistics, engineering, dates, recipes, projects, and travel
- Loan down payments, mortgage/escrow estimates, metric/imperial modes, and clock-format work time
- An all-118-element shape calculator for reference volume, mass, and weight
- Blank-by-default tool inputs, manual tool-history saves, two-decimal money, and precision choices from 1–15
- Automatic triangle solving/classification, typed true-proportion geometry references, labeled triangle visuals, and a crisp pannable/zoomable 0.2-subdivision quadratic graph
- A rearranged signed-number keypad with `000` and mortgage lifetime loan cost including principal, interest, and PMI
- Direct live currency rates with versioned endpoint and last-known-rate fallbacks
- Custom orange/white visual system, versioned logo, bundled icons, validation, and responsive layouts

The catalogs are data-driven so additional tools can be added without redesigning the interface. Each project’s README contains setup, testing, deployment, and extension instructions.

## Validation completed

- Web expression and all-tool default tests
- DOM interaction checks for the keypad, collapsed-on-open toolbox, nested favorite folders, inline rocket, reference inputs, and quadratic graph
- Dart syntax parsing for every modified Flutter source and test file
- Catalog coverage for expression, money, all 92 tools, triangle, mortgage lifetime cost, and element density
- Exact offset checks for Celsius/Fahrenheit conversion

The generated mobile platform runner folders are intentionally created with the consumer’s installed Flutter SDK using the included one-command bootstrap script.
